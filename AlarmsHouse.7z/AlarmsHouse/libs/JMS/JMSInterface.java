/*
 * JMSInterface.java
 *
 */
package JMS;

import java.util.Hashtable;

import util.SynchronizedQueue;
import JNI.JNISleep;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.RecordatorioMessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

/**
 * This class manages the JMS communication
 */
public class JMSInterface {
	/**
	 * Constant attribute name to insert the xsd file to convert object
	 */
	static String PROPERTY_XSD_CLASS = "XsdClass";
	/**
	 * Text to represent that all clients must be updated spanish
	 */
	public static String UPDATE_ALL_CLIENTS = "ALL";
	/**
	 * Text to represent that all clients must be updated spanish
	 */
	public static String MEDIDAS = "MEDIDAS";
	
	/**
	 * Constant attribute name to insert the crc information at the jms message
	 */
	static String PROPERTY_CRC = "CRC";
	/**
	 * Constant attribute name to insert the message type information at the jms
	 * message
	 */
	static String PROPERTY_MESSAGETYPE = "MessageType";
	/*
	 * a Constant attribute name to insert the desstination information at the
	 * jms message
	 */
	static String PROPERTY_DESTINY = "Destination";
	/**
	 * Constant attribute name to insert the origin information at the jms
	 * message
	 */
	static String PROPERTY_ORIGIN = "Origin";
	/**
	 * Constant attribute name to insert the redelivered information at the jms
	 * message
	 */
	static String PROPERTY_REDELIVERED = "Redelivered";
	/**
	 * Logger class manager.
	 */
	private static final OCSLogger logger = OCSLoggerFactory
			.getLogger(JMSInterface.class);
	/**
	 * Reception Message Queue
	 */
	private final SynchronizedQueue receptionQueue;
	/**
	 * JMS Configuration manager class
	 */
	private final JMSCfg configuration;
	/**
	 * Suscribers list
	 */
	private JMSSubscriber[] subscribers = new JMSSubscriber[0];
	/**
	 * Publishers list
	 */
	private JMSPublisher[] publishers = new JMSPublisher[0];

	/**
	 * Creates a new instance of JMSInterface.
	 *
	 * @param configFileName
	 *            The configuration file name.
	 */
	public JMSInterface(String configFileName) {
		configuration = new JMSCfg(configFileName);
		receptionQueue = new SynchronizedQueue(
				configuration.getReceptionQueueSize());
		startsCommunications();
	}

	/**
	 * Starts JMS communications.
	 */
	private void startsCommunications() {
		final int numSubscribers = configuration.getSubscribersCount();
		final int numPublicaciones = configuration.getPublishersCount();
		final Hashtable<Integer, JMSConnectionCfg> susc = configuration
				.getSubscribersCfg();
		final Hashtable<Integer, JMSConnectionCfg> publ = configuration
				.getPublishersCfg();

		if (susc != null && susc.size() == numSubscribers) {
			subscribers = new JMSSubscriber[numSubscribers];

			for (int i = 0; i < numSubscribers; i++) {
				subscribers[i] = new JMSSubscriber(i, susc.get(new Integer(i)),
						configuration, receptionQueue);
			}
		} else {
			logger.error("The number of subcriptions not match the number of defined subcriptions");
		}

		try {
			JNISleep.sleep(1000);
		} catch (InterruptedException e) {
			logger.error(e);
		}

		if (publ != null && (publ.size() == numPublicaciones)) {
			publishers = new JMSPublisher[numPublicaciones];

			for (int i = 0; i < numPublicaciones; i++) {
				publishers[i] = new JMSPublisher(i, publ.get(new Integer(i)),
						configuration, receptionQueue);
				JMSWatchDogSender jmsWatchDogSender = new JMSWatchDogSender(
						publishers[i], configuration.getSystemID(),
						publishers[i].getReceiveConditionsFilter());

				for (int suscrip = 0; suscrip < numSubscribers; suscrip++) {
					if (subscribers[suscrip]
							.getTopicQueueName()
							.equalsIgnoreCase(publishers[i].getTopicQueueName())) {
						subscribers[suscrip].setPublicacion(publishers[i]);
					}
				}

				publishers[i].replaceLifeConditionsFilterOnlyOthers();

			}
		} else {
			logger.error("The number of publishers not match the number of defined publishers");
		}
	}

	/**
	 * Get the sync queue where are stored the received messages
	 *
	 * @return received messages queue
	 */
	public final SynchronizedQueue getReceptionQueue() {
		return receptionQueue;
	}

	/**
	 * Get the system JMS Id
	 *
	 * @return JMS Id String
	 */
	public String getSystemID() {
		return configuration.getSystemID();
	}

	/**
	 * Stop the jms communications.
	 */
	public void finishClass() {
		logger.log("Stopping jms communications...");
		if (publishers != null) {
			int num = publishers.length;
			for (int i = 0; i < num; i++) {
				if (publishers[i] != null) {
					publishers[i].stopExecution();
				}
			}
		}
		if (subscribers != null) {
			int num = subscribers.length;
			for (int i = 0; i < num; i++) {
				if (subscribers[i] != null) {
					subscribers[i].stopExecution();
				}
			}
		}
		logger.log("JMSInterface: jms communication stoped.");
	}

	/**
	 * Reconnect all the jms connections.
	 */
	public void reconnection() {
		if (publishers != null) {
			final int num = publishers.length;

			for (int i = 0; i < num; i++) {
				if (publishers[i] != null) {
					publishers[i].jmsReconnection();
				}
			}
		}

		if (subscribers != null) {
			final int num = subscribers.length;

			for (int i = 0; i < num; i++) {
				if (subscribers[i] != null) {
					subscribers[i].jmsReconnection();
				}
			}
		}
	}

	/**
	 * Insert a message into the send messages queue with a selected origin
	 *
	 * @param object
	 *            Object to send.
	 * @param destination
	 *            Destiny system ID of the message
	 * @param origin
	 *            Origin system ID of the message
	 */
	public void sendMessageOtherOrigin(BBGmessage object, String destination,
			String origin) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(origin);
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}
	}

	/**
	 * Insert a message into the send messages queue.
	 *
	 * @param object
	 *            Object to send.
	 * @param destination
	 *            Destiny system ID of the message
	 */
	public void sendMessage(BBGmessage object, String destination) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}
	}
	

	
	/**
	 * Insert an event message into the send messages queue.
	 *
	 * @param object
	 *            Object to send.
	 * @param destination
	 *            Destiny system ID of the message
	 */
	public void sendMessage(eventMessage object, String destination) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}		
	}
	
	public void sendMessage(RecordatorioMessage object, String destination) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}		
	}
	
	/**
	 * Insert a movement sensor message into the send messages queue.
	 *
	 * @param object
	 *            Object to send.
	 * @param destination
	 *            Destiny system ID of the message
	 */
	public void sendMessage(movemessage object, String destination) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}		
	}
	
	/**
	 * Insert a RPI client message into the send messages queue.
	 *
	 * @param object
	 *            Object to send.
	 * @param destination
	 *            Destiny system ID of the message
	 */
	public void sendMessage(RPImessage object, String destination) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(destination);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(object.getClass().getName());
			sendMsg(object, messageToSend);
		}		
	}		
	
	/**
	 * Insert a message into the send messages queue without modifying its type.
	 * This method is only intended to be used for sending messages to EXTERNAL
	 * systems, never between Rail9000 modules
	 *
	 * @param object
	 *            Object to send.
	 * @param messageType
	 *            The message type of the object, used to select the topic to
	 *            publish.
	 */
	public void sendMessageAsObjectExternalSystem(BBGmessage object,
			String messageType) {
		if (object != null) {
			final JMSMessage messageToSend = new JMSMessage();
			messageToSend.setObject(object);
			messageToSend.setDestination(null);
			messageToSend.setOrigin(configuration.getSystemID());
			messageToSend.setMessageType(messageType);
			messageToSend.setEncapsulate(false);
			sendMsg(object, messageToSend);
		}
	}

	/**
	 * Send a message to JMS. Each interface has configured the message types
	 * that must be published on it. Before send the message, the message type
	 * is checked to know if is configured for the specific topic.
	 *
	 * @param object
	 *            Informacion a enviar
	 * @param messageToSend
	 *            Mensaje JMS con todas las condiciones inicializadas para
	 *            enviar.
	 */
	private void sendMsg(Object object, JMSMessage messageToSend) {
		if (object != null) {
			boolean sended = false;
			String shortName = null;
			if (messageToSend.isEncapsulate()) {
				shortName = object.getClass().getSimpleName();
			} else {
				shortName = messageToSend.getMessageType();
			}
			for (int index = 0; index < publishers.length; index++) {
				if (publishers[index] != null) {
					String filterCondition = publishers[index]
							.getReceiveConditionsFilter();
					if (filterCondition.indexOf(";TODOS;") != -1
							|| filterCondition.indexOf(";ALL;") != -1
							|| (filterCondition.indexOf(";" + shortName + ";") != -1)) {
						publishers[index].sendMessage(messageToSend);
						sended = true;
					}
				}
			}
			if (!sended) {
				logger.error("You are trying to send a not configured message: "
						+ shortName);
			}
		} else {
			logger.error("Send NULL message is not possible.");
		}
	}



}
