/*
 * JMSConnectionCfg.java
 *
 */
package JMS;

import java.util.Properties;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import util.UtilProperties;

/**
 * Contains a jms communication configuration parameters
 *
 */
public class JMSConnectionCfg {

  /**
   * Logger class manager.
   */
  private static final OCSLogger logger = OCSLoggerFactory.getLogger(JMSConnectionCfg.class);

  /**
   * Parameter to set SASL_POLICY_NOPLAINTEXT.
   */
  public static final String SASL_POLICY_NOPLAINTEXT = "jboss.naming.client.connect.options.org.xnio.Options.SASL_POLICY_NOPLAINTEXT";

  /**
   * Communication name
   */
  private String communicationName = "";

  /**
   * Username to be used by this topic/queue connection
   */
  private String userName = "";

  /**
   * Password for the userName to be used by this topic/queue connection
   */
  private String password = "";

  /**
   * Inidcate if the communication is with topics (true) or queues (false).
   */
  private boolean topic = true;

  /**
   * JMS Factory Connection
   */
  private String connectionFactory = "jms/RemoteConnectionFactory";

  /**
   * Topic or Queue Name
   */
  private String topicQueueName = "";

  /**
   * Indicates if crc will be checked (true) or not (false)
   */
  private boolean checkCRC = false;

  /**
   * Indicates if the sequence number will be checked (true) or not (false)
   */
  private boolean checkSequence = false;

  /**
   * Indicates if the application is going to halt on a CRC or sequence check fail.
   */
  private boolean rebootOnError = true;

  /**
   * JMS Provider Name
   */
  private String jmsProvider = "remote://servjms:4447";

  /**
   * Connection Factory
   */
  private String jndi = "org.jboss.naming.remote.client.InitialContextFactory";

  /**
   * Reception queue lenght
   */
  private int receptionQueueLenght = 100;

  /**
   * Send queue lenght
   */
  private int sendQueueLenght = 0;

  /**
   * Connection timeout
   */
  private int connectionTimeout = 5000;

  /**
   * Message Type to Send XML or Objeto
   */
  private String messageTypes = "XML";

  /**
   * Persistent message type
   */
  private boolean persistent = false;

  /**
   * Condition filter to receive the messages
   */
  private String receiveConditionsFilter = "";

  /**
   * The value JNI_DISABLE_DISCOVERY of the connection
   */
  private boolean disableDiscovery = true;

  /**
   * The value JNP PARTITION NAME of the connection.
   */
  private String partitionName;

  /**
   * The value JNP DISCOVERY TIMEOUT of the connection.
   */
  private String discoveryTimeout;

  /**
   * The value JNP DISCOVERY PORT of the connection.
   */
  private String discoveryPort;

  /**
   * The value JNP DISCOVERY TTL of the connection.
   */
  private String discoveryTTL;

  /**
   * The value JNP DISCOVERY TTL of the connection.
   */
  private String saslPolicyNoplainText = "false";

  /**
   * The object list that need to ask for a new resend because CRC not match
   */
  private static String[] objects_resend = new String[0];

  /**
   * The object list that produce a reconnection by a sequence number failure
   */
  private static String[] objects_reconnection = new String[0];

  /**
   * Connection timeout
   */
  private int messagesPerMinute;

  /**
   * Creates a new instance JMSConnectionCfg
   *
   * @param idConnection Unique ID of the connection.
   * @param prop JMS configuration properties file
   * @param systemID System identifier Unique ID
   * @param suscription <code>true</code> indicates that the connextion is a subscription, <code>false</code> indicates that the connection is a publication
   */
  public JMSConnectionCfg(String idConnection, Properties prop, String systemID, boolean suscription) {
    initConfiguration(idConnection, prop, systemID, suscription);
  }

  /**
   * Init the class and the configuration.
   *
   * @param idConnection Unique ID of the connection.
   * @param prop JMS configuration properties file
   * @param systemID System identifier Unique ID
   * @param suscription <code>true</code> indicates that the connextion is a subscription, <code>false</code> indicates that the connection is a publication
   */
  private void initConfiguration(String idConnection, Properties prop, String systemID, boolean suscription) {
    try {
      final String filter = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_condition", idConnection + "_condicion" }, null);
      communicationName = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_name", idConnection + "_nombre" }, filter);
      userName = prop.getProperty(idConnection + "_username", "");
      password = prop.getProperty(idConnection + "_password", "");
      topic = Boolean.parseBoolean(UtilProperties.getPropertyML(prop, new String[] { idConnection + "_topic", idConnection + "_topico" }, "true"));
      connectionFactory = prop.getProperty(idConnection + "_fact", "jms/RemoteConnectionFactory");
      topicQueueName = prop.getProperty(idConnection + "_dest", "");
      checkCRC = Boolean.parseBoolean(prop.getProperty(idConnection + "_crc", "true"));
      rebootOnError = Boolean.parseBoolean(prop.getProperty(idConnection + "_rebooterror", "true"));
      jmsProvider = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_provider", idConnection + "_proveedor" }, "remote://servjms:4447");
      jndi = prop.getProperty(idConnection + "_jndi", "org.jboss.naming.remote.client.InitialContextFactory");
      receptionQueueLenght
              = Integer.parseInt(UtilProperties.getPropertyML(prop, new String[] { idConnection + "_queue_size", idConnection + "_tama_cola" }, "100"));
      sendQueueLenght = Integer
              .parseInt(UtilProperties.getPropertyML(prop, new String[] { idConnection + "_resend_queue_size", idConnection + "_tama_cola_reenvio" }, "0"));
      connectionTimeout = Integer.parseInt(prop.getProperty(idConnection + "_timeout", "5000"));
      messageTypes = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_type", idConnection + "_tipo" }, "XML");
      persistent
              = Boolean.parseBoolean(UtilProperties.getPropertyML(prop, new String[] { idConnection + "_persistent", idConnection + "_persistente" }, "false"));
      disableDiscovery = Boolean.parseBoolean(prop.getProperty(idConnection + "_jnp_disableDiscovery", "false"));

      if (!disableDiscovery) {
        partitionName = prop.getProperty(idConnection + "_jnp_partitionName");
        discoveryTimeout = prop.getProperty(idConnection + "_jnp_discoveryTimeout");
        discoveryPort = prop.getProperty(idConnection + "_jnp_discoveryPort");
        discoveryTTL = prop.getProperty(idConnection + "_jnp_discoveryTTL");
      }

      saslPolicyNoplainText = prop.getProperty("saslPolicyNoplainText", "false");

      if (suscription) {
        final String listaReenvios
                = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_resend_objects", idConnection + "_objetos_reenvio" }, null);
        final String listaReconexion
                = UtilProperties.getPropertyML(prop, new String[] { idConnection + "_reconnection_objects", idConnection + "_objetos_reconexion" }, null);

        if ((listaReenvios != null) && (listaReenvios.length() > 0)) {
          objects_resend = listaReenvios.split(";");
        }
        if ((listaReconexion != null) && (listaReconexion.length() > 0)) {
          objects_reconnection = listaReconexion.split(";");
        }

        checkSequence
                = Boolean.parseBoolean(UtilProperties.getPropertyML(prop, new String[] { idConnection + "_sequence", idConnection + "_secuencia" }, "true"));
        if ((filter != null) && (systemID != null)) {
          receiveConditionsFilter = filter.replaceAll("'equipo'", "'" + systemID + "'");
          receiveConditionsFilter = filter.replaceAll("'systemID'", "'" + systemID + "'");
        } else {
          receiveConditionsFilter = filter;
        }
        messagesPerMinute = Integer.parseInt(prop.getProperty(idConnection + "_sla_messages_per_minute", "-1"));
      } else {
        if (filter == null) {
          receiveConditionsFilter = "ALL";
        } else {
          receiveConditionsFilter = filter.replaceAll(" ", "");
        }
      }
    } catch (NumberFormatException e) {
      logger.error(e);
    }
  }

  /**
   * Method that returns the communication name.
   *
   * @return Communication name.
   */
  protected final String getCommunicationName() {
    return communicationName;
  }

  /**
   * Method that returns the username.
   *
   * @return Username.
   */
  protected final String getUserName() {
    return userName;
  }

  /**
   * Method that returns the password for the username.
   *
   * @return Password for the username.
   */
  protected final String getPassword() {
    return password;
  }

  /**
   * Method that return if the communicacion is a topic or not.
   *
   * @return <CODE>true</CODE> id is topic <CODE>false</CODE> if is queue.
   */
  protected final boolean isTopic() {
    return topic;
  }

  /**
   * Method that return the connection factory
   *
   * @return The Connection Factory
   */
  protected final String getConnectionFactory() {
    return connectionFactory;
  }

  /**
   * Method that return the topic or queue name.
   *
   * @return Topic or queue connection name.
   */
  protected final String getTopicQueueName() {
    return topicQueueName;
  }

  /**
   * Method that return if crc check is active or not.
   *
   * @return <CODE>true</CODE> if crc check is active <CODE>false</CODE> i.o.c.
   */
  protected final boolean isCheckCRC() {
    return checkCRC;
  }

  /**
   * This method indicates if the module shall halt after a CTC or sequence error detection.
   * @return TRUE if module is going to halt
   * 
   */
  final boolean isRebootOnError() {
    return rebootOnError;
  }

  /**
   * Method that return if sequence check is active or not.
   *
   * @return <CODE>true</CODE> if sequence check is active <CODE>false</CODE> i.o.c.
   */
  protected final boolean isCheckSequence() {
    return checkSequence;
  }

  /**
   * Get the JMS provider.
   *
   * @return JMS provider
   */
  protected final String getJmsProvider() {
    return jmsProvider;
  }

  /**
   * Get the java naming and directory interface.
   *
   * @return jms JNDI.
   */
  protected final String getJndi() {
    return jndi;
  }

  /**
   * Get the max reception queue lenght
   *
   * @return max reception queue lenght value.
   */
  protected final int getReceptionQueueLenght() {
    return receptionQueueLenght;
  }

  /**
   * Get the max resend queue lenght
   *
   * @return max resend queue lenght.
   */
  protected final int getSendQueueLenght() {
    return sendQueueLenght;
  }

  /**
   * Get the connection timeout.
   *
   * @return connection timeout.
   */
  protected final int getTimeoutConexion() {
    return connectionTimeout;
  }

  /**
   * Get the Message types
   *
   * @return Returns Object or XML
   */
  protected final String getMessageTypes() {
    return messageTypes;
  }

  /**
   * Get if the message send is persistent
   *
   * @return TRUE if message send is persistent, FALSE e.o.c.
   */
  protected final boolean getPersistent() {
    return persistent;
  }

  /**
   * Get the receive conditions filter string
   *
   * @return receive conditions filter String
   */
  protected final String getReceiveConditionsFilter() {
    return receiveConditionsFilter;
  }

  /**
   * Set the receive conditions filter string
   *
   * @param conditions The conditiosn to set
   */
  protected final void setReceiveConditionsFilter(String conditions) {
    receiveConditionsFilter = conditions;
  }

  /**
   * Get the jni_disbale_discovey
   *
   * @return true if disable discovery is disabled, false e.o.c.
   */
  protected final boolean getDisableDiscovery() {
    return disableDiscovery;
  }

  /**
   * get the jni_partitionName value
   *
   * @return the jni partition name string
   */
  public String getPartitionName() {
    return partitionName;
  }

  /**
   * Get the jni_discovery_timeout value
   *
   * @return the discovery timeout String
   */
  public String getDiscoveryTimeout() {
    return discoveryTimeout;
  }

  /**
   * Get the jni_discoveryPort
   *
   * @return the discovery port string value
   */
  public String getDiscoveryPort() {
    return discoveryPort;
  }

  /**
   * Get the jni_discoveryTTL
   *
   * @return the discovery TTL string value
   */
  public String getDiscoveryTTL() {
    return discoveryTTL;
  }

  /**
   * Get the sasl_policy_noplaintext
   *
   * @return the sasl_policy_noplaintext string value
   */
  public String getSaslPolicyNoplainText() {
    return saslPolicyNoplainText;
  }

  /**
   * Check if must ask for a resend of the object by a invalid crc.
   *
   * @param messageType Message type to check
   * @return <code>true</code> if resend must be done, false i.o.c.
   */
  public boolean isResendObject(String messageType) {
    boolean resend = false;

    for (int index = 0; !resend && (index < objects_resend.length); index++) {
      resend = objects_resend[index].equals(messageType);
    }

    return resend;
  }

  /**
   * Check if jms connection must be reconnected by a invalid message type sequence.
   *
   * @param messageType Tipo de dato definido en el mensaje recibido por JMS
   * @return <code>true</code> if reconnection must be done.
   */
  public boolean isReconnectionObject(String messageType) {
    boolean reconnection = false;

    for (int index = 0; !reconnection && (index < objects_reconnection.length); index++) {
      reconnection = objects_reconnection[index].equals(messageType);
    }

    return reconnection;
  }

  public int SLA_MessagesPerMinute() {
    return messagesPerMinute;
  }
}
