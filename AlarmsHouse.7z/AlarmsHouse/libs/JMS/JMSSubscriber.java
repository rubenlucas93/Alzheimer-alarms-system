/*
 * JMSSubscriber.java
 *
 */
package JMS;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;


import javax.jms.Connection;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.exolab.castor.xml.Unmarshaller;

import util.files.XmlParser;
import JMS.JMSmessages.messages.ADSMessage;
import JMS.JMSmessages.messages.Header;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import util.CRC32;
import util.SynchronizedQueue;
import JNI.JNISleep;
import JNI.JNITimer;
import JNI.JNITimerTask;

/**
 * Class that manages a subscriber connetion to jms.
 */
public class JMSSubscriber implements MessageListener, ExceptionListener {

  /**
   * Logger class manager.
   */
  private static final OCSLogger logger = OCSLoggerFactory.getLogger(JMSSubscriber.class);

  /**
   * Communication name
   */
  private String communicationName;

  /**
   * Subscriber number
   */
  private final int subscriberNumber;

  /**
   * JMS Connection configuration
   */
  private final JMSConnectionCfg jmsConnectionCfg;

  /**
   * Subscriber initial context
   */
  private InitialContext ctx = null;

  /**
   * JMS connection
   */
  private Connection connection = null;

  /**
   * Timer for connections
   */
  private JNITimer timer = null;

  /**
   * Task for communication timer.
   */
  private JNITimerTask task = null;

  /**
   * Received messages queue
   */
  private SynchronizedQueue queue_reception = null;

  /**
   * Indicates if the class is doing a jms reconnection
   */
  private boolean jmsReconnection = false;

  /**
   * Connetion user
   */
  private String user = null;

  /**
   * Connection password
   */
  private String pass = null;

  /**
   * Related publisher to this Subscriber
   */
  private JMSPublisher relatedPublisher = null;

  /**
   * Store the sequence of each message types sended
   */
  private final HashMap<String, Long> sequenceTable = new HashMap<String, Long>();

  /**
   * Connection password
   */
  private SlaManager slaManager = null;

  /**
   * Creates a new instance of JMSSubscriber
   *
   * @param number Publisher number
   * @param config JMS Connection configuration
   * @param jmsCfg JMS Subscriber configuration
   * @param queue Notify mesages queue, this queue is for received jms messages notifications.
   */
  JMSSubscriber(int number, JMSConnectionCfg config, JMSCfg jmsCfg, SynchronizedQueue queue) {
    subscriberNumber = number;
    jmsConnectionCfg = config;
    queue_reception = queue;
    user = getUserName(jmsCfg);
    pass = getPassword(jmsCfg);
    if (jmsConnectionCfg.SLA_MessagesPerMinute() > -1) {
      slaManager = new SlaManager(jmsConnectionCfg, this, jmsCfg.getSystemID());
    }
    if (jmsConnectionCfg != null) {
      communicationName = jmsConnectionCfg.getCommunicationName();
      startTimerConnecion();
    } else {
      logger.error("Not exist any configuration for subscriber number " + number);
    }
  }

  /**
   * Updates the objext that manager the publication to the same topic or queue. It is used to request a resend of a message that can be validates by the CRC or
   * sequence checks.
   *
   * @param jmsPublisher Publisher related to the topic or queue
   */
  void setPublicacion(JMSPublisher jmsPublisher) {
    relatedPublisher = jmsPublisher;
  }

  /**
   * Returns the object that manages the publication to the same topic or queue.
   *
   * @param jmsPublisher Publisher related to the topic or queue
   */
  JMSPublisher getPublisher() {
    return relatedPublisher;
  }

  /**
   * Gets the topic or queue communication name
   *
   * @return topic or queue communication name
   */
  String getTopicQueueName() {
    return jmsConnectionCfg.getTopicQueueName();
  }

  /**
   * Start the timer to make a JMS Connetction
   */
  private void startTimerConnecion() {
    if (timer == null) {
      try {
        timer = new JNITimer("startTimerConnecion" + communicationName);
        task = new JNITimerTask() {
          @Override
          public void run() {
            startsCommunication();
          }
        };
        timer.schedule(task, 0, jmsConnectionCfg.getTimeoutConexion());
      } catch (Exception e) {
        logger.error("Cant create the connection timer " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Try to connect to jms
   */
  private synchronized void startsCommunication() {
    if (jmsConnectionCfg != null) {
      obtainContext();
      if (ctx != null && connection == null) {
        initConnection();
      }
    }
  }

  /**
   * Override method called when a jms message is received. After receive the message, the crc is checked if needed. In case the checks must be done and are not
   * correct an error is reported and a request is made.
   *
   * @param message Received message
   */
  @Override
  public void onMessage(Message message) {
    Header header;
    boolean crcStatus;
    long sequenceStatus = 1;
    try {
      boolean fulfillsSLA = true;
      if (slaManager != null) {
        fulfillsSLA = slaManager.newMessage(System.currentTimeMillis());
      }
      if (fulfillsSLA) {
        if (message.getJMSCorrelationID() != null) {
          final String idJMSMensaje = message.getJMSCorrelationID();
          final String messageOrigin = message.getStringProperty(JMSInterface.PROPERTY_ORIGIN);
          logger.log("Received resend message request, message id: " + idJMSMensaje + " from " + messageOrigin);
          if (relatedPublisher != null) {
            relatedPublisher.resendMessage(idJMSMensaje, messageOrigin);
          } else {
            logger.log("The related Publisher to resend message not exist " + idJMSMensaje);
          }
        } else if (message instanceof TextMessage) {
          final JMSMessage receivedMessage = new JMSMessage();
          final TextMessage textMessage = (TextMessage) message;
          final String calculatedChain = textMessage.getText();
          String xsdFile = message.getStringProperty(JMSInterface.PROPERTY_XSD_CLASS);
          if (xsdFile == null) {

            if (message.getBooleanProperty("isMessageFromExternalSources")) {

              String tipoDato = "";
              String origen = "";
              String destino = "";
              try {
                tipoDato = message.getStringProperty("MessageType");
                receivedMessage.setMessageType(tipoDato);
              } catch (JMSException ignored) {
                logger.warn("MessageType is empty");
              }
              try {
                origen = message.getStringProperty("Origin");
                receivedMessage.setOrigin(origen);
              } catch (JMSException ignored) {
                logger.warn("Origin is empty");
              }
              try {
                destino = message.getStringProperty("Destination");
                receivedMessage.setDestination(destino);
              } catch (JMSException ignored) {
                logger.warn("Destination is empty");
              }
              try {
                String textMessageString = ((TextMessage) message).getText();

                if (textMessageString != null) {
                  textMessageString = textMessageString.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
                }

                receivedMessage.setObject(textMessageString);
                crcStatus = checkMessageCRC(message, calculatedChain);
                notificarInformacion(receivedMessage, message, crcStatus, sequenceStatus);

              } catch (JMSException jmse) {
                logger.error("Unable to get the message received through JMS");
              }
            } else {

              Object messageObject;
              ADSMessage atsMessage;
              if (logger.isTraceEnabled()) {
                logger.trace("RX " + communicationName + ": " + calculatedChain);
              }

              atsMessage = (ADSMessage) Unmarshaller.unmarshal(ADSMessage.class, new StringReader(calculatedChain));
              atsMessage.validate();
              messageObject = atsMessage.getInfo();
              header = atsMessage.getHeader();
              crcStatus = checkMessageCRC(message, calculatedChain);

              if (header != null) {
                final Class objectClass = Class.forName(header.getMessageType());
                final Object mensajeObj = Unmarshaller.unmarshal(objectClass, new StringReader(messageObject.toString()));
                receivedMessage.setMessageType(header.getMessageType());
                receivedMessage.setOrigin(header.getOrigin());
                receivedMessage.setDestination(header.getDestination());
                receivedMessage.setObject(mensajeObj);
                sequenceStatus = checkMessageSequence(message, objectClass, header);
              } else {
                final String messageType = message.getStringProperty(JMSInterface.PROPERTY_MESSAGETYPE);
                receivedMessage.setMessageType(messageType);
                receivedMessage.setObject(messageObject);
              }
              receivedMessage.setCRCStatus(crcStatus);
              notificarInformacion(receivedMessage, message, crcStatus, sequenceStatus);

            }
          } else {
            String classString = message.getStringProperty(JMSInterface.PROPERTY_XSD_CLASS);
            if (logger.isTraceEnabled()) {
              logger.trace("RX " + communicationName + ": " + calculatedChain);
            }
            Object objectFromXsd = convertXsdObject(classString, xsdFile, calculatedChain);
            notificarInformacion(objectFromXsd, message, true, 1);
          }

        } else if (message instanceof ObjectMessage) {
          final ObjectMessage object = (ObjectMessage) message;
          final Object objetoRecv = object.getObject();
          if (objetoRecv instanceof ADSMessage) {
            final JMSMessage receivedMessage = new JMSMessage();
            final ADSMessage rxMensaje = (ADSMessage) objetoRecv;
            if (logger.isTraceEnabled()) {
              String classXML = XmlParser.getStringXML(objetoRecv);
              logger.trace("RX " + communicationName + ": " + classXML);
            }
            header = rxMensaje.getHeader();
            crcStatus = checkMessageCRC(message, rxMensaje);

            if (header != null) {
              receivedMessage.setMessageType(header.getMessageType());
              receivedMessage.setOrigin(header.getOrigin());
              receivedMessage.setDestination(header.getDestination());
              sequenceStatus = checkMessageSequence(message, rxMensaje.getInfo().getClass(), header);
            } else {
              final String messageType = message.getStringProperty(JMSInterface.PROPERTY_MESSAGETYPE);
              receivedMessage.setMessageType(messageType);
            }

            receivedMessage.setCRCStatus(crcStatus);
            receivedMessage.setObject(rxMensaje.getInfo());
            notificarInformacion(receivedMessage, message, crcStatus, sequenceStatus);
          } else {
            /*
             * The object comes from an external system and it cannot be
             * casted to ATSMessage
             */
            if (logger.isTraceEnabled()) {
              String classXML = XmlParser.getStringXML(objetoRecv);
              logger.trace("RX " + communicationName + ": " + classXML);
            }
            /*
             * This messages have no CRC and no sequence number, so the
             * values are set by default as never invalid
             */
            notificarInformacion(objetoRecv, message, true, 1);
          }
        }
      } else

      {
        logger.error("REJECTED MESSAGE FROM JMS CONNECTION " + jmsConnectionCfg.getCommunicationName() + " BECAUSE IT IS COMMING FROM A BANNED SYSTEM.");
      }
    } catch (

    javax.jms.JMSException jmse) {

      logger.error("Cant obtain the jms message: " + jmse.getMessage());
      logger.error(jmse);
    } catch (

    org.exolab.castor.xml.MarshalException me) {
      logger.error("Cant make message marshall: " + me.getMessage());
      logger.error(me);
    } catch (

    org.exolab.castor.xml.ValidationException ve) {
      logger.error("Cant validate the xml message: " + ve.getMessage());
      logger.error(ve);
    } catch (

    ClassNotFoundException cnfe) {
      logger.error("Message type not known: " + cnfe.getMessage());
      logger.error(cnfe);
    }
  }

  private Object convertXsdObject(String className, String xsdName, String xml) {
    Object result = null;
    try {
      List<Class<?>> list = ClassFinder.find("common.jms", className);
      if (list.isEmpty()) {
        logger.error("The recieved xml not has a class to unmarshall:> " + className);
      } else if (list.size() > 1) {
        logger.error("The recieved xml has more than  one class to unmarshall :> " + className);
      } else if (list.size() == 1) {
        Class<?> objectClass = list.get(0);
        if (objectClass != null) {
          result = Unmarshaller.unmarshal(objectClass, new StringReader(xml));
        } else {
          System.out.println("OBJECT INSTANCE NOT KNOWN.");
        }

      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return (result);
  }

  /**
   * Check if message CRC is correct. This method only works if is configured to use CRC checks.
   *
   * @param message Message from jms.
   * @param object Message object to calculate the crc.
   * @return <code>true</code> if is a valid CRC, <code>false</code> i.o.c.
   */
  private boolean checkMessageCRC(Message message, Object object) {
    boolean crcStatus = true;

    if (jmsConnectionCfg.isCheckCRC()) {
      try {
        if (message.propertyExists(JMSInterface.PROPERTY_REDELIVERED)) {
          logger.log("Message was received previously, crc not checked");
        } else {
          final String crcMessageText = message.getStringProperty(JMSInterface.PROPERTY_CRC);

          if (crcMessageText != null) {
            final long crc = CRC32.getCRC(object);

            if (!(Long.toHexString(crc).equalsIgnoreCase(crcMessageText))) {
              logger.log("Incorrect crc message received, crc received is: " + crcMessageText + ", CRC calculated " + Long.toHexString(crc));
              crcStatus = false;
              if (jmsConnectionCfg.isRebootOnError()) {
                logger.panicErrorExit("REBOOT ON JMS ERROR ENABLED (CRC ERROR)... MODULE REBOOT NEEDED");
              }
            }
          }
        }
      } catch (javax.jms.JMSException e) {
        logger.error("Exception calculating crc :" + e.getMessage());
        logger.error(e);
      }
    }

    return crcStatus;
  }

  /**
   * Check if message sequence is correct. The sequence number depends of message type and origin message Id.
   *
   * @param message Message from jms.
   * @param objectClass Message object class to check
   * @param header Message header
   * @return Diff between the last message received sequence number and the last message processed sequence number.
   */
  private long checkMessageSequence(Message message, Class objectClass, Header header) {
    long sequenceStatus = 1;

    if (jmsConnectionCfg.isCheckSequence()) {
      try {
        if (message.propertyExists(JMSInterface.PROPERTY_REDELIVERED)) {
          logger.log("Message was received previously, sequence not checked");
        } else if ((objectClass != null) && (header != null) && (header.hasSecNumber())) {
          final long sequence = header.getSecNumber();
          final String origin = header.getOrigin();
          final String destination = header.getDestination();
          final String seqId = origin + "_" + destination + "_" + objectClass.getName();

          if (sequence == 1L) {
            sequenceTable.put(seqId, sequence);
            logger.log("Sequence init for " + seqId);
          } else {
            final Long lastSequence = sequenceTable.get(seqId);

            if (lastSequence == null) {
              sequenceTable.put(seqId, sequence);
              logger.log("Sequence init for " + seqId + " to " + sequence);
            } else {
              sequenceStatus = sequence - lastSequence;

              if (sequenceStatus == 1) { // Correct sequence
                sequenceTable.put(seqId, sequence);
              } else if (sequenceStatus > 1) { // Message lost, we
                // will get the
                // last
                sequenceTable.put(seqId, sequence);
                logger.log("Message lost of  " + seqId + ", number of lost messages: " + (sequenceStatus - 1));
                logger.log("Received sequence was : " + sequence + " and last sequence is: " + lastSequence);
                if (jmsConnectionCfg.isRebootOnError()) {
                  logger.panicErrorExit("REBOOT ON JMS ERROR ENABLED (SECUENCE LOST)... MODULE REBOOT NEEDED");
                }
              } else if (sequenceStatus < -50) { // Very large
                // difference,
                // starts again
                sequenceTable.put(seqId, sequence);
                logger.log("Sequence init for " + seqId + " by sequence adjust");
              } else { // Older message, not processed
                logger.log("Older or repeated message received of " + seqId + ", not updated messages " + sequenceStatus);
                logger.log("Received sequence was : " + sequence + " and last sequence is: " + lastSequence);
              }
            }
          }
        }
      } catch (javax.jms.JMSException e) {
        logger.error("Excepcion al comprobar secuencia correcta:" + e.getMessage());
        logger.error(e);
      }
    }
    return sequenceStatus;
  }

  /**
   * Override method when a jms exception is thrown. At this case the jms connection will be reconnected.
   *
   * @param excepcion jms Exception.
   */
  @Override
  public void onException(JMSException excepcion) {
    logger.error("JMS Exception occurs " + excepcion.getMessage());
    logger.error(excepcion);
    queue_reception.vaciarCola();
    jmsReconnection();
  }

  /**
   * Reconnects the jms connection.
   */
  synchronized void jmsReconnection() {
    if (!jmsReconnection) {
      logger.log("Reconnecting to JBoss...");
      jmsReconnection = true;
      finalizeConnection();
      sequenceTable.clear();
      startTimerConnecion();
      jmsReconnection = false;
    }
  }

  /**
   * Obtain the jms context
   */
  private void obtainContext() {
    try {
      final Properties props = new Properties();
      props.put(InitialContext.INITIAL_CONTEXT_FACTORY, jmsConnectionCfg.getJndi());
      props.put(InitialContext.PROVIDER_URL, jmsConnectionCfg.getJmsProvider());
      props.put(InitialContext.SECURITY_PRINCIPAL, user);
      props.put(InitialContext.SECURITY_CREDENTIALS, pass);
      props.put(JMSConnectionCfg.SASL_POLICY_NOPLAINTEXT, jmsConnectionCfg.getSaslPolicyNoplainText());
      ctx = new InitialContext(props);
    } catch (javax.naming.NamingException e) {
      logger.error("Cant get the context for factory " + jmsConnectionCfg.getJndi() + " and provider " + jmsConnectionCfg.getJmsProvider());
      logger.error(e);
    }
  }

  /**
   * Init the connection statements depending if a topic or queue is configured.
   */
  private void initConnection() {
    if (jmsConnectionCfg.isTopic()) {
      try {
        final TopicConnectionFactory factory = (TopicConnectionFactory) ctx.lookup(jmsConnectionCfg.getConnectionFactory());
        final Topic topic = (Topic) ctx.lookup(jmsConnectionCfg.getTopicQueueName());
        final TopicConnection topicConnection = factory.createTopicConnection(user, pass);
        TopicSession topicSession;
        TopicSubscriber recv;

        topicConnection.setExceptionListener(this);
        topicSession = topicConnection.createTopicSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);
        if (jmsConnectionCfg.getReceiveConditionsFilter() == null) {
          recv = topicSession.createSubscriber(topic);
        } else {
          recv = topicSession.createSubscriber(topic, jmsConnectionCfg.getReceiveConditionsFilter(), false);
        }
        recv.setMessageListener(this);
        topicConnection.start();
        connection = topicConnection;
      } catch (javax.jms.JMSException e) {
        logger.error("Cant create the connection...");
        logger.error(e);
      } catch (javax.naming.NamingException e) {
        logger.error("Cant get naming connection.");
        logger.error(e);
        try {
          ctx.close();
        } catch (javax.naming.NamingException ex) {
          logger.error(ex);
        }
        ctx = null;
        try {
          JNISleep.sleep(5000);
        } catch (InterruptedException ex) {
          logger.error(ex);
        }
      }
    } else {
      try {
        final QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup(jmsConnectionCfg.getConnectionFactory());
        final Queue queue = (Queue) ctx.lookup(jmsConnectionCfg.getTopicQueueName());
        final QueueConnection queueConnection = factory.createQueueConnection(user, pass);
        QueueSession queueSession;
        QueueReceiver recv;

        queueConnection.setExceptionListener(this);
        queueSession = queueConnection.createQueueSession(true, javax.jms.Session.AUTO_ACKNOWLEDGE);
        recv = queueSession.createReceiver(queue);
        recv.setMessageListener(this);
        queueConnection.start();
        connection = queueConnection;
      } catch (javax.jms.JMSException e) {
        logger.error("Cant create the connection...");
        logger.error(e);
      } catch (javax.naming.NamingException e) {
        logger.error("Cant get naming connection.");
        logger.error(e);
        try {
          ctx.close();
        } catch (javax.naming.NamingException ex) {
          logger.error(ex);
        }
        ctx = null;
        try {
          JNISleep.sleep(5000);
        } catch (InterruptedException ex) {
          logger.error(ex);
        }
      }
    }

    if (connection != null) {
      final JMSSubscriberState state = new JMSSubscriberState();
      cancelConnectionTimer();

      logger.log("JMS CONNECTION " + communicationName + " STABLISHED");
      state.setState(JMSSubscriberState.CONNECTED);
      state.setNumCom(subscriberNumber);
      state.setName(communicationName);
      notificarInformacion(state, null, true, 1);
    }
  }

  /**
   * Notify a jms received message to appilcation logic.
   *
   * @param object The message to send to application logic.
   * @param message Original message received from jms bus. If is needed to nitify other message to application logic, this filed can be null.
   * @param crc Indicates if the message crc is correctly checked. This field only is valid if message is not null.
   * @param sequence The subtraction of the actual message sequence and the last message sequence. If the message is old is discarted and not notify to the
   * application logic. if sequence is 1 no actions about sequence is done.
   */
  protected void notificarInformacion(Object object, Message message, boolean crc, long sequence) {
    try {
      if (sequence < 1L) {
        logger.log("Sequence error, message discarted: " + sequence);
      } else if (!crc) {
        logger.log("CRC error, message discarted");
      } else {
        queue_reception.insertar(object);
        logger.info("message received successfully");
      }
    } catch (util.ColaLlenaException cle) {
      logger.error("The recieved message queue is FULL.");
      logger.error(cle);
    }

    try {
      if (!crc && (relatedPublisher != null) && (message != null) && (object != null) && (object instanceof JMSMessage) && !message.getJMSRedelivered()) {
        final JMSMessage jmsMessage = (JMSMessage) object;
        final String messageType = message.getStringProperty(JMSInterface.PROPERTY_MESSAGETYPE);

        logger.log("Incorrect CTC, Check if resend request is needed for message type: " + messageType);
        if (jmsConnectionCfg.isResendObject(messageType)) {
          relatedPublisher.sendMessageRequestResend(message, jmsMessage.getOrigin());
        } else {
          logger.log("The message type is not configured to be resended");
        }
      }

      if ((sequence != 1) && (relatedPublisher != null) && (message != null)) {
        final String messageType = message.getStringProperty(JMSInterface.PROPERTY_MESSAGETYPE);
        final JMSMessage jmsMessage = (JMSMessage) object;

        logger.log("Incorrect sequence, Check if reconnection is needed for message type: " + messageType);
        if (jmsConnectionCfg.isReconnectionObject(messageType)) {
          jmsReconnection();
        } else {
          logger.log("The message type is not configured for reconnections");
        }
      }
    } catch (JMSException jmse) {
      logger.log("Can obtain the type or message redelivered property to check the reconnection or resend.");
      logger.error(jmse);
    }
  }

  /**
   * Cancel the connection timer.
   */
  private void cancelConnectionTimer() {
    if (timer != null) {
      timer.cancel();
      timer = null;
      task = null;
    }
  }

  /**
   * Stop the jms connection and inform with a Disconnected state.
   */
  private void finalizeConnection() {
    final JMSSubscriberState subscriberState = new JMSSubscriberState();
    logger.log("Clossing connection ...");

    cancelConnectionTimer();
    if (connection != null) {
      try {
        connection.close();
      } catch (JMSException e1) {
        logger.error("Cant make connection close");
        logger.error(e1);
      }
    }
    if (ctx != null) {
      try {
        ctx.close();
      } catch (NamingException e1) {
        logger.error("Cant make context close");
        logger.error(e1);
      }
    }

    connection = null;
    ctx = null;
    logger.log("Subscriber " + communicationName + " connecion close.");
    subscriberState.setState(JMSSubscriberState.DISCONNECTED);
    subscriberState.setNumCom(subscriberNumber);
    subscriberState.setName(communicationName);
    notificarInformacion(subscriberState, null, true, 1);
  }

  /**
   * Stops the thread execution
   */
  void stopExecution() {
    cancelConnectionTimer();
    if (slaManager != null) {
      slaManager.stopExecution();
    }
    finalizeConnection();
  }

  /**
   * Method for obtaining the username to be used in this connection
   *
   */
  private String getUserName(JMSCfg jmsCfg) {
    if (jmsConnectionCfg.getUserName() != null && !jmsConnectionCfg.getUserName().equals("")) {
      return jmsConnectionCfg.getUserName();
    } else {
      return jmsCfg.getUserName();
    }
  }

  /**
   * Method for obtaining the password to be used in this connection
   *
   */
  private String getPassword(JMSCfg jmsCfg) {
    if (jmsConnectionCfg.getPassword() != null && !jmsConnectionCfg.getPassword().equals("")) {
      return jmsConnectionCfg.getPassword();
    } else {
      return jmsCfg.getPassword();
    }
  }
}
