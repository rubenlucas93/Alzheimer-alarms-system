/*
 * JMSSubscriberState.java
 *
 */
package JMS;

import java.io.Serializable;

/**
 * This classs store a jms subscription state
 */
public class JMSSubscriberState implements Serializable {

	/**
	 * Indicates that the connection is disconnected
	 */
	public final static int DISCONNECTED = 0;
	/**
	 * Indicates that the connection is connected
	 */
	public final static int CONNECTED = 1;
	/**
	 * The state of the connection
	 */
	private int state = 0;
	/**
	 * comunication number
	 */
	private int numCom = -1;
	/**
	 * Connection ID
	 */
	private String name = "";

	/**
	 * Cretes a new instance ofJMSSubscriberState
	 */
	public JMSSubscriberState() {
	}

	/**
	 * Get the subscriber connection current state
	 *
	 * @return subscriber connection current state
	 */
	public final int getState() {
		return state;
	}

	/**
	 * Set the publisher connection current state.
	 *
	 * @param subscriberState
	 *            publisher connection state
	 */
	public final void setState(int subscriberState) {
		state = subscriberState;
	}

	/**
	 * Get the publisher communication number.
	 *
	 * @return publisher communication number.
	 */
	public final int getNumCom() {
		return numCom;
	}

	/**
	 * Set the publisher communication number.
	 *
	 * @param num
	 *            publisher communication number.
	 */
	public final void setNumCom(int num) {
		numCom = num;
	}

	/**
	 * Get the publisher connection name.
	 *
	 * @return publisher connection name.
	 */
	public final String getName() {
		return name;
	}

	/**
	 * Set the publisher connection name.
	 *
	 * @param connectionName
	 *            publisher connection name.
	 */
	public final void setName(String connectionName) {
		name = (connectionName != null) ? connectionName : "";
	}
}
