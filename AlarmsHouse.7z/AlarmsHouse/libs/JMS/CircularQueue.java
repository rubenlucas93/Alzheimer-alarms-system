package JMS;

public class CircularQueue {

  private final int ONE_MINUTE = 60000;

  private long[] messagesQueue;

  private int firstPosition = 0;

  public CircularQueue(int size) {
    messagesQueue = new long[size];
  }

  public int getSize() {
    return messagesQueue.length;
  }

  public boolean addElement(long data) {
    boolean insert = false;
    long nextElement = getFirstElement();
    if (nextElement > -1) {
      /*Date date1 = new Date(data);
      Date date2 = new Date(nextElement);
      Date date3 = new Date(nextElement - 30000);
      DateFormat formatter = new SimpleDateFormat("HH:mm:ss.sss");
      System.out.println("-----------------------------------");
      System.out.println("Data --> " + formatter.format(date1));
      System.out.println("firstElement --> " + formatter.format(date2));
      System.out.println("firstElement - 30 --> " + formatter.format(date3));
      System.out.println("-----------------------------------");*/

      if (data - nextElement < ONE_MINUTE) {
        insert = false;
      } else {
        insert = true;
      }
    } else {
      insert = true;
    }
    if (insert) {
      messagesQueue[firstPosition] = data;
      firstPosition++;
      if (firstPosition == messagesQueue.length) {
        firstPosition = 0;
      }
    }
    return insert;
  }

  public long getFirstElement() {
    long result = -1;
    if (messagesQueue[firstPosition] > 0) {
      result = messagesQueue[firstPosition];
    }
    return result;
  }

  public long getElementAt(int position) {
    return messagesQueue[position];
  }

}
