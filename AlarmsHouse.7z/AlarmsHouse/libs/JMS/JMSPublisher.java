/*
 * JMSPublisher.java
 *
 */
package JMS;

import java.io.Serializable;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.JFrame;

import org.dom4j.io.XMLWriter;

import JMS.JMSmessages.messages.ADSMessage;
import JMS.JMSmessages.messages.Header;
import JMS.JMSmessages.messages.Life;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.DialogoInfo;
import util.CRC32;
import util.ColaLlenaException;
import util.SynchronizedQueue;
import JNI.JNISleep;
import JNI.JNITimer;
import JNI.JNITimerTask;

/**
 * Class that manages a publish connetion to jms.
 */
public class JMSPublisher extends Thread implements ExceptionListener {

  /**
   * Logger class manager.
   */
  private static final OCSLogger logger = OCSLoggerFactory.getLogger(JMSPublisher.class);

  /**
   * Data type to ask for a information resend.
   */
  private final String DATA_TYPE_RESEND = "Resend";

  /**
   * Store the sequence of each message types sended
   */
  private final HashMap<String, Long> sequenceTable = new HashMap<String, Long>();

  /**
   * Pendind messages to send queue
   */
  private SynchronizedQueue queue_pending2Send = null;

  /**
   * Queue for notification info to send to the class that manager the interface
   */
  private SynchronizedQueue queue_notifyInfo = null;

  /**
   * Publisher number
   */
  private final int publisherNumber;

  /**
   * JMS System Id. Used on the header of sended JMS messages
   */
  private String systemId = "";

  /**
   * Communication name
   */
  private String communicationName = null;

  /**
   * JMS connection configuration.
   */
  private JMSConnectionCfg jmsConnectionCfg = null;

  /**
   * Timer for connections
   */
  private JNITimer timer = null;

  /**
   * Task for communication timer.
   */
  private JNITimerTask task = null;

  /**
   * Publisher initial context
   */
  private InitialContext ctx = null;

  /**
   * JMS connection
   */
  private Connection connection = null;

  /**
   * JMS session
   */
  private Session session = null;

  /**
   * Topic publisher type (1 to N)
   */
  private TopicPublisher publisher = null;

  /**
   * Queue publisher type (1 to 1)
   */
  private QueueSender sender = null;

  /**
   * Indicates if the process must finalize or not.
   */
  private boolean finish = false;

  /**
   * Indicates if the class is doing a jms reconnection
   */
  protected boolean jmsReconnection = false;

  /**
   * Connection user
   */
  private String user = null;

  /**
   * Connection password
   */
  private String pass = null;

  /**
   * Store the messages sended to jms. Used if a resend is needed.
   */
  private final LinkedList<Message> sendedMessages = new LinkedList<Message>();

  /**
   * Creates a new instance of JMSPublisher
   *
   * @param number Publisher number
   * @param config JMS Connection configuration
   * @param jmsCfg JMS Publisher configuration
   * @param queue Notify meesages queue, this queue is for main program notifications.
   */
  public JMSPublisher(int number, JMSConnectionCfg config, JMSCfg jmsCfg, SynchronizedQueue queue) {
    super("JMSPublisher" + config.getCommunicationName());
    publisherNumber = number;
    systemId = jmsCfg.getSystemID();
    jmsConnectionCfg = config;
    user = getUserName(jmsCfg);
    pass = getPassword(jmsCfg);
    queue_notifyInfo = queue;

    if (jmsConnectionCfg != null) {
      communicationName = jmsConnectionCfg.getCommunicationName();
      queue_pending2Send = new SynchronizedQueue(jmsConnectionCfg.getReceptionQueueLenght());
      startTimerConnection();
      startThreads();
    } else {
      logger.error("Not exist any configuration for publisher number " + number);
    }
  }

  private void startThreads() {
    Life messageLife = new Life();
    messageLife.setOrigin(systemId);
    messageLife.setConnected(true);
    JMSMessage jmsMessage = new JMSMessage();
    jmsMessage.setObject(messageLife);
    jmsMessage.setMessageType("Life");
    jmsMessage.setDestination("ALL");
    jmsMessage.setOrigin(systemId);
    sendMessage(jmsMessage);
    new Thread(this, jmsConnectionCfg.getCommunicationName()).start();
  }

  /**
   * Start the timer to make a JMS Connetction
   */
  private void startTimerConnection() {
    if (timer == null) {
      try {
        timer = new JNITimer("startTimerConnection" + communicationName);
        task = new JNITimerTask() {
          @Override
          public void run() {
            startsCommunication();
          }
        };
        timer.schedule(task, 0, jmsConnectionCfg.getTimeoutConexion());
      } catch (Exception e) {
        logger.error("Cant create the connection timer " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Gets the topic or queue communication name
   *
   * @return topic or queue communication name
   */
  protected String getTopicQueueName() {
    return jmsConnectionCfg.getTopicQueueName();
  }

  /**
   * Try to connect to jms
   */
  private synchronized void startsCommunication() {
    if (jmsConnectionCfg != null) {
      obtainContext();
      if (ctx != null && connection == null) {
        initConnection();
      }
    }
  }

  /**
   * Init the connection statements depending if a topic or queue is configured.
   */
  private void initConnection() {
    try {
      if (jmsConnectionCfg.isTopic()) {
        TopicConnectionFactory factory = (TopicConnectionFactory) ctx.lookup(jmsConnectionCfg.getConnectionFactory());
        Topic topic = (Topic) ctx.lookup(jmsConnectionCfg.getTopicQueueName());
        TopicConnection topicConnection = factory.createTopicConnection(user, pass);
        TopicSession topicSession;

        topicConnection.setExceptionListener(this);
        topicSession = topicConnection.createTopicSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);
        publisher = topicSession.createPublisher(topic);
        if (jmsConnectionCfg.getPersistent()) {
          publisher.setDeliveryMode(DeliveryMode.PERSISTENT);
        } else {
          publisher.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        }
        topicConnection.start();
        connection = topicConnection;
        session = topicSession;
      } else {
        QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup(jmsConnectionCfg.getConnectionFactory());
        Queue queue = (Queue) ctx.lookup(jmsConnectionCfg.getTopicQueueName());
        QueueConnection queueConnection = factory.createQueueConnection(user, pass);
        QueueSession queueSession;

        queueConnection.setExceptionListener(this);
        queueSession = queueConnection.createQueueSession(true, javax.jms.Session.AUTO_ACKNOWLEDGE);
        sender = queueSession.createSender(queue);
        queueConnection.start();
        connection = queueConnection;
        session = queueSession;
      }
    } catch (javax.jms.JMSException e) {
      logger.error("Cant create the connection...");
//	  DialogoInfo info = new DialogoInfo(new JFrame(), true, "not connected to the server yet", true);
//	  info.dispose();
      logger.error(e);
    } catch (javax.naming.NamingException e) {
      logger.error("Cant get naming connection.");
//	  DialogoInfo info = new DialogoInfo(new JFrame(), true, "not connected to the server yet", true);
//	  info.dispose();
      logger.error(e);
      if (ctx != null) {
        try {
          ctx.close();
        } catch (javax.naming.NamingException ex) {
          logger.error(ex);
        }
      }
      ctx = null;
      try {
        JNISleep.sleep(5000);
      } catch (InterruptedException ex) {
        logger.error(ex);
      }
    }

    if (connection != null) {
      final JMSPublisherState state = new JMSPublisherState();
      cancelConnectionTimer();

      logger.log("JMS CONNECTION " + communicationName + " STABLISHED");
      state.setState(JMSPublisherState.CONNECTED);
      state.setNumCom(publisherNumber);
      state.setName(communicationName);
      state.setConditions(getReceiveConditionsFilter());
      notifyInformation(state);
    }
  }

  /**
   * Obtain the jms context
   */
  private synchronized void obtainContext() {
    try {
      Properties props = new Properties();
      props.put(InitialContext.INITIAL_CONTEXT_FACTORY, jmsConnectionCfg.getJndi());
      props.put(InitialContext.PROVIDER_URL, jmsConnectionCfg.getJmsProvider());
      props.put(InitialContext.SECURITY_PRINCIPAL, user);
      props.put(InitialContext.SECURITY_CREDENTIALS, pass);
      props.put(JMSConnectionCfg.SASL_POLICY_NOPLAINTEXT, jmsConnectionCfg.getSaslPolicyNoplainText());
//      props.put(JMSConnectionCfg.SASL_POLICY_NOPLAINTEXT, false);

      ctx = new InitialContext(props);
    } catch (javax.naming.NamingException e) {
      logger.error("Cant get the context for factory " + jmsConnectionCfg.getJndi() + " and provider " + jmsConnectionCfg.getJmsProvider());
      logger.error(e);
    }
  }

  /**
   * Cancel the connection timer
   */	
  private void cancelConnectionTimer() {
    if (timer != null) {
      timer.cancel();
      timer = null;
      task = null;
    }
  }

  /**
   * Stop the jms connection and inform with a Disconnected state.
   */
  private void finalizeConnection() {
    final JMSPublisherState publisherState = new JMSPublisherState();
    logger.log("Clossing connection ...");
//    DialogoInfo info = new DialogoInfo(new JFrame(), true, "SERVIDOR DESCONECTADO", true);
//    info.dispose();
    queue_pending2Send.vaciarCola();
    cancelConnectionTimer();
    if (sender != null) {
      try {
        sender.close();
      } catch (JMSException e) {
        logger.error("Cant make sender close");
        logger.error(e);
      }
    }
    if (publisher != null) {
      try {
        publisher.close();
      } catch (JMSException e) {
        logger.error("Cant make publisher close");
        logger.error(e);
      }
    }
    if (session != null) {
      try {
        session.close();
      } catch (JMSException e) {
        logger.error("Cant make session close");
        logger.error(e);
      }
    }
    if (connection != null) {
      try {
        connection.close();
      } catch (JMSException e1) {
        logger.error("Cant make connection close");
        logger.error(e1);
      }
    }
    if (ctx != null) {
      try {
        ctx.close();
      } catch (NamingException e1) {
        logger.error("Cant make context close");
        logger.error(e1);
      }
    }
    sender = null;
    publisher = null;
    session = null;
    connection = null;
    ctx = null;
    sequenceTable.clear();

    logger.log("Publisher " + communicationName + " connecion close.");
    publisherState.setState(JMSPublisherState.DISCONNECTED);
    publisherState.setNumCom(publisherNumber);
    publisherState.setName(communicationName);
    publisherState.setConditions(getReceiveConditionsFilter());
    notifyInformation(publisherState);
  }

  /**
   * Generates the header for a specific message to make a jms send
   *
   * @param object Object to send into the message
   * @param origin jms process origin id.
   * @param destination jms process destination id.
   * @return A specific jms header for the message.
   */
  private Header getMessageHeader(Object object, String origin, String destination) {
    final Header header = new Header();
    final String messageType = object.getClass().getName();
    final String key = origin + "_" + destination + "_" + messageType;
    final Long sequence = sequenceTable.get(key);
    final long newSequence = (sequence == null) || (sequence == Long.MAX_VALUE) ? 1L : (sequence.longValue() + 1);

    sequenceTable.put(key, new Long(newSequence));
    header.setSecNumber(newSequence);
    header.setOrigin(origin);
    header.setDestination(destination);
    header.setMessageType(messageType);
    header.setTimestamp(System.currentTimeMillis());

    return header;
  }

  /**
   * Process a object to convert in a standar message and send to JMS.
   *
   * @param object Object to send to jms
   */
  private void processMessage(Object object) {
    if ((object != null) && (object instanceof JMSMessage)) {
      final JMSMessage internalMessage = (JMSMessage) object;
      if (internalMessage.isEncapsulate()) {
        final ADSMessage message = new ADSMessage();
        final Object informacion = internalMessage.getObject();
        final Header header = getMessageHeader(informacion, internalMessage.getOrigin(), internalMessage.getDestination());

        message.setHeader(header);
        message.setInfo(informacion);
        if (jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("XML") == true) {
          sendXMLMessage(message, internalMessage.getOrigin(), internalMessage.getDestination(), internalMessage.getMessageType());
        } else if ((jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("Objeto") == true)
                || (jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("Object") == true)) {
          sendObjectMessage(message, internalMessage.getOrigin(), internalMessage.getDestination(), internalMessage.getMessageType());
        } else {
          logger.error("The message type configured for " + communicationName + " is not correcto, It must be XML or Objet");
        }
      } else {
        final Object message2Send = internalMessage.getObject();
        if (jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("XML") == true) {
          sendXMLMessageExternalSystem(message2Send);
        } else if ((jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("Objeto") == true)
                || (jmsConnectionCfg.getMessageTypes().equalsIgnoreCase("Object") == true)) {
          sendObjectMessageExternalSystem(message2Send);
        } else {
          logger.error("The message type configured for " + communicationName + " is not correcto, It must be XML or Objet");
        }
      }
    } else {
      logger.error("Trying to send a null message");
    }
  }

  /**
   * Send a message to jms.
   *
   * @param mensaje Object to send
   */
  public void sendMessage(Object mensaje) {
    try {
      queue_pending2Send.insertar(mensaje);
    } catch (ColaLlenaException e) {
      logger.error("The queue to send the message is full");
      logger.error(e);
    }
  }

  /**
   * Method that send a jms XML message with the crc attribute if necesary.
   *
   * @param atsMessage Message to send to jms.
   * @param origin Message origin ID
   * @param destination Message destination ID
   * @param messageType Message Type to send mensajeria.
   */
  private void sendXMLMessage(ADSMessage atsMessage, String origin, String destination, String messageType) {
    if ((atsMessage != null) && (session != null)) {
      try {
        final String text = transformaObjeto(atsMessage);

        if (text != null) {
          final Message message = session.createTextMessage(text);

          if (jmsConnectionCfg.isCheckCRC()) {
            final long crc = CRC32.getCRC(text);
            message.setStringProperty(JMSInterface.PROPERTY_CRC, Long.toHexString(crc));
          }

          try {
            if (messageType.lastIndexOf('.') != -1) {
              messageType = messageType.substring(messageType.lastIndexOf('.') + 1, messageType.length());
            }
          } catch (Exception e) {
            logger.error("The message type is not cut on the correct way " + messageType);
            logger.error(e);
          }
          message.setStringProperty(JMSInterface.PROPERTY_MESSAGETYPE, messageType);
          message.setStringProperty(JMSInterface.PROPERTY_DESTINY, destination);
          message.setStringProperty(JMSInterface.PROPERTY_ORIGIN, origin);

          if (messageType.equalsIgnoreCase(DATA_TYPE_RESEND)) {
            message.setJMSCorrelationID(atsMessage.getInfo().toString());
          }
          if (logger.isTraceEnabled()) {
            logger.trace("TX " + communicationName + ": " + text);
          }
          publish(message);
        }
      } catch (JMSException e) {
        logger.error("Publisher " + communicationName + ": Excepcion at sendXMLMessage " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Method that send a jms Object message with the crc attribute if necesary.
   *
   * @param atsMessage Message to send to jms.
   * @param origin Message origin ID
   * @param destination Message destination ID
   * @param messageType Message Type to send mensajeria.
   */
  private void sendObjectMessage(ADSMessage atsMessage, String origin, String destination, String messageType) {
    if ((atsMessage != null) && (session != null)) {
      try {
        final Message message = session.createObjectMessage(atsMessage);
        if (jmsConnectionCfg.isCheckCRC()) {
          long crc = CRC32.getCRC(atsMessage);
          message.setStringProperty(JMSInterface.PROPERTY_CRC, Long.toHexString(crc));
        }

        try {
          if (messageType.lastIndexOf('.') != -1) {
            messageType = messageType.substring(messageType.lastIndexOf('.') + 1, messageType.length());
          }
        } catch (Exception e) {
          logger.error("The message type is not cut on the correct way " + messageType);
          logger.error(e);
        }
        message.setStringProperty(JMSInterface.PROPERTY_MESSAGETYPE, messageType);
        message.setStringProperty(JMSInterface.PROPERTY_DESTINY, destination);
        message.setStringProperty(JMSInterface.PROPERTY_ORIGIN, origin);

        if (messageType.equalsIgnoreCase(DATA_TYPE_RESEND)) {
          message.setJMSCorrelationID(atsMessage.getInfo().toString());
        }

        if (logger.isTraceEnabled()) {
          final String text = transformaObjeto(atsMessage);
          logger.trace("TX " + communicationName + ": " + text);
        }
        publish(message);
      } catch (JMSException e) {
        logger.error("Publisher " + communicationName + ": Excepcion at sendObjectMessage " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Method that send a jms XML message with the crc attribute if necesary.
   *
   * @param objectMsg Message to send to jms.
   * @param messageType Message Type to send mensajeria.
   */
  private void sendXMLMessageExternalSystem(Object objectMsg) {
    if ((objectMsg != null) && (session != null)) {
      try {
        final String text = convertTextObjectToXML(objectMsg);

        if (text != null) {
          final Message message = session.createTextMessage(text);
          String packageName = objectMsg.getClass().getPackage().getName();
          String simpleClassName = objectMsg.getClass().getSimpleName();
          message.setStringProperty(JMSInterface.PROPERTY_XSD_CLASS, packageName + "." + simpleClassName);
          if (logger.isTraceEnabled()) {
            logger.trace("TX " + communicationName + ": " + text);
          }
          publish(message);
        }
      } catch (JMSException e) {
        logger.error("Publisher " + communicationName + ": Excepcion at sendXMLMessageExternalSystem " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Method that send a jms Object message to external systems Only to be used when sending a non JMSMessage to a JMS Interface
   *
   * @param objectMsg Message to send to jms.
   * @param messageType Message Type to send.
   */
  public void sendObjectMessageExternalSystem(Object objectMsg) {
    if ((objectMsg != null) && (session != null)) {
      try {
        final Message message = session.createObjectMessage((Serializable) objectMsg);
        if (logger.isTraceEnabled()) {
          final String text = transformaObjeto(objectMsg);
          logger.trace("TX " + communicationName + ": " + text);
        }
        publish(message);
      } catch (JMSException e) {
        logger.error("Publisher " + communicationName + ": Excepcion at sendObjectMessageExternalSystem " + e.getMessage());
        logger.error(e);
      }
    }
  }

  /**
   * Publish the JMS message
   *
   * @param message Message to publish
   */
  private void publish(Message message) {
    try {
      if (publisher != null) {
        publisher.publish(message);
      } else {
        sender.send(message);
      }
      storeMessageToResend(message);
    } catch (JMSException e) {
      logger.error(e);
      try {
        if (publisher != null) {
          publisher.publish(message);
        } else {
          sender.send(message);
        }
        storeMessageToResend(message);
      } catch (JMSException ex) {
        logger.error("Cant publish a message: " + ex.getMessage());
        logger.error(ex);
        jmsReconnection();
      }
    }
  }

  /**
   * Convert an object in a xml string to send as XML.
   *
   * @param object Object to transform a transformar.
   * @return XML Object String representation.
   */
  private String transformaObjeto(Object object) {
    String result = null;

    if (object != null) {
      try {
        final java.io.StringWriter writer = new java.io.StringWriter();
        final org.exolab.castor.xml.Marshaller marshaller = new org.exolab.castor.xml.Marshaller(writer);
        marshaller.setSuppressXSIType(true);
        marshaller.marshal(object);
        result = writer.toString();
      } catch (org.exolab.castor.xml.MarshalException e) {
        logger.error("Cant convert to xml string a message: " + e.getMessage());
        logger.error(e);
        result = null;
      } catch (org.exolab.castor.xml.ValidationException e) {
        logger.error("Cant validate a xml string message: " + e.getMessage());
        logger.error(e);
        result = null;
      } catch (java.io.IOException e) {
        logger.error("Cant create a marshaller to translate the object to xml message: " + e.getMessage());
        logger.error(e);
        result = null;
      }
    }

    return result;
  }

  /**
   * This function converts an object containing TextMessage inside into the XML.
   * @param objectToBeConverted object to be converted.
   * @return parse XML message in string format
   */
  public static String convertTextObjectToXML(final Object objectToBeConverted) {
    String information = null;

    if (objectToBeConverted instanceof String) {
      return (String) objectToBeConverted;
    }

    try {
      StringWriter stringWriter = new StringWriter();
      XMLWriter xmlWriter = new XMLWriter(stringWriter);
      xmlWriter.setEscapeText(false);
      final org.exolab.castor.xml.Marshaller marshaller = new org.exolab.castor.xml.Marshaller(xmlWriter);
      marshaller.setSuppressXSIType(true);
      marshaller.marshal(objectToBeConverted);
      information = stringWriter.toString();
    } catch (org.exolab.castor.xml.MarshalException marshalException) {
      logger.error("Unable to parse a message to string - " + marshalException.getMessage());
    } catch (org.exolab.castor.xml.ValidationException validationException) {
      logger.error("Unable to validate a message parsed to string" + validationException);
    } catch (java.io.IOException ioException) {
      logger.error("Unable to create the marshall to parse a message" + ioException);
    }
    return information;
  }

  /**
   * Main Thread that get the queued messages and send it to jms bus
   */
  @Override
  public void run() {
    while (!finish) {
      if (queue_pending2Send != null) {
        Object object;
        // To avoid send message before session initialization.
        while (session == null) {
          try {
            JNISleep.sleep(1000);
          } catch (InterruptedException e) {
            logger.error(e);
          }
        }
        object = queue_pending2Send.consumir();
        processMessage(object);
      }
    }
  }

  /**
   * Override method when a jms exception is thrown. At this case the jms connection will be reconnected.
   *
   * @param exception jms Exception.
   */
  @Override
  public void onException(JMSException exception) {
    logger.error("JMS Exception occurs " + exception.getMessage());
    logger.error(exception);
    jmsReconnection();
  }

  /**
   * Reconnects the jms connection.
   */
  public synchronized void jmsReconnection() {
    if (!jmsReconnection) {
      logger.log("Reconnecting to JBoss...");
      jmsReconnection = true;
      finalizeConnection();
      startTimerConnection();
      jmsReconnection = false;
    }
  }

  /**
   * Stops the Thread execution.
   */
  public synchronized void stopExecution() {
    finish = true;
    finalizeConnection();
  }

  /**
   * Send a notify message to the application logic
   *
   * @param object Object to send to the application logic
   */
  private void notifyInformation(Object object) {
    try {
      queue_notifyInfo.insertar(object);
    } catch (ColaLlenaException e) {
      logger.error("The notitication info queue is full.");
      logger.error(e);
    }
  }

  /**
   * Replace the LIFE* option by Life
   *
   */
  public void replaceLifeConditionsFilterOnlyOthers() {
    String conditions = jmsConnectionCfg.getReceiveConditionsFilter();
    if (conditions != null) {
      conditions = conditions.replaceAll("LIFE*", "LIFE");
      jmsConnectionCfg.setReceiveConditionsFilter(conditions);
    }
  }

  /**
   * Get the receive conditions filter string
   *
   * @return receive conditions filter String
   */
  public String getReceiveConditionsFilter() {
    return (";" + jmsConnectionCfg.getReceiveConditionsFilter() + ";");
  }

  /**
   * Store message to resend if necesary at future
   *
   * @param message Message to Store.
   */
  private void storeMessageToResend(Message message) {
    if (message != null) {
      final int sendQueueLenght = jmsConnectionCfg.getSendQueueLenght();

      if (sendQueueLenght > 0) {
        sendedMessages.addFirst(message);

        if (sendedMessages.size() > sendQueueLenght) {
          sendedMessages.removeLast();
        }
      }
    }
  }

  /**
   * Resend a message to a specific destination.
   *
   * @param messageId Message unique Id to resend
   * @param destination Identificador del sistema que pide el reenvio del mensaje.
   */
  protected void resendMessage(String messageId, String destination) {
    if ((messageId != null) && (destination != null)) {
      boolean resend = false;

      logger.log("Resendind a message id " + messageId + " to " + destination);
      try {
        for (int index = 0; !resend && (index < sendedMessages.size()); index++) {
          final Message message = sendedMessages.get(index);

          if (message.getJMSMessageID().equalsIgnoreCase(messageId)) {
            message.setStringProperty(JMSInterface.PROPERTY_DESTINY, destination);
            message.setStringProperty(JMSInterface.PROPERTY_REDELIVERED, "true");
            publish(message);
            resend = true;
            logger.log("Message id resend " + messageId);
          }

        }

        if (!resend) {
          logger.log("Mensaje id " + messageId + " not found at the store to resend");
        }
      } catch (JMSException jmse) {
        logger.error("Trying to resend a message " + jmse.getMessage());
        logger.error(jmse);
      }
    }
  }

  /**
   * Method to ask to the origin to resend a specific message
   *
   * @param message Received message that is wanted to be resended
   * @param destination Destination Id to ask for the message
   */
  protected void sendMessageRequestResend(Message message, String destination) {
    boolean requested = false;

    logger.log("Making a resend request to " + destination + " from " + systemId);
    try {
      if ((message != null) && (destination != null)) {
        final JMSMessage resendMessage = new JMSMessage();
        final String messageId = message.getJMSMessageID();

        resendMessage.setDestination(destination);
        resendMessage.setOrigin(systemId);
        resendMessage.setObject(messageId);
        resendMessage.setMessageType(DATA_TYPE_RESEND);
        processMessage(resendMessage);
        requested = true;
        logger.log("Resend request sended to messageId: " + messageId);
      }
    } catch (JMSException jmse) {
      logger.error(jmse);
    }

    if (!requested) {
      logger.log("Resend request not completed.");
    }
  }

  /**
   * Method for obtaining the username to be used in this connection
   *
   */
  private String getUserName(JMSCfg jmsCfg) {
    if (jmsConnectionCfg.getUserName() != null && !jmsConnectionCfg.getUserName().equals("")) {
      return jmsConnectionCfg.getUserName();
    } else {
      return jmsCfg.getUserName();
    }
  }

  /**
   * Method for obtaining the password to be used in this connection
   *
   */
  private String getPassword(JMSCfg jmsCfg) {
    if (jmsConnectionCfg.getPassword() != null && !jmsConnectionCfg.getPassword().equals("")) {
      return jmsConnectionCfg.getPassword();
    } else {
      return jmsCfg.getPassword();
    }
  }
}
