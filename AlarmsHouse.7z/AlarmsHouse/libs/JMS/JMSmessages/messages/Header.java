/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.2</a>, using an XML
 * Schema.
 * $Id$
 */

package JMS.JMSmessages.messages;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * The generic header of each message sended to JMS
 * 
 * @version $Revision$ $Date$
 */
public class Header implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Numeric sequence different for each publisher and message
     * type. Its objetive is check that any message is lost. It is
     * reset with each system initialization.
     */
    private long _secNumber = -1;

    /**
     * keeps track of state for field: _secNumber
     */
    private boolean _has_secNumber;

    /**
     * Milliseconds of message sended from 01-01-1970.
     */
    private long _timestamp = 0;

    /**
     * keeps track of state for field: _timestamp
     */
    private boolean _has_timestamp;

    /**
     * Message origin identifier
     */
    private java.lang.String _origin = "";

    /**
     * Message Type Unique Identifier
     */
    private java.lang.String _messageType = "";

    /**
     * Message destination identifier
     */
    private java.lang.String _destination;


      //----------------/
     //- Constructors -/
    //----------------/

    public Header() {
        super();
        setOrigin("");
        setMessageType("");
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteSecNumber(
    ) {
        this._has_secNumber= false;
    }

    /**
     */
    public void deleteTimestamp(
    ) {
        this._has_timestamp= false;
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;
        
        if (obj instanceof Header) {
        
            Header temp = (Header)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._secNumber != temp._secNumber)
                return false;
            if (this._has_secNumber != temp._has_secNumber)
                return false;
            if (this._timestamp != temp._timestamp)
                return false;
            if (this._has_timestamp != temp._has_timestamp)
                return false;
            if (this._origin != null) {
                if (temp._origin == null) return false;
                if (this._origin != temp._origin) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._origin);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._origin);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._origin); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._origin.equals(temp._origin)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._origin);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._origin);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin);
                    }
                }
            } else if (temp._origin != null)
                return false;
            if (this._messageType != null) {
                if (temp._messageType == null) return false;
                if (this._messageType != temp._messageType) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._messageType);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._messageType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._messageType); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._messageType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._messageType.equals(temp._messageType)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._messageType);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._messageType);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._messageType);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._messageType);
                    }
                }
            } else if (temp._messageType != null)
                return false;
            if (this._destination != null) {
                if (temp._destination == null) return false;
                if (this._destination != temp._destination) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._destination);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._destination);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._destination); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._destination); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._destination.equals(temp._destination)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._destination);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._destination);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._destination);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._destination);
                    }
                }
            } else if (temp._destination != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'destination'. The field
     * 'destination' has the following description: Message
     * destination identifier
     * 
     * @return the value of field 'Destination'.
     */
    public java.lang.String getDestination(
    ) {
        return this._destination;
    }

    /**
     * Returns the value of field 'messageType'. The field
     * 'messageType' has the following description: Message Type
     * Unique Identifier
     * 
     * @return the value of field 'MessageType'.
     */
    public java.lang.String getMessageType(
    ) {
        return this._messageType;
    }

    /**
     * Returns the value of field 'origin'. The field 'origin' has
     * the following description: Message origin identifier
     * 
     * @return the value of field 'Origin'.
     */
    public java.lang.String getOrigin(
    ) {
        return this._origin;
    }

    /**
     * Returns the value of field 'secNumber'. The field
     * 'secNumber' has the following description: Numeric sequence
     * different for each publisher and message type. Its objetive
     * is check that any message is lost. It is reset with each
     * system initialization.
     * 
     * @return the value of field 'SecNumber'.
     */
    public long getSecNumber(
    ) {
        return this._secNumber;
    }

    /**
     * Returns the value of field 'timestamp'. The field
     * 'timestamp' has the following description: Milliseconds of
     * message sended from 01-01-1970.
     * 
     * @return the value of field 'Timestamp'.
     */
    public long getTimestamp(
    ) {
        return this._timestamp;
    }

    /**
     * Method hasSecNumber.
     * 
     * @return true if at least one SecNumber has been added
     */
    public boolean hasSecNumber(
    ) {
        return this._has_secNumber;
    }

    /**
     * Method hasTimestamp.
     * 
     * @return true if at least one Timestamp has been added
     */
    public boolean hasTimestamp(
    ) {
        return this._has_timestamp;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;
        
        long tmp;
        result = 37 * result + (int)(_secNumber^(_secNumber>>>32));
        result = 37 * result + (int)(_timestamp^(_timestamp>>>32));
        if (_origin != null
               && !org.castor.util.CycleBreaker.startingToCycle(_origin)) {
           result = 37 * result + _origin.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_origin);
        }
        if (_messageType != null
               && !org.castor.util.CycleBreaker.startingToCycle(_messageType)) {
           result = 37 * result + _messageType.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_messageType);
        }
        if (_destination != null
               && !org.castor.util.CycleBreaker.startingToCycle(_destination)) {
           result = 37 * result + _destination.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_destination);
        }
        
        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'destination'. The field
     * 'destination' has the following description: Message
     * destination identifier
     * 
     * @param destination the value of field 'destination'.
     */
    public void setDestination(
            final java.lang.String destination) {
        this._destination = destination;
    }

    /**
     * Sets the value of field 'messageType'. The field
     * 'messageType' has the following description: Message Type
     * Unique Identifier
     * 
     * @param messageType the value of field 'messageType'.
     */
    public void setMessageType(
            final java.lang.String messageType) {
        this._messageType = messageType;
    }

    /**
     * Sets the value of field 'origin'. The field 'origin' has the
     * following description: Message origin identifier
     * 
     * @param origin the value of field 'origin'.
     */
    public void setOrigin(
            final java.lang.String origin) {
        this._origin = origin;
    }

    /**
     * Sets the value of field 'secNumber'. The field 'secNumber'
     * has the following description: Numeric sequence different
     * for each publisher and message type. Its objetive is check
     * that any message is lost. It is reset with each system
     * initialization.
     * 
     * @param secNumber the value of field 'secNumber'.
     */
    public void setSecNumber(
            final long secNumber) {
        this._secNumber = secNumber;
        this._has_secNumber = true;
    }

    /**
     * Sets the value of field 'timestamp'. The field 'timestamp'
     * has the following description: Milliseconds of message
     * sended from 01-01-1970.
     * 
     * @param timestamp the value of field 'timestamp'.
     */
    public void setTimestamp(
            final long timestamp) {
        this._timestamp = timestamp;
        this._has_timestamp = true;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * JMS.JMSmessages.messages.Header
     */
    public static JMS.JMSmessages.messages.Header unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (JMS.JMSmessages.messages.Header) Unmarshaller.unmarshal(JMS.JMSmessages.messages.Header.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
