/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.2</a>, using an XML
 * Schema.
 * $Id$
 */

package JMS.JMSmessages.messages;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * The object you want to publish to JMS.
 * 
 * @version $Revision$ $Date$
 */
public class ADSMessage implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The generic header of each message sended to JMS
     */
    private JMS.JMSmessages.messages.Header _header;

    /**
     * Contiene la informacion especifica a enviar por la mensajeria
     */
    private java.lang.Object _info;


      //----------------/
     //- Constructors -/
    //----------------/

    public ADSMessage() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;
        
        if (obj instanceof ADSMessage) {
        
            ADSMessage temp = (ADSMessage)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._header != null) {
                if (temp._header == null) return false;
                if (this._header != temp._header) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._header);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._header);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._header); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._header); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._header.equals(temp._header)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._header);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._header);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._header);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._header);
                    }
                }
            } else if (temp._header != null)
                return false;
            if (this._info != null) {
                if (temp._info == null) return false;
                if (this._info != temp._info) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._info);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._info);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._info); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._info); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._info.equals(temp._info)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._info);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._info);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._info);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._info);
                    }
                }
            } else if (temp._info != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'header'. The field 'header' has
     * the following description: The generic header of each
     * message sended to JMS
     * 
     * @return the value of field 'Header'.
     */
    public JMS.JMSmessages.messages.Header getHeader(
    ) {
        return this._header;
    }

    /**
     * Returns the value of field 'info'. The field 'info' has the
     * following description: Contiene la informacion especifica a
     * enviar por la mensajeria.
     * 
     * @return the value of field 'Info'.
     */
    public java.lang.Object getInfo(
    ) {
        return this._info;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;
        
        long tmp;
        if (_header != null
               && !org.castor.util.CycleBreaker.startingToCycle(_header)) {
           result = 37 * result + _header.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_header);
        }
        if (_info != null
               && !org.castor.util.CycleBreaker.startingToCycle(_info)) {
           result = 37 * result + _info.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_info);
        }
        
        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'header'. The field 'header' has the
     * following description: The generic header of each message
     * sended to JMS
     * 
     * @param header the value of field 'header'.
     */
    public void setHeader(
            final JMS.JMSmessages.messages.Header header) {
        this._header = header;
    }

    /**
     * Sets the value of field 'info'. The field 'info' has the
     * following description: Contiene la informacion especifica a
     * enviar por la mensajeria.
     * 
     * @param info the value of field 'info'.
     */
    public void setInfo(
            final java.lang.Object info) {
        this._info = info;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * JMS.JMSmessages.messages.ATSMessage
     */
    public static JMS.JMSmessages.messages.ADSMessage unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (JMS.JMSmessages.messages.ADSMessage) Unmarshaller.unmarshal(JMS.JMSmessages.messages.ADSMessage.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
