/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.2</a>, using an XML
 * Schema.
 * $Id$
 */

package JMS.JMSmessages.messages;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Message that is sent when the system has started
 * 
 * @version $Revision$ $Date$
 */
public class Running implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Indicates if the system is active
     */
    private boolean _active;

    /**
     * keeps track of state for field: _active
     */
    private boolean _has_active;

    /**
     * Milliseconds when the system has started from 01-01-1970.
     */
    private long _dateActive = 0;

    /**
     * keeps track of state for field: _dateActive
     */
    private boolean _has_dateActive;

    /**
     * Field _system.
     */
    private JMS.JMSmessages.messages.types.SystemType _system;


      //----------------/
     //- Constructors -/
    //----------------/

    public Running() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteActive(
    ) {
        this._has_active= false;
    }

    /**
     */
    public void deleteDateActive(
    ) {
        this._has_dateActive= false;
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;
        
        if (obj instanceof Running) {
        
            Running temp = (Running)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._active != temp._active)
                return false;
            if (this._has_active != temp._has_active)
                return false;
            if (this._dateActive != temp._dateActive)
                return false;
            if (this._has_dateActive != temp._has_dateActive)
                return false;
            if (this._system != null) {
                if (temp._system == null) return false;
                if (this._system != temp._system) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._system);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._system);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._system); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._system); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._system.equals(temp._system)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._system);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._system);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._system);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._system);
                    }
                }
            } else if (temp._system != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'active'. The field 'active' has
     * the following description: Indicates if the system is active
     * 
     * @return the value of field 'Active'.
     */
    public boolean getActive(
    ) {
        return this._active;
    }

    /**
     * Returns the value of field 'dateActive'. The field
     * 'dateActive' has the following description: Milliseconds
     * when the system has started from 01-01-1970.
     * 
     * @return the value of field 'DateActive'.
     */
    public long getDateActive(
    ) {
        return this._dateActive;
    }

    /**
     * Returns the value of field 'system'.
     * 
     * @return the value of field 'System'.
     */
    public JMS.JMSmessages.messages.types.SystemType getSystem(
    ) {
        return this._system;
    }

    /**
     * Method hasActive.
     * 
     * @return true if at least one Active has been added
     */
    public boolean hasActive(
    ) {
        return this._has_active;
    }

    /**
     * Method hasDateActive.
     * 
     * @return true if at least one DateActive has been added
     */
    public boolean hasDateActive(
    ) {
        return this._has_dateActive;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;
        
        long tmp;
        result = 37 * result + (_active?0:1);
        result = 37 * result + (int)(_dateActive^(_dateActive>>>32));
        if (_system != null
               && !org.castor.util.CycleBreaker.startingToCycle(_system)) {
           result = 37 * result + _system.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_system);
        }
        
        return result;
    }

    /**
     * Returns the value of field 'active'. The field 'active' has
     * the following description: Indicates if the system is active
     * 
     * @return the value of field 'Active'.
     */
    public boolean isActive(
    ) {
        return this._active;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'active'. The field 'active' has the
     * following description: Indicates if the system is active
     * 
     * @param active the value of field 'active'.
     */
    public void setActive(
            final boolean active) {
        this._active = active;
        this._has_active = true;
    }

    /**
     * Sets the value of field 'dateActive'. The field 'dateActive'
     * has the following description: Milliseconds when the system
     * has started from 01-01-1970.
     * 
     * @param dateActive the value of field 'dateActive'.
     */
    public void setDateActive(
            final long dateActive) {
        this._dateActive = dateActive;
        this._has_dateActive = true;
    }

    /**
     * Sets the value of field 'system'.
     * 
     * @param system the value of field 'system'.
     */
    public void setSystem(
            final JMS.JMSmessages.messages.types.SystemType system) {
        this._system = system;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * JMS.JMSmessages.messages.Running
     */
    public static JMS.JMSmessages.messages.Running unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (JMS.JMSmessages.messages.Running) Unmarshaller.unmarshal(JMS.JMSmessages.messages.Running.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
