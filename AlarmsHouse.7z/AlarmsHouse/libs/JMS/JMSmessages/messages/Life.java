/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.2</a>, using an XML
 * Schema.
 * $Id$
 */

package JMS.JMSmessages.messages;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Life messages to send to JMS for the different systems.
 * 
 * @version $Revision$ $Date$
 */
public class Life implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Message origin identifier
     */
    private java.lang.String _origin = "";

    /**
     * Indicate if system is connected
     */
    private boolean _connected;

    /**
     * keeps track of state for field: _connected
     */
    private boolean _has_connected;


      //----------------/
     //- Constructors -/
    //----------------/

    public Life() {
        super();
        setOrigin("");
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     */
    public void deleteConnected(
    ) {
        this._has_connected= false;
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;
        
        if (obj instanceof Life) {
        
            Life temp = (Life)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._origin != null) {
                if (temp._origin == null) return false;
                if (this._origin != temp._origin) {
                    thcycle=org.castor.util.CycleBreaker.startingToCycle(this._origin);
                    tmcycle=org.castor.util.CycleBreaker.startingToCycle(temp._origin);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(this._origin); };
                        if (!tmcycle) { org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._origin.equals(temp._origin)) {
                            org.castor.util.CycleBreaker.releaseCycleHandle(this._origin);
                            org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin);
                            return false;
                        }
                        org.castor.util.CycleBreaker.releaseCycleHandle(this._origin);
                        org.castor.util.CycleBreaker.releaseCycleHandle(temp._origin);
                    }
                }
            } else if (temp._origin != null)
                return false;
            if (this._connected != temp._connected)
                return false;
            if (this._has_connected != temp._has_connected)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'connected'. The field
     * 'connected' has the following description: Indicate if
     * system is connected
     * 
     * @return the value of field 'Connected'.
     */
    public boolean getConnected(
    ) {
        return this._connected;
    }

    /**
     * Returns the value of field 'origin'. The field 'origin' has
     * the following description: Message origin identifier
     * 
     * @return the value of field 'Origin'.
     */
    public java.lang.String getOrigin(
    ) {
        return this._origin;
    }

    /**
     * Method hasConnected.
     * 
     * @return true if at least one Connected has been added
     */
    public boolean hasConnected(
    ) {
        return this._has_connected;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;
        
        long tmp;
        if (_origin != null
               && !org.castor.util.CycleBreaker.startingToCycle(_origin)) {
           result = 37 * result + _origin.hashCode();
           org.castor.util.CycleBreaker.releaseCycleHandle(_origin);
        }
        result = 37 * result + (_connected?0:1);
        
        return result;
    }

    /**
     * Returns the value of field 'connected'. The field
     * 'connected' has the following description: Indicate if
     * system is connected
     * 
     * @return the value of field 'Connected'.
     */
    public boolean isConnected(
    ) {
        return this._connected;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'connected'. The field 'connected'
     * has the following description: Indicate if system is
     * connected
     * 
     * @param connected the value of field 'connected'.
     */
    public void setConnected(
            final boolean connected) {
        this._connected = connected;
        this._has_connected = true;
    }

    /**
     * Sets the value of field 'origin'. The field 'origin' has the
     * following description: Message origin identifier
     * 
     * @param origin the value of field 'origin'.
     */
    public void setOrigin(
            final java.lang.String origin) {
        this._origin = origin;
    }

    /**
     * Method unmarshal.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.siemens.ra.r9k.libs.common.jms.jmsInterface.messages.Life
     */
    public static JMS.JMSmessages.messages.Life unmarshal(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (JMS.JMSmessages.messages.Life) Unmarshaller.unmarshal(JMS.JMSmessages.messages.Life.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
