/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.2</a>, using an XML
 * Schema.
 * $Id$
 */

package JMS.JMSmessages.messages.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Hashtable;

/**
 * Indicates the type of system
 * 
 * @version $Revision$ $Date$
 */
public class SystemType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The ctc_server type
     */
    public static final int CTC_SERVER_TYPE = 0;

    /**
     * The instance of the ctc_server type
     */
    public static final SystemType CTC_SERVER = new SystemType(CTC_SERVER_TYPE, "ctc_server");

    /**
     * The alarm_manager type
     */
    public static final int ALARM_MANAGER_TYPE = 1;

    /**
     * The instance of the alarm_manager type
     */
    public static final SystemType ALARM_MANAGER = new SystemType(ALARM_MANAGER_TYPE, "alarm_manager");

    /**
     * Field _memberTable.
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type.
     */
    private final int type;

    /**
     * Field stringValue.
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private SystemType(final int type, final java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerate.Returns an enumeration of all possible
     * instances of SystemType
     * 
     * @return an Enumeration over all possible instances of
     * SystemType
     */
    public static java.util.Enumeration enumerate(
    ) {
        return _memberTable.elements();
    }

    /**
     * Method getType.Returns the type of this SystemType
     * 
     * @return the type of this SystemType
     */
    public int getType(
    ) {
        return this.type;
    }

    /**
     * Method init.
     * 
     * @return the initialized Hashtable for the member table
     */
    private static java.util.Hashtable init(
    ) {
        Hashtable members = new Hashtable();
        members.put("ctc_server", CTC_SERVER);
        members.put("alarm_manager", ALARM_MANAGER);
        return members;
    }

    /**
     * Method readResolve. will be called during deserialization to
     * replace the deserialized object with the correct constant
     * instance.
     * 
     * @return this deserialized object
     */
    private java.lang.Object readResolve(
    ) {
        return valueOf(this.stringValue);
    }

    /**
     * Method toString.Returns the String representation of this
     * SystemType
     * 
     * @return the String representation of this SystemType
     */
    public java.lang.String toString(
    ) {
        return this.stringValue;
    }

    /**
     * Method valueOf.Returns a new SystemType based on the given
     * String value.
     * 
     * @param string
     * @return the SystemType value of parameter 'string'
     */
    public static JMS.JMSmessages.messages.types.SystemType valueOf(
            final java.lang.String string) {
        java.lang.Object obj = null;
        if (string != null) {
            obj = _memberTable.get(string);
        }
        if (obj == null) {
            String err = "" + string + " is not a valid SystemType";
            throw new IllegalArgumentException(err);
        }
        return (SystemType) obj;
    }

}
