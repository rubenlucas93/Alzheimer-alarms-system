/*
 * JMSCfg.java
 *
 */
package JMS;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Hashtable;

import util.EncryptedProperties;
import util.UtilProperties;

/**
 * Manages the configuration for the JMS connections.
 */
final class JMSCfg {
  /**
  * The clss loader
  */
  private final ClassLoader classLoader;
  /**
   * Reception queue size
   */
  private int receptionQueueSize;
  /**
   * The system unique ID
   */
  private String systemID = null;
  /**
   * Username for JBoss 7 connections
   */
  private String userName = null;
  /**
   * Password for JBoss 7 connections
   */
  private String password = null;
  /**
   * Publishers configurations list
   */
  private final Hashtable<Integer, JMSConnectionCfg> publishersCfg = new Hashtable<Integer, JMSConnectionCfg>();
  /**
   * Suscribers configurations list
   */
  private final Hashtable<Integer, JMSConnectionCfg> subscribersCfg = new Hashtable<Integer, JMSConnectionCfg>();

  /**
   * Creates a new instance of JMSCfg
   *
   * @param configFilePath
   *            Config File Path of the JMS Configuration File.
   */
  protected JMSCfg(String configFilePath) {
    classLoader = this.getClass().getClassLoader();
    loadConfiguration(configFilePath);
  }

  /**
   * Loads de configurationj from the config file.
   *
   * @param configFilePath
   *            Config File Path of the JMS Configuration File.
   */
  private void loadConfiguration(String configFilePath) {
    final EncryptedProperties prop = new EncryptedProperties();

    try {
      prop.load(new java.io.FileInputStream(configFilePath));
    } catch (IOException e) {
      try {
        prop.load(classLoader.getResourceAsStream(configFilePath));
      } catch (IOException e1) {
        System.err.println("JMSCfg: cant load the configuration file " + configFilePath);
        System.exit(0);
      }
    }

    if (prop != null) {
      try {
        final int numPublicaciones = Integer.parseInt(prop.getProperty("npublic"));
        final int numSuscripciones = Integer.parseInt(prop.getProperty("nsuscrip"));

        systemID = UtilProperties.getPropertyML(prop, new String[] { "systemID", "idsistema" });
        if ((systemID != null) && (systemID.equalsIgnoreCase("hostname"))) {
          systemID = InetAddress.getLocalHost().getHostName();
        }
        userName = prop.getProperty("username", "userjms");
        password = prop.getProperty("password", "password_1");
        receptionQueueSize = Integer.parseInt(UtilProperties.getPropertyML(prop, new String[] { "reception_queue_size", "tamano_cola_recepcion" }));

        for (int i = 0; i < numPublicaciones; i++) {
          JMSConnectionCfg configuracion = new JMSConnectionCfg("public" + i, prop, systemID, false);
          publishersCfg.put(new Integer(i), configuracion);
        }
        for (int i = 0; i < numSuscripciones; i++) {
          JMSConnectionCfg configuracion = new JMSConnectionCfg("suscrip" + i, prop, systemID, true);
          subscribersCfg.put(new Integer(i), configuracion);
        }
      } catch (NumberFormatException e1) {
        System.err.println("JMSCfg ERROR: reading the config file " + configFilePath + ":" + e1.getMessage());
        System.exit(0);
      } catch (UnknownHostException e1) {
        System.err.println("JMSCfg ERROR: reading the config file " + configFilePath + ":" + e1.getMessage());
        System.exit(0);
      }
    }
  }

  /**
   * Get the number of configured publishers.
   *
   * @return Configured publishers number.
   */
  protected final int getPublishersCount() {
    return publishersCfg.size();
  }

  /**
   * Get the number of configured subscribers.
   *
   * @return Configured subscribers number.
   */
  protected final int getSubscribersCount() {
    return subscribersCfg.size();
  }

  /**
   * Get the Publishers Configuration list.
   *
   * @return The publishers configuration list.
   */
  protected final Hashtable<Integer, JMSConnectionCfg> getPublishersCfg() {
    return publishersCfg;
  }

  /**
   * Get the Subscribers Configuration list.
   *
   * @return The subscribers configuration list.
   */
  protected final Hashtable<Integer, JMSConnectionCfg> getSubscribersCfg() {
    return subscribersCfg;
  }

  /**
   * Get the System unique ID
   *
   * @return get the system ID.
   */
  protected final String getSystemID() {
    return systemID;
  }

  /**
   * Get the connection username
   *
   * @return the username string
   */
  protected final String getUserName() {
    return userName;
  }

  /**
   * Get the connection password
   *
   * @return the password string
   */
  protected final String getPassword() {
    return password;
  }

  /**
   * Set the SystemID.
   *
   * @param systemIdent
   *            New systemID
   */
  protected final void setIdSistema(String systemIdent) {
    systemID = systemIdent;
  }

  /**
   * Get the reception message queue size
   *
   * @return Reception queue message size.
   */
  protected final int getReceptionQueueSize() {
    return receptionQueueSize;
  }
}
