/*
 * JMSPublisherState.java
 *
 */
package JMS;

/**
 * Class that contains the related state information of a publisher jms.
 */
public class JMSPublisherState {

  /**
   * Constant to note that a publisher is disconnected
   */
  public final static int DISCONNECTED = 0;
  /**
   * Constant to note that a publisher is connected
   */
  public final static int CONNECTED = 1;
  /**
   * Contains the current publisher communication state
   */
  private int state = 0;
  /**
   * Comunication number
   */
  private int numCom = -1;
  /**
   * Connection name
   */
  private String name = "";
  /**
   * Name of the publisher conditions
   */
  private String conditions = "";

  /**
   * Creates a new instance of JMSPublisherState
   */
  public JMSPublisherState() {
  }

  /**
   * Get the publisher connection current state
   *
   * @return publisher connection current state
   */
  public final int getState() {
    return state;
  }

  /**
   * Set the publisher connection current state.
   *
   * @param publisherState
   *            publisher connection state
   */
  public final void setState(int publisherState) {
    state = publisherState;
  }

  /**
   * Get the publisher communication number.
   *
   * @return publisher communication number.
   */
  public final int getNumCom() {
    return numCom;
  }

  /**
   * Set the publisher communication number.
   *
   * @param num
   *            publisher communication number.
   */
  public final void setNumCom(int num) {
    numCom = num;
  }

  /**
   * Get the publisher connection name.
   *
   * @return publisher connection name.
   */
  public final String getName() {
    return name;
  }

  /**
   * Set the publisher connection name.
   *
   * @param connectionName
   *            publisher connection name.
   */
  public final void setName(String connectionName) {
    name = (connectionName != null) ? connectionName : "";
  }

  /**
   * Get the name of publisher conditions
   * 
   * @ return Name of the conditions.
   */
  public final String getConditions() {
    return conditions;
  }

  /**
   * Set the name of the publisher conditions
   * 
   * @param conditionNames Name of the conditions.
   */
  public final void setConditions(String conditionNames) {
    conditions = (conditionNames != null) ? conditionNames : "";
  }

}
