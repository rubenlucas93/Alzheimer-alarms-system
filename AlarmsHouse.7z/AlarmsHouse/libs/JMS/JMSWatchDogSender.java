/*
 * JMSWatchDogSender.java
 *
 * Created on 29 de abril de 2010, 18:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package JMS;

import JMS.JMSmessages.messages.Life;
import JNI.JNISleep;

/**
 * This class sends life message to jms each 5 seconds
 *
 * @author Rub�n
 */
public class JMSWatchDogSender extends Thread {

  /**
   * Publish class to send the life messages
   */
  private JMSPublisher publisher = null;

  /**
   * Watchdog send time
   */
  public final static long WATCHDOG_SEND_TIME = 5000;

  /**
   * Indicates if the watchdog send must finish
   */
  private final boolean finalize = false;

  /**
   * jms identifier
   */
  private String id = null;

  /**
   * Crea una instancia de la clase JMSWatchDogSender Creates a instance of JMSWatchDogSender
   *
   * @param pub Publisher to send the life messages
   * @param systemId jms id
   * @param publishconditions publish conditions.
   */
  public JMSWatchDogSender(JMSPublisher pub, String systemId, String publishconditions) {
    String upperConditions = publishconditions.toUpperCase();
    publisher = pub;
    id = systemId;
    if ((upperConditions.indexOf("VIDA") != -1) || (upperConditions.indexOf("LIFE") != -1)) {
      startThreads();
    }
  }

  private void startThreads() {
    new Thread(this, "JMSWatchDogSender").start();
  }

  /**
   * Main Thread execution
   */
  @Override
  public void run() {
    Life messageLife = new Life();
    messageLife.setOrigin(id);
    messageLife.setConnected(true);
    JMSMessage jmsMessage = new JMSMessage();
    jmsMessage.setObject(messageLife);
    jmsMessage.setMessageType("Life");
    jmsMessage.setDestination("ALL");
    jmsMessage.setOrigin(id);
    while (!finalize) {
      try {
        if (!publisher.jmsReconnection) {
          publisher.sendMessage(jmsMessage);
        }
        JNISleep.sleep(WATCHDOG_SEND_TIME);
      } catch (InterruptedException e) {
      }
    }
  }
}
