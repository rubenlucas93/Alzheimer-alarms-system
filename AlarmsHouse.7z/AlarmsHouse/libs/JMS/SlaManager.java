package JMS;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import JNI.JNISleep;

public class SlaManager extends Thread {

  /**
   * Logger class manager.
   */
  private static final OCSLogger logger = OCSLoggerFactory.getLogger(SlaManager.class);

  private final int THIRTY_SECONDS = 30000;

  private final int ONE_MINUTE = 60000;

  private CircularQueue circularQueue;

  private JMSSubscriber subscriber;

  private JMSConnectionCfg jmsConnectionCfg;

  private boolean banned = false;

  private boolean finish = false;

  private String systemID;

  public SlaManager(JMSConnectionCfg jmsConnectionCfg, JMSSubscriber subscriber, String systemID) {
    this.jmsConnectionCfg = jmsConnectionCfg;
    this.subscriber = subscriber;
    this.systemID = systemID;
    circularQueue = new CircularQueue(jmsConnectionCfg.SLA_MessagesPerMinute());
    startThreads();
  }

  public boolean newMessage(long date) {
    if (!banned) {
      if (!circularQueue.addElement(date)) {
        banned = true;
      }
    }
    return !banned;
  }

  private void startThreads() {
    new Thread(this, "SlaManager" + jmsConnectionCfg.getCommunicationName()).start();
  }

  /**
   * Main Thread execution
   */
  @Override
  public void run() {
    while (!finish) {
      if (banned) {
        final JMSSLAViolation slaViolation = new JMSSLAViolation();
        logger.log("JMS CONNECTION " + jmsConnectionCfg.getCommunicationName() + " SLA REACHED. SYSTEM WILL BE BANNED FOR 30 SECONDS");
        slaViolation.setState(JMSSLAViolation.DISCONNECTED);
        slaViolation.setName(jmsConnectionCfg.getCommunicationName());
        subscriber.notificarInformacion(slaViolation, null, true, 1);

        JMSMessage jmsMessage = new JMSMessage();
        jmsMessage.setObject(slaViolation);
        jmsMessage.setMessageType("JMSSLAViolation");
        jmsMessage.setDestination("ALL");
        jmsMessage.setOrigin(systemID);
        subscriber.getPublisher().sendMessage(jmsMessage);

        try {
          JNISleep.sleep(THIRTY_SECONDS);
        } catch (InterruptedException e) {
        }
        logger.log("JMS CONNECTION " + jmsConnectionCfg.getCommunicationName() + " SLA STARTED OVER. SYSTEM IS NOT BANNED ANYMORE");
        slaViolation.setState(JMSSLAViolation.CONNECTED);
        slaViolation.setName(jmsConnectionCfg.getCommunicationName());
        subscriber.notificarInformacion(slaViolation, null, true, 1);
        banned = false;
        jmsMessage = new JMSMessage();
        jmsMessage.setObject(slaViolation);
        jmsMessage.setMessageType("JMSSLAViolation");
        jmsMessage.setDestination("ALL");
        jmsMessage.setOrigin(systemID);
        subscriber.getPublisher().sendMessage(jmsMessage);
      } else {
        printSLA();
        try {
          JNISleep.sleep(THIRTY_SECONDS);
        } catch (InterruptedException e) {
        }
      }
    }
  }

  public void printSLA() {
    int rate = 0;
    long currentTime = System.currentTimeMillis();
    for (int i = 0; i < circularQueue.getSize(); i++) {
      if (circularQueue.getElementAt(i) != 0 && circularQueue.getElementAt(i) < currentTime && circularQueue.getElementAt(i) > currentTime - ONE_MINUTE) {
        rate++;
      }
    }
    logger.log("JMS CONNECTION " + jmsConnectionCfg.getCommunicationName() + " IS RECEIVING " + rate + " MESSAGES PER MINUTE");
  }

  /**
   * Stops the Thread execution.
   */
  public synchronized void stopExecution() {
    finish = true;
  }
}
