/*
 * JMSMessage.java
 *
 */
package JMS;

/**
 * Class to store the JMS messages
 */
public class JMSMessage implements java.io.Serializable {

	/**
	 * Message Object
	 */
	private Object object;
	/**
	 * Message origin jms Id
	 */
	private String origin;
	/**
	 * Message Type of the Object inside the message
	 */
	private String messageType = "";
	/**
	 * Message destination jms Id
	 */
	private String destination;
	/**
	 * Indicates if the crc check is activated
	 */
	private boolean crcStatus = true;
	/**
	 * Indicate if message should be encapsulated into a ATSMessage or not.
	 */
	private boolean encapsulate = true;

	/**
	 * Create a new Isntance of JMSMessage
	 */
	public JMSMessage() {
	}

	/**
	 * Get the origin jms message Id
	 *
	 * @return Origin jms message Id.
	 */
	public final String getOrigin() {
		return origin;
	}

	/**
	 * Set the origin jms message Id.
	 *
	 * @param originId
	 *            Origin jms message Id.
	 */
	public final void setOrigin(String originId) {
		origin = originId;
	}

	/**
	 * Get de destination jms message Id
	 *
	 * @return Destination jms message Id
	 */
	public final String getDestination() {
		return destination;
	}

	/**
	 * Set the destination jms message Id
	 *
	 * @param destinationID
	 *            Destination jms message Id.
	 */
	public final void setDestination(String destinationID) {
		destination = destinationID;
	}

	/**
	 * Get the message object
	 *
	 * @return Message Object.
	 */
	public final Object getObject() {
		return object;
	}

	/**
	 * Set the message Object.
	 *
	 * @param obj
	 *            the message object.
	 */
	public final void setObject(Object obj) {
		object = obj;
	}

	/**
	 * Get the message object type.
	 *
	 * @return message object type
	 */
	public final String getMessageType() {
		return messageType;
	}

	/**
	 * Set the message object type.
	 *
	 * @param type
	 *            message object type.
	 */
	public final void setMessageType(String type) {
		messageType = (type != null) ? type : "";
	}

	/**
	 * Get the crc activation check status
	 *
	 * @return TRUE if ctc is activated, false i.o.c.
	 */
	public final boolean getCRCStatus() {
		return (crcStatus);
	}

	/**
	 * Set the crc activation check status
	 *
	 * @param status
	 *            crc activation check status
	 */
	public final void setCRCStatus(boolean status) {
		crcStatus = status;
	}

	/**
	 * Check if the message is for encapsulate or not.
	 */
	public boolean isEncapsulate() {
		return encapsulate;
	}

	/**
	 * Set the encapsulate value for the message
	 *
	 * @param encapsulate
	 *            encapsulate value to set
	 */
	public void setEncapsulate(boolean encapsulate) {
		this.encapsulate = encapsulate;
	}

}
