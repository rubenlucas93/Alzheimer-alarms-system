/**
 * Log4jChangeWatcherService.java
 *
 * Created on Dec 16, 2013, 9:56:42 AM
 *
 * Copyright (c) Siemens AG 2013, All Rights Reserved, Confidential
 *
 */
package Logger.log4jspecific;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

import org.apache.log4j.PropertyConfigurator;

import JNI.JNISleep;

/**
 * This class wath OCSLogger config file to reload it on modifications.
 *
 * @author miki
 */
public class Log4jWatcherService implements Runnable {

	/**
	 * Configuration file name.
	 */
	private String configFileName = null;
	/**
	 * Full path to config file.
	 */
	private String fullFilePath = null;

	/**
	 * Create new instance for Log4jWatcherService.
	 *
	 * @param filePath
	 *            Path file to the config file to watch.
	 */
	public Log4jWatcherService(final String filePath) {
		this.fullFilePath = filePath;
	}

	/**
	 * This method will be called each time the log4j configuration is changed
	 *
	 * @param file
	 *            Config file path change
	 */
	public void configurationChanged(final String file) {
		System.out
				.println("Log4jWatcherService configuration file changed. Reloading logging levels !!");
		PropertyConfigurator.configure(file);
	}

	/**
	 * Thread main run process.
	 */
	@Override
	public void run() {
		try {
			register(this.fullFilePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Register the file to wath.
	 *
	 * @param file
	 *            Path to the file to register.
	 * @throws IOException
	 *             Exception in case register fails.
	 */
	private void register(final String file) throws IOException {
		final int lastIndex = file.lastIndexOf("/");
		String dirPath = file.substring(0, lastIndex + 1);
		String fileName = file.substring(lastIndex + 1, file.length());
		this.configFileName = fileName;
		configurationChanged(file);
		startWatcher(dirPath, fileName);
	}

	/**
	 * Starts the watcher to a file.
	 *
	 * @param dirPath
	 *            Path dir to configuration file.
	 * @param file
	 *            File of configuration.
	 * @throws IOException
	 *             Exception in case startWatcher file.
	 */
	private void startWatcher(String dirPath, String file) throws IOException {
		final WatchService watchService = FileSystems.getDefault()
				.newWatchService();
		// Define the file and type of events which the watch service should
		// handle
		Path path = Paths.get(dirPath);
		path.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				try {
					watchService.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		WatchKey key;
		boolean continue_process = true;
		while (continue_process) {
			try {
				key = watchService.take();
				for (WatchEvent<?> event : key.pollEvents()) {
					if (event.context().toString().equals(configFileName)) {
						// From here the configuration change callback is
						// triggered
						configurationChanged(dirPath + file);
					}
				}
				boolean reset = key.reset();
				if (!reset) {
					System.out
							.println("Log4jWatcherService: Could not reset the watch key.");
					break;
				}
				JNISleep.sleep(5000);
			} catch (InterruptedException e) {
				System.out
						.println("Log4jWatcherService: InterruptedException: "
								+ e.getMessage());
				continue_process = false;
			} catch (Exception ignored) {
			}
		}
	}
}
