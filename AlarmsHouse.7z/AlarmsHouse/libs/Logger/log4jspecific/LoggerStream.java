/**
 * LoggerStream.java
 *
 * Created on Dec 18, 2013, 2:29:04 PM
 *
 * Copyright (c) Siemens AG 2013, All Rights Reserved, Confidential
 *
 */
package Logger.log4jspecific;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class redirects stderr to file
 *
 * @author miki
 */
public class LoggerStream extends OutputStream {

    /**
     * Logger clas to write.
     */
    private final Logger logger;
    /**
     * LogLevel to write stdout.
     */
    private final Level logLevel;
    /**
     * OutputStream to wirte data.
     */
    private final OutputStream outputStream;

    /**
     * Create a new instance of LoggerStream
     *
     * @param logger Logger to write messages
     * @param logLevel Log level to write messages
     * @param outputStream OutputStream to write messages
     */
    public LoggerStream(Logger logger, Level logLevel, OutputStream outputStream) {
        super();

        this.logger = logger;
        this.logLevel = logLevel;
        this.outputStream = outputStream;
    }

    /**
     * Write byte[] to the stderr
     *
     * @param b byte[] to write to
     * @throws IOException throw if write fails
     */
    @Override
    public void write(byte[] b) throws IOException {
        outputStream.write(b);
        String string = new String(b);
        if (!string.trim().isEmpty()) {
            logger.log(logLevel, string);
        }
    }

    /**
     * Write byte[] to the stderr
     *
     * @param b byte[] to write to
     * @throws IOException throw if write fails
     */
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        outputStream.write(b, off, len);
        String string = new String(b, off, len);
        if (!string.trim().isEmpty()) {
            logger.log(logLevel, string);
        }
    }

    /**
     * Write integer to the stderr
     *
     * @param b integer to write to
     * @throws IOException throw if write fails
     */
    @Override
    public void write(int b) throws IOException {
        outputStream.write(b);
        String string = String.valueOf((char) b);
        if (!string.trim().isEmpty()) {
            logger.log(logLevel, string);
        }
    }

    /**
     * Redirect the strderr to logger
     */
    public static void redirectErr() {
        System.setErr(new PrintStream(new LoggerStream(Logger.getLogger("SYSERR"), Level.INFO, System.out)));
    }

}
