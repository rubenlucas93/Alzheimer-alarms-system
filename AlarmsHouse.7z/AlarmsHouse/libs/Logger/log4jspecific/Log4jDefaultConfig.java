/*
 * Controlguide
 * Copyright (c) Siemens AG 2015, All Rights Reserved, Confidential
 */
package Logger.log4jspecific;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class Log4jDefaultConfig {

  private static final String CONVERSIONPATTERN = "%-7p %d [%t] %c %x - %m%n";
  private static final String DEFAULTDIR = "logs//logs.txt";
  private static final Level DEFAULTLEVEL = Level.INFO;

  private Log4jDefaultConfig() {
  }

  public static void setDefaultConfig() {
    PatternLayout layout = new PatternLayout();
    layout.setConversionPattern(CONVERSIONPATTERN);

    ConsoleAppender consoleAppender = new ConsoleAppender();
    consoleAppender.setLayout(layout);
    consoleAppender.activateOptions();

    FileAppender fileAppender = new FileAppender();
    fileAppender.setFile(DEFAULTDIR);
    fileAppender.setLayout(layout);
    fileAppender.activateOptions();

    Logger rootLogger = Logger.getRootLogger();
    rootLogger.setLevel(DEFAULTLEVEL);
    rootLogger.addAppender(consoleAppender);
    rootLogger.addAppender(fileAppender);
  }

}
