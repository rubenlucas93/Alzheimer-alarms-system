package Logger;


import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.MessageFormatter;

/**
 * CFOCSLog.java
 *
 * Created on Dec 13, 2013, 11:39:29 AM
 *
 * Copyright (c) Siemens AG 2013, All Rights Reserved, Confidential
 *
 */
/**
 * The class to manage cgocs logs!
 *
 * @author Rub�n
 */
public class OCSLogger {

  /**
   * slf4j logger class
   */
  private Logger logger = null;

  private String className = null;

  /**
   * Create a instance of OCSLogger
   *
   * @param c
   *            Reference log class
   */
  public OCSLogger(Class c) {
    className = c.getCanonicalName();
    logger = LoggerFactory.getLogger(c);
  }

  /**
   * Create a instance of OCSLogger
   *
   * @param c
   *            Reference log class name
   */
  public OCSLogger(String c) {
    className = c;
    logger = LoggerFactory.getLogger(c);
  }

  /**
   * Check if debug mode is enabled.
   *
   * @return TRUE if debug is enabled, FALSE e.o.c.
   */
  public boolean isDebugEnabled() {
    return (logger.isDebugEnabled());
  }

  /**
   * Check if info mode is enabled.
   *
   * @return TRUE if info is enabled, FALSE e.o.c.
   */
  public boolean isInfoEnabled() {
    return (logger.isInfoEnabled());
  }

  /**
   * Check if log mode is enabled.
   *
   * @return TRUE if log is enabled, FALSE e.o.c.
   */
  public boolean isLogEnabled() {
    return (isInfoEnabled());
  }

  /**
   * Check if trace mode is enabled.
   *
   * @return TRUE if trace is enabled, FALSE e.o.c.
   */
  public boolean isTraceEnabled() {
    return (logger.isTraceEnabled());
  }

  /**
   * Check if warn mode is enabled.
   *
   * @return TRUE if warn is enabled, FALSE e.o.c.
   */
  public boolean isWarnEnabled() {
    return (logger.isWarnEnabled());
  }

  /**
   * Check if error mode is enabled.
   *
   * @return TRUE if error is enabled, FALSE e.o.c.
   */
  public boolean isErrorEnabled() {
    return (logger.isErrorEnabled());
  }

  /**
   * Write a message to debug traces.
   *
   * @param message
   *            Message to write
   */
  public void debug(String message) {
    logger.debug(message);
    appendMessage(message);

  }

  /**
   * Write a message to debug traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void debug(String message, Object... args) {
    logger.debug(message, args);
    appendMessage(message, args);
  }

  /**
   * Write a message to info traces.
   *
   * @param message
   *            Message to write
   */
  public void info(String message) {
    logger.info(message);
    appendMessage(message);
  }

  /**
   * Write a message to info traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void info(String message, Object... args) {
    logger.info(message, args);
    appendMessage(message, args);
  }

  /**
   * Write a message to log traces.
   *
   * @param message
   *            Message to write
   */
  public void log(String message) {
    info(message);
  }

  /**
   * Write a message to log traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void log(String message, Object... args) {
    info(message, args);
  }

  /**
   * Write a message to trace traces.
   *
   * @param message
   *            Message to write
   */
  public void trace(String message) {
    logger.trace(message);
    appendMessage(message);
  }

  /**
   * Write a message to trace traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void trace(String message, Object... args) {
    logger.trace(message, args);
    appendMessage(message, args);
  }

  /**
   * Write a message to warn traces.
   *
   * @param message
   *            Message to write
   */
  public void warn(String message) {
    logger.warn(message);
    appendMessage(message);
  }

  /**
   * Write a message to warn traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void warn(String message, Object... args) {
    logger.warn(message, args);
    appendMessage(message, args);
  }

  /**
   * Write a message to error traces.
   *
   * @param message
   *            Message to write
   */
  public void error(String message) {
    logger.error(message);
    appendMessage(message);
  }

  /**
   * Write a message to error traces.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void error(String message, Object... args) {
    logger.error(message, args);
    appendMessage(message, args);
  }

  /**
   * Write a exception stack info to error traces.
   *
   * @param e
   *            Exception to write
   */
  public void error(Exception e) {
    logger.error(getException(e));
  }

  /**
   * Write a panic error and stop the process.
   *
   * @param message
   *            Message to write.
   */
  public void panicErrorExit(String message) {
    logger.error(message);
    appendMessage(message);
    logger.error("PANIC ERROR: PROCESS WILL BE STOPPED.");
    appendMessage(message);
    System.exit(-1);
  }

  /**
   * Write a panic error and stop the process.
   *
   * @param message Message to write
   * @param args optional arguments
   */
  public void panicErrorExit(String message, Object... args) {
    logger.error(message, args);
    appendMessage(message, args);
    logger.error("PANIC ERROR: PROCESS WILL BE STOPPED.");
    appendMessage(message, args);
    System.exit(-1);
  }

  private void appendMessage(String message) {
    if (OCSLoggerAppender.isActivated()) {
      OCSLoggerAppender.appendMessage(className, message);
    }
  }

  private void appendMessage(String message, Object... args) {
    if (OCSLoggerAppender.isActivated()) {
      String formattedMessage = MessageFormatter.arrayFormat(message, args).getMessage();
      appendMessage(formattedMessage);
    }
  }

  /**
   * Gets a text representation of a Exception
   *
   * @param e
   *            excepcion
   * @return Exception text message
   */
  private static String getException(Exception e) {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw, true);
    e.printStackTrace(pw);
    pw.flush();
    sw.flush();
    return (sw.toString());
  }

  /**
   * Delegate to the appropriate method of the underlying logger.
   */
  public String getName() {
    return logger.getName();
  }
}
