/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

import Logger.log4jspecific.Log4jWatcherService;
import Logger.log4jspecific.LoggerStream;

/**
 * This class manages the creation of OCSLogger for applications
 *
 * @author Rub�n
 */
public class OCSLoggerFactory {

  /**
   * OCSLoggerFactory instance class.
   */
  private final static OCSLoggerFactory INSTANCE = new OCSLoggerFactory();
  /**
   * CGOCS logger watcher services for config files reload on modifications.
   */
  private static Log4jWatcherService listener = null;
  /**
   * Class to write standard error to file
   */
  private static final OCSLogger stderr = getLogger("stderr");

  /**
   * Get a OCSLoggerFactory instance.
   *
   * @return OCSLoggerFactory class
   */
  public static OCSLoggerFactory getInstance() {
    return INSTANCE;
  }

  /**
   * Create a OCSLoggerFactory instance
   */
  public OCSLoggerFactory() {
    String filename = System.getProperty("OCSLog.properties");
    Properties p = new Properties();
    boolean initFile = false;
    try {
      p.load(new FileInputStream(filename));
      initFile = true;
    } catch (IOException | NullPointerException e) {
      System.err.println("ERROR: Cant initialice OCSLog correctly, path is [" + filename + "]");
      System.err.println("ERROR: Set VM argument OCSLog.properties to the log properties file.");
    }
    if (initFile) {
      PropertyConfigurator.configure(p);
      synchronized (OCSLoggerFactory.class) {
        if (listener == null) {
          listener = new Log4jWatcherService(filename);
          startThreads();
        }
      }
      System.out.println("INFO: OCSLog succesfully initialiced with file: " + filename);
    } else {
      System.err.println("INFO: OCSLog will take the current Logger config");
    }
  }

  /**
   * Launch class threads
   */
  private void startThreads() {
    new Thread(listener, "OCSLoggerWatcherService").start();
  }

  /**
   * Redirect the stderr to file.
   */
  public static void redirectStderr() {
    LoggerStream.redirectErr();
  }

  /**
   * Get a OCSLogger related to a class
   *
   * @param c
   *            related Class to log
   * @return OCSLogger for the class.
   */
  public static OCSLogger getLogger(Class c) {
    OCSLogger logger = new OCSLogger(c);
    return (logger);
  }

  /**
   * Get a OCSLogger related to a class name
   *
   * @param c
   *            related Class name to log
   * @return OCSLogger for the class name.
   */
  public static OCSLogger getLogger(String c) {
    OCSLogger logger = new OCSLogger(c);
    return (logger);
  }

}
