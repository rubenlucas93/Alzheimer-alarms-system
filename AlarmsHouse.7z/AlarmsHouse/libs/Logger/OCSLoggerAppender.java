/*
 * Controlguide
 * Copyright (c) Siemens AG 2015, All Rights Reserved, Confidential
 */
package Logger;

import java.util.HashMap;
import java.util.LinkedList;

public class OCSLoggerAppender {

  private static final int MAX_MESSAGES_PER_CLASS = 500;

  private static HashMap<String, LinkedList<String>> appenders = null;
  private static boolean activated = false;

  public synchronized static void activateAppender() {
    if (!activated) {
      appenders = new HashMap<String, LinkedList<String>>();
      activated = true;
    }
  }

  public synchronized static void clearAppender() {
    if (activated) {
      appenders = new HashMap<String, LinkedList<String>>();
      activated = true;
    }
  }

  public synchronized static boolean isActivated() {
    return (activated);
  }

  public synchronized static void appendMessage(String className, String message) {
    if (!appenders.containsKey(className)) {
      LinkedList<String> list = new LinkedList<String>();
      list.addLast(message);
      appenders.put(className, list);
    } else {
      appenders.get(className).addLast(message);
    }
    if (appenders.get(className).size() > MAX_MESSAGES_PER_CLASS) {
      appenders.get(className).removeFirst();
    }

  }

  public synchronized static String getFirst(Class<?> c) {
    return (getFirst(c.getCanonicalName()));
  }

  public synchronized static String getFirst(String className) {
    String result = null;
    if (appenders.containsKey(className) && (!appenders.get(className).isEmpty())) {
      result = appenders.get(className).removeFirst();
    }
    return (result);
  }

  public synchronized static boolean matchLog(Class<?> c, String message) {
    return (matchLog(c.getCanonicalName(), message));
  }

  public synchronized static boolean matchLog(String className, String message) {
    boolean result = false;
    boolean continueSearch = true;
    while (continueSearch) {
      String msg = getFirst(className);
      if (msg == null) {
        continueSearch = false;
      } else if (msg.equals(message)) {
        result = true;
        continueSearch = false;
      }
    }
    return (result);
  }

  public synchronized static boolean isInList(Class<?> c, String message) {
    return (isInList(c.getCanonicalName(), message));
  }

  public synchronized static boolean isInList(String className, String message) {
    boolean result = false;
    if (appenders.containsKey(className) && (!appenders.get(className).isEmpty())) {
      LinkedList<String> list = appenders.get(className);
      if (list.contains(message)) {
        result = true;
      }
    }
    return (result);
  }

  public synchronized static boolean clearClassNameLogs(Class<?> c) {
    return (clearClassNameLogs(c.getCanonicalName()));
  }

  public synchronized static boolean clearClassNameLogs(String className) {
    boolean result = false;
    if (appenders.containsKey(className) && (!appenders.get(className).isEmpty())) {
      appenders.get(className).clear();
    }
    return (result);
  }

  public synchronized static boolean matchSomeLogNoOrder(Class<?> c, String[] messageList) {
    return (matchSomeLogNoOrder(c.getCanonicalName(), messageList));
  }

  public synchronized static boolean matchSomeLogNoOrder(String className, String[] messageList) {
    boolean result = false;
    boolean continueSearch = true;
    for (int i = 0; (i < messageList.length) && continueSearch; i++) {
      String message = messageList[i];
      continueSearch = continueSearch && isInList(className, message);
    }
    if (continueSearch) {
      result = true;
    }
    return (result);
  }

}
