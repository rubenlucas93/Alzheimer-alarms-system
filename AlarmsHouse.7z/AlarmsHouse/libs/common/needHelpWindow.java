/*
 * DialogoInfo.java
 *
 * Created on 21 de abril de 2010, 15:23
 */

package common;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.ImageIcon;

import JMS.JMSInterface;
import RPIclient.communicationManager;
import common.messageTypes.RPImessage;
import util.UtilVentanas;

/**
 * Ventana dialogo de aviso
 *
 * @author operador
 */
public class needHelpWindow extends javax.swing.JDialog {

  /** Serial */
  private static final long serialVersionUID = -7994190136323325530L;

  /** Constant */
  private static final int CONSTANT10 = 10;

  /** Constant */
  private static final int CONSTANT20 = 20;
  
	private communicationManager comm;


  // </editor-fold>//GEN-END:initComponents
  // Variables declaration - do not modify//GEN-BEGIN:variables
  /** Java swing component */
  private javax.swing.JButton botonAceptar;

  /** Java swing component */
  private javax.swing.JButton botonCancelar;

  /** Java swing component */
  private javax.swing.JLabel etiqueta;

  /** Java swing component */
  private javax.swing.JPanel panelBotonera;
  // End of variables declaration//GEN-END:variables

  /**
   * Accion realizada.
   */
  private boolean accion = false;
  
  private ImageIcon icon;

//  private String iconPath = "C:\\Users\\Z003TXBU\\eclipse-workspace\\AlarmsHouse\\config\\cruz.jpg";
  private String iconPath = "/TFMconfig/cruz.JPG";


  /**
   * Indica si traducir mensaje.
   */
  private boolean traducir = true;

  private boolean SOSValue;
 
  private boolean fallAndMovement;

  private boolean fallAndNotMovement;

  private RPImessage sensorMsg;

  
  
  /**
   * Crea una nueva instancia de DialogoInfo
   *
   * @param parent ventana padre
   * @param modal indica si es modal
   * @param mensaje mensaje a mostrar
   * @param info indica si es informacion
 * @param comm 
   * @param idioma idioma de usuario
   * @param traducirMensaje indica si traducir mensaje
   */
  public needHelpWindow(javax.swing.JFrame parent, boolean modal, String mensaje, boolean info, communicationManager comm) {
    super(parent, modal);
    init(mensaje, info);
    this.comm=comm;
  }

  /**
   * Crea una nueva instancia de DialogoInfo
   *
   * @param parent ventana padre
   * @param modal indica si es modal
   * @param mensaje mensaje a mostrar
   * @param info indica si es informacion
   * @param idioma idioma de usuario
   * @param traducirMensaje indica si traducir mensaje
   */
  public needHelpWindow(javax.swing.JDialog parent, boolean modal, String mensaje, boolean info) {
    super(parent, modal);
    init(mensaje, info);
  }

  /**
   * Indica si se acepta la accion
   *
   * @return true si aceptado
   */
  public boolean estaAceptado() {
    return (accion);
  }

  /**
   * Inicializa la ventana
   *
   * @param mensaje
   * @param info
   * @param idioma
   */
  private void init(String mensaje, boolean info) {
    initComponents();
    initComponentsPersonalizados();
    if ((mensaje != null) && (mensaje.length() > 0)) {
      etiqueta.setText(mensaje);
      etiqueta.setVisible(true);
    } else {
      etiqueta.setVisible(false);
    }
    if (info) {
      botonCancelar.setVisible(false);
    }
    botonAceptar.requestFocus();
    setResizable(true);
    ponerIconos();
    cargarEventos();
    pack();
    setLocation(UtilVentanas.centrarDialogo(getSize()));
    this.setVisible(true);
  }

  /**
   * Inicializa los componentes personalizados
   *
   * @param idioma idioma de usuario
   */
  private void initComponentsPersonalizados() {
    botonAceptar.setText("AYUDA");
  }

  /**
   * Pne los iconos.
   */
  private void ponerIconos() {
    File file = new File(iconPath);
	if (file.exists()) {
	  icon = new ImageIcon(iconPath);
	} 
	    
    etiqueta.setIcon(icon);
  }
  
  private void needHelp() {
  	SOSValue=true;
  	fallAndMovement=false;
  	fallAndNotMovement=false;
  
    if(sensorMsg.constructMessage(fallAndMovement, SOSValue, fallAndNotMovement)) {
    	
	comm.sendinfo(sensorMsg);
    }
  }

  /**
   * Inicializa y carga la captura de los eventos realizados por el usuario sobre la ventana.
   */
  private void cargarEventos() {
    botonAceptar.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(java.awt.event.ActionEvent evt) {
        needHelp();
      }
    });
    botonAceptar.addKeyListener(new java.awt.event.KeyAdapter() {

      public void keyReleased(java.awt.event.KeyEvent evt) {
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
        	needHelp();
        }
      }
    });

  }

  /**
   * Accion de aceptar.
   */
  private void aceptarAction() {
    accion = true;
    setVisible(false);
  }

  /**
   * Accion de cancelar.
   */
  private void cancelarAction() {
    accion = false;
    setVisible(false);
  }

  /**
   * This method is called from within the constructor to initialize the form. WARNING: Do NOT modify this code. The content of this method is always
   * regenerated by the Form Editor.
   */
  // <editor-fold defaultstate="collapsed" desc="Generated
  // Code">//GEN-BEGIN:initComponents
  private void initComponents() {
    java.awt.GridBagConstraints gridBagConstraints;

    sensorMsg = new RPImessage(); 
    
    etiqueta = new javax.swing.JLabel();
    panelBotonera = new javax.swing.JPanel();
    botonAceptar = new javax.swing.JButton();

    setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
    getContentPane().setLayout(new java.awt.GridBagLayout());

    etiqueta.setText("jLabel1");
    etiqueta.setFont((new Font("Serif", Font.PLAIN, 30)));
    gridBagConstraints = new java.awt.GridBagConstraints();

    gridBagConstraints.insets = new java.awt.Insets(70, 70, 50, 50);
    
    getContentPane().add(etiqueta, gridBagConstraints);

    botonAceptar.setText("Aceptar");
    botonAceptar.setPreferredSize(new Dimension(140,40));
    botonAceptar.setBackground(Color.LIGHT_GRAY);
    panelBotonera.add(botonAceptar);

    gridBagConstraints = new java.awt.GridBagConstraints();
    gridBagConstraints.gridx = 0;
    gridBagConstraints.gridy = 1;
    gridBagConstraints.anchor = java.awt.GridBagConstraints.CENTER;
    gridBagConstraints.insets = new java.awt.Insets(CONSTANT10, CONSTANT10, CONSTANT10, CONSTANT10);
    getContentPane().add(panelBotonera, gridBagConstraints);
    
    this.getContentPane().setBackground(Color.white);
    
    setUndecorated(true);
    
    pack();
  }
}
