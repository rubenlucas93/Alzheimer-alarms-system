package common;

import static common.sensor.LOGGER;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.logging.Log;

import BBG.sensorManager;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;

public abstract class sensor {
   
	protected Float sensedInfo = (float) 0;
	private String accelerometerSensedInfo;
	private static Process proc;
    public static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(sensor.class);

	
	public void executeEnableIOPortCommand(String port) throws InterruptedException {
	    		try {
			
			String command = "echo " + port + " > " + " /sys/class/gpio/export";
	        // Similarly for this: "java -cp input\\master\\Kajari_G\\ MemoryComparison > output\\output1.txt" also           
	        proc = Runtime.getRuntime().exec(new String[] { "/bin/sh"//$NON-NLS-1$
	                , "-c", command });//$NON-NLS-1$
	        if (proc != null) {
	            proc.waitFor();
	        }
			
			LOGGER.info("IO Port " + port + " enabled");		
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	public void executeSetIODirection(String dir, String port) throws InterruptedException {
	    
		try {
			
			String command = "echo " + dir +" > " + "/sys/class/gpio/gpio"+port+"/direction";
	        // Similarly for this: "java -cp input\\master\\Kajari_G\\ MemoryComparison > output\\output1.txt" also           
	        proc = Runtime.getRuntime().exec(new String[] { "/bin/sh"//$NON-NLS-1$
	                , "-c", command });//$NON-NLS-1$
	        if (proc != null) {
	            proc.waitFor();
	        }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	
	}
	

	public String readAccelerometer(String port) throws IOException {
		Runtime rt = Runtime.getRuntime();
		String[] commands = {"/home/pi/gyro.py"};
		try {
			proc = rt.exec(commands);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BufferedReader stdInput = new BufferedReader(new 
		     InputStreamReader(proc.getInputStream()));

		BufferedReader stdError = new BufferedReader(new 
		     InputStreamReader(proc.getErrorStream()));

		// read the output from the command
		String s = null;
		if ((s = stdInput.readLine()) != null) {
			accelerometerSensedInfo=s;
			LOGGER.info(""+accelerometerSensedInfo);
			return accelerometerSensedInfo;
		}else {
			System.out.println("No se est� midiendo nada!");
			return "0.0; 0.0; 0.0";
		}
	}
	
	public Float readAnalogPort(String port) throws IOException {
	    
		Runtime rt = Runtime.getRuntime();
		String[] commands = {"cat", "/sys/devices/ocp.3/helper.12/AIN" + port};
		proc = rt.exec(commands);

		BufferedReader stdInput = new BufferedReader(new 
		     InputStreamReader(proc.getInputStream()));

		BufferedReader stdError = new BufferedReader(new 
		     InputStreamReader(proc.getErrorStream()));

		// read the output from the command
		String s = null;
		if ((s = stdInput.readLine()) != null) {
			sensedInfo=Float.valueOf(s);

			return sensedInfo;
		}else {
			System.out.println("No se est� midiendo nada!");
			return (float) 0.0;
		}
		
		// read any errors from the attempted command
//		while ((s = stdError.readLine()) != null) {
//		    System.out.println(s);
//		}

	}
	
		
		protected Float getHumDHT11(String port) throws IOException {
			Runtime rt = Runtime.getRuntime();

			String command = "/root/Adafruit_Python_DHT/examples/AdafruitDHThum.py 11 " + port;
	        proc = Runtime.getRuntime().exec(new String[] { "bash"//$NON-NLS-1$
	                , "-c", command });//$NON-NLS-1$
	        
			BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(proc.getInputStream()));

			// read the output from the command
			String s = null;
			if ((s = stdInput.readLine()) != null) {
				sensedInfo=Float.valueOf(s);
				LOGGER.info("hum -"+sensedInfo);
			}else {
				LOGGER.info("el hum sensor no se est� midiendo nada!");
			}

			return sensedInfo;
		}
		
		protected Float getTempDHT11(String port) throws IOException {
			Runtime rt = Runtime.getRuntime();
			String command = "/root/Adafruit_Python_DHT/examples/AdafruitDHTtemp.py 11 " + port;
	        proc = Runtime.getRuntime().exec(new String[] { "bash"//$NON-NLS-1$
	                , "-c", command });//$NON-NLS-1$
	        
			BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(proc.getInputStream()));

			// read the output from the command
			String s = null;
			if ((s = stdInput.readLine()) != null) {
				sensedInfo=Float.valueOf(s);
				LOGGER.info("temp -"+sensedInfo);
			}else {
				LOGGER.info("el temp sensor no se est� midiendo nada!");
			}
			
			return sensedInfo;
			
		}

    public Float readIOPort(String PORT) throws IOException {

    		Runtime rt = Runtime.getRuntime();
	        String[] commands = {"cat", "/sys/class/gpio/gpio"+PORT+"/value"};
			proc = rt.exec(commands);

			BufferedReader stdInput = new BufferedReader(new 
			     InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new 
			     InputStreamReader(proc.getErrorStream()));

			
			// read the output from the command
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sensedInfo=Float.valueOf(s);
			    LOGGER.info("movement -"+Float.valueOf(s));
			}

			return sensedInfo;
    	
    }
	
	public Float getSensedInfo() throws NumberFormatException, IOException {

    	return this.sensedInfo;
    
    }

    public void setSensedInfo(final Float value) {

    	this.sensedInfo = value;
  
    }

	public void run() {
		// TODO Auto-generated method stub
		
	}

    public static void enableAnalogPorts() throws InterruptedException {
		try {
			
			String command = "echo cape-bone-iio > /sys/devices/bone_capemgr.*/slots";
	        proc = Runtime.getRuntime().exec(new String[] { "bash"//$NON-NLS-1$
	                , "-c", command });//$NON-NLS-1$
	        
			BufferedReader stdInput = new BufferedReader(new 
				     InputStreamReader(proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new 
				     InputStreamReader(proc.getErrorStream()));
			
			String s = null;
			while ((s = stdInput.readLine()) != null) {
		    System.out.println(s);
			}
			while ((s = stdError.readLine()) != null) {
		    System.out.println(s);
			}
			
	        if (proc != null) {
	            proc.waitFor();
	        }

			LOGGER.info("Analogs Ports enabled");		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}

	public Float getSensedInfo(Integer i) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
