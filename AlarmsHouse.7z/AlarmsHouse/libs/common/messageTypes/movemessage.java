package common.messageTypes;

public class movemessage extends BBGmessage {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2217471158197482464L;

    public Boolean constructMessage(final Float move, final String roomID) {
    	this.setMovevalue(move);
        this.setRoom(roomID);
    	return true;
    	
    }
    
    
}
