package common.messageTypes;

public class RPIEsperMessage extends BBGEsperMessage {

	    private boolean fallvalue =  false;

	    private boolean SOSvalue = false;
	    
		private boolean fallNotMovevalue=false;

	    private long date;



		public long getDate() {
			return date;
		}

		public void setDate(long mills) {
			this.date = mills;
		}

		public boolean getSOSvalue() {
			return SOSvalue;
		}

		public void setSOSvalue(boolean SOS) {
			this.SOSvalue = SOS;
		}
		
		public boolean getFallvalue() {
			return fallvalue;
		}

		public void setFallvalue(boolean fall) {
			this.fallvalue = fall;
		}

		public boolean getFallNotMovevalue() {
			return fallNotMovevalue;
		}
		
		public void setFallNotMovevalue(boolean fallNotMovement) {
			this.fallNotMovevalue = fallNotMovement;
			
		}
	
}
