package common.messageTypes;

public class BBGEsperMessage {
    private Float gasvalue = (float) 0;

    private Float lightvalue = (float) 0;

    private Float tempvalue = (float) 0;

    private Float soundvalue = (float) 0;

    private Float movevalue = (float) 0;
	
    private Float humvalue= (float) 0;;

    private String room;

    private long date;



	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public long getDate() {
		return date;
	}

	public void setDate(long mills) {
		this.date = mills;
	}

	public Float getGasvalue() {
		return gasvalue;
	}

	public void setGasvalue(Float gasvalue) {
		this.gasvalue = gasvalue;
	}

	public Float getTempvalue() {
		return tempvalue;
	}

	public void setTempvalue(Float tempvalue) {
		this.tempvalue = tempvalue;
	}

	public Float getSoundvalue() {
		return soundvalue;
	}

	public void setSoundvalue(Float soundvalue) {
		this.soundvalue = soundvalue;
	}

	public Float getMovevalue() {
		return movevalue;
	}

	public void setMovevalue(Float movevalue) {
		this.movevalue = movevalue;
	}

	public Float getLightvalue() {
		return lightvalue;
	}

	public void setLightvalue(Float lightvalue) {
		this.lightvalue = lightvalue;
	}


	public Float getHumvalue() {
		return humvalue;
	}

	public void setHumvalue(Float humvalue) {
		this.humvalue = humvalue;
	}
}
