package common.messageTypes;

public class recordatorioEsperMessage{

	private String text="";

	private long date=0;
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public long getDate() {
		return date;
	}

	public void setDate(long fecha) {
		this.date = fecha;
	}
	
}
