package common.messageTypes;

public class eventMessage implements java.io.Serializable  {
	private int eventType= 0;
	private String extrainfo = "";
	private static final long serialVersionUID = 2217471158197122464L;


	public eventMessage(int type, String extraInfo) {
		eventType=type;
		this.extrainfo=extraInfo;
	}

	public int getEventType() {
		return eventType;
	}

	public String getExtraInfo() {
		return this.extrainfo;
	}
	
}
