package common.messageTypes;

public class moveEsperMessage extends BBGEsperMessage {

}
