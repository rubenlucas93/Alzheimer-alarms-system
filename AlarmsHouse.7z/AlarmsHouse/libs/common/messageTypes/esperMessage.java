package common.messageTypes;

public class esperMessage {

	public static esperMessage getObject() {
		// TODO Auto-generated method stub
		return null;
	}

	public String event;

}
