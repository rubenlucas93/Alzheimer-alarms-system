package common.messageTypes;

public class RecordatorioMessage implements java.io.Serializable  {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2217471158197482464L;

	private long date;
	private String recordatorio;



    public Boolean constructMessage(final String text) {
    	this.setRecordatorio(text);
    	return true;
    }



	public long getDate() {
		return date;
	}



	public void setDate(long date) {
		this.date = date;
	}



	public String getRecordatorio() {
		return recordatorio;
	}



	public void setRecordatorio(String text) {
		this.recordatorio = text;
	}
    
	

}
