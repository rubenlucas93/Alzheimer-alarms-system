package common.messageTypes;

public class RPImessage implements java.io.Serializable  {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2217471158197482464L;

	private boolean fallValue = false;
			
	private boolean SOSValue = false;

	private float moveValue = (float) 0.0;

	private boolean fallAndNotMovement;

	public boolean getSOSvalue() {
		return SOSValue;
	}

	public void setSOSvalue(boolean SOS) {
		this.SOSValue = SOS;
	}
	
	public boolean getFallvalue() {
		return fallValue;
	}

	public void setFallvalue(boolean fall) {
		this.fallValue = fall;
	}

    public Boolean constructMessage(final boolean fall, final boolean SOS, boolean fallAndNotMovement) {
    	this.setFallvalue(fall);
    	this.setSOSvalue(SOS);
    	this.setFallNotMoveValue(fallAndNotMovement);
    	return true;
    }
    
	private void setFallNotMoveValue(boolean fallAndNotMovement) {
		this.fallAndNotMovement = fallAndNotMovement;
		
	}

	public boolean getFallNotMoveValue() {
		// TODO Auto-generated method stub
		return this.fallAndNotMovement;
	}


}
