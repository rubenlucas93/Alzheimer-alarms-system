package common.messageTypes;

public class BBGmessage implements java.io.Serializable  {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2217471158197482464L;

	private Float gasvalue = (float) 110;

	private Float lightvalue = (float) 0;

	private Float tempvalue = (float) 0;

	private Float soundvalue = (float) 0;

	private Float movevalue = (float) 1;


    private String room;

	private Float humvalue= (float) 0;

    public String getRoom() {
        return this.room;
    }

    public void setRoom(final String value) {
        this.room = value;
    }

    public Boolean constructMessage(final Float move,  final Float lightvalue, final Float gas,final Float temp, Float humvalue, final Float sound,  final String roomID) {
    	this.setGasvalue(gas);
    	this.setTempvalue(temp);
    	this.setHumvalue(humvalue);
    	this.setMovevalue(move);
    	this.setSoundvalue(sound);
        this.setRoom(roomID);
        this.setLightvalue(lightvalue);
    	return true;
    }

	private void setHumvalue(Float humvalue) {
		this.humvalue = humvalue;
		
	}

	public Float getGasvalue() {
		return gasvalue;
	}

	public void setGasvalue(Float gasvalue) {
		this.gasvalue = gasvalue;
	}

	public Float getTempvalue() {
		return tempvalue;
	}

	public void setTempvalue(Float tempvalue) {
		this.tempvalue = tempvalue;
	}

	public Float getSoundvalue() {
		return soundvalue;
	}

	public void setSoundvalue(Float soundvalue) {
		this.soundvalue = soundvalue;
	}

	public Float getMovevalue() {
		return movevalue;
	}

	public void setMovevalue(Float movevalue) {
		this.movevalue = movevalue;
	}

	public Float getLightvalue() {
		return lightvalue;
	}

	public void setLightvalue(Float lightvalue) {
		this.lightvalue = lightvalue;
	}

	public Float getHumvalue() {
		return humvalue;
	}
	
}
