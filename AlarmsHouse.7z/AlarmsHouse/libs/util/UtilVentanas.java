/*
 * UtilVentanas.java
 *
 * Created on 20 de abril de 2010, 15:50
 *
 */
package util;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

/**
 * Utilidades de ventanas
 *
 * @author operador
 */
public class UtilVentanas {

  /**
   * Calcula el centro de la ventana para centrar
   *
   * @param dimVentana dimensiones de la ventana
   * @return punto central
   */
  public static Point centrarDialogo(Dimension dimVentana) {
    Toolkit prop = Toolkit.getDefaultToolkit();
    Dimension dim = prop.getScreenSize();
    int posX = (int) (dim.getWidth() / 2 - dimVentana.getWidth() / 2);
    int posY = (int) (dim.getHeight() / 2 - dimVentana.getHeight() / 2);
    Point punto = new Point(posX, posY);
    return (punto);
  }

  /**
   * Cambia el ancho de la columna indicada
   *
   * @param tabla Tabla sobre la que se realizara el cambio de ancho
   * @param numColumna numero de la columna
   * @param ancho nuevo ancho de columna
   */
  public static void cambiarAnchoColumna(JTable tabla, int numColumna, int ancho) {
    TableColumn columna = tabla.getColumnModel().getColumn(numColumna);
    columna.setPreferredWidth(ancho);
    columna.setResizable(true);
  }
}
