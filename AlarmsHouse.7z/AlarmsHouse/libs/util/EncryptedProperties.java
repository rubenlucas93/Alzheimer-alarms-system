package util;

import java.util.Properties;

/**
 * Class for work with properties encripted. Gives a relation between name of a property an their value
 */
public class EncryptedProperties extends Properties {

  /**
   * 
   */
  private static final long serialVersionUID = 5927008007229634192L;

  TextEncryptionService textEncryptionService = new TextEncryptionService();

  /**
   * Constructor
   */
  public EncryptedProperties() {
    super();
  }

  @Override
  public String getProperty(String key, String defaultValue) {

    String encryptedValue = super.getProperty(key, defaultValue);
    String plainValue = null;
    if (encryptedValue != null && encryptedValue.startsWith("ENC")) {
      encryptedValue = encryptedValue.substring(3);
      plainValue = textEncryptionService.decryptText(encryptedValue, Obkn.a());
    } else {
      plainValue = encryptedValue;
    }
    return plainValue;
  }

  @Override
  public String getProperty(String key) {

    String encryptedValue = super.getProperty(key);
    String plainValue = null;
    if (encryptedValue != null && encryptedValue.startsWith("ENC")) {
      encryptedValue = encryptedValue.substring(3);
      plainValue = textEncryptionService.decryptText(encryptedValue, Obkn.a());
    } else {
      plainValue = encryptedValue;
    }
    return plainValue;
  }

}
