/*
 * Encolado.java
 *
 * Created on 28 de noviembre de 2001, 16:20
 */
package util;

/**
 *
 */
public class Encolado {

    int i;
    String cadena;

    /**
     * Creates new Encolado
     *
     * @param cadena Cadena del elemento de pruebas
     */
    public Encolado(String cadena) {
        this.cadena = cadena;
    }

}
