/*
 * ColaNoElementException.java
 *
 * Created on 3 de diciembre de 2001, 12:37
 */
package util;

/**
 *
 */
public class ColaNoElementException extends ColaException {

    /**
     * Creates new <code>ColaNoElementException</code> without detail message.
     */
    public ColaNoElementException() {
    }

    /**
     * Constructs an <code>ColaNoElementException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public ColaNoElementException(String msg) {
        super(msg);
    }
}
