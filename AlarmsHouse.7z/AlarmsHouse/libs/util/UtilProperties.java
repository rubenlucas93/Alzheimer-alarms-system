/**
 * UtilProperties.java
 *
 * Created on Oct 1, 2013, 5:04:35 PM
 *
 * Copyright (c) Siemens AG 2013, All Rights Reserved, Confidential
 *
 */
package util;

import java.util.Properties;

/**
 * Common operations for UtilProperties files !!!!
 *
 * @author operador
 */
public class UtilProperties {

  /**
   * 
   * @param prop Properties
   * @param names Name of property to search
   * @param defaultValue Default value of property
   * @return
   */
  public static String getPropertyML(Properties prop, String[] names, String defaultValue) {
    String result = getPropertyML(prop, names);
    if (result == null) {
      result = defaultValue;
    }
    return (result);
  }

  /**
   * 
   * @param prop Properties
   * @param names Name of property to search
   * @return
   */
  public static String getPropertyML(Properties prop, String[] names) {
    String result = null;
    for (int i = 0; (i < names.length) && (result == null); i++) {
      result = prop.getProperty(names[i]);
    }
    return (result);
  }
}
