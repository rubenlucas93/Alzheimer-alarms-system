package util;

/**
 * 
 * @author Unknown
 *
 */
public final class Obkn {

  private static final int INT_1 = 1;

  private static final int INT_2 = 2;

  private static final int INT_3 = 3;

  private static final int INT_4 = 4;

  private static final int INT_5 = 5;

  private static final int INT_6 = 6;

  private static final int INT_7 = 7;

  private static final int INT_11 = 11;

  private static final int INT_12 = 12;

  private static final int INT_13 = 13;

  private static final int INT_14 = 14;

  private static final int INT_15 = 15;

  private static final int INT_17 = 17;

  private static final int INT_18 = 18;

  private static final int INT_19 = 19;

  private static final int INT_20 = 20;

  private static String b() {
    String s = (new StringBuilder()).append(Obka.a()[INT_20]).append(Obkb.a()[INT_20])
            .append(Obka.a()[INT_18]).append(Obkb.a()[INT_18])
            .append(Obka.a()[INT_15]).append(Obkb.a()[INT_15])
            .append(Obka.a()[INT_12]).append(Obkb.a()[INT_12])
            .append(Obka.a()[INT_13]).append(Obkb.a()[INT_5])
            .append(Obka.a()[INT_6]).append(Obkb.a()[INT_3])
            .append(Obka.a()[INT_6]).append(Obkb.a()[INT_3])
            .append(Obka.a()[INT_14]).append(Obkb.a()[INT_19])
            .append(Obka.a()[INT_11]).append(Obkb.a()[INT_11])
            .append(Obka.a()[INT_19]).append(Obkb.a()[INT_2])
            .append(Obka.a()[INT_1]).append(Obkb.a()[INT_14])
            .append(Obka.a()[INT_4]).append(Obkb.a()[INT_6])
            .append(Obka.a()[INT_5]).append(Obkb.a()[INT_13])
            .append(Obka.a()[INT_6]).append(Obkb.a()[INT_1])
            .append(Obka.a()[INT_7]).append(Obkb.a()[INT_2])
            .append(Obka.a()[INT_13]).append(Obkb.a()[INT_1]).toString();
    return s;
  }

  /**
   * 
   * @return
   */
  public static String a() {
    return b().replace(Obka.a()[INT_20], Obkb.a()[INT_17]);
  }
}
