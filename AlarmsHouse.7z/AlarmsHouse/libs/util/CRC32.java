/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import org.apache.commons.codec.binary.Base64;

/**
 * Implementa metodos para calcular un CRC a partir de un objeto determinado
 *
 */
public class CRC32 extends java.util.zip.CRC32 {

  /**
   * Obtiene el CRC para el mensaje(objeto).
   * @param mensaje Mensaje sobre el que se calcula su CRC
   * @return El CRC del objeto entrando o -1 en caso de <code>null</code>
   */
  public static long getCRC(Object mensaje) {
    final CRC32 crc = new CRC32();

    if (mensaje != null) {
      String textoCRC;

      if (mensaje instanceof String) {
        textoCRC = (String) mensaje;
      } else {
        textoCRC = objectToString(mensaje);
      }
      if (textoCRC != null) {
        crc.update(textoCRC.getBytes());
      }
    }

    return crc.getValue();
  }

  /**
   * Convierte un objeto java a texto para calcular su CRC.
   * @param obj Objeto que se desea transformar.
   * @return El string equivalente al objeto.
   */
  private static String objectToString(Object obj) {
    String out = null;

    if (obj != null) {
      try {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(obj);
        out = Base64.encodeBase64String(baos.toByteArray());
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    return out;
  }
}
