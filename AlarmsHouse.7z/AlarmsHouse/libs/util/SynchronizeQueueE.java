/*
 * Cola.java
 *
 * Created on 21 de octubre de 2002, 21:07
 */
package util;

/**
 *
 */
import java.util.LinkedList;

/**
 * ImplementaciXXXn de una cola sincronizada. Utilizada para resolver el problema
 * Productor-Consumidor. El objeto consumidor llamarXXX al mXXXtodo
 * <CODE>consumir</CODE> para obtener los elementos de la cola, quedando en
 * estado "dormido" en el caso de que no haya ningXXXn elemento. El objeto
 * productor insertarXXX elementos en la cola utilizado el mXXXtodo
 * <CODE>insertar</CODE> despertando al objeto consumidor si este se encuentra
 * dormido para que obtenga dicho objeto.
 */
public class SynchronizeQueueE<E> {

    /**
     * Almacen de los mensajes.
     */
    private LinkedList<E> cola;
    /**
     * Capacidad mXXXxima que puede tener la cola de mensajes.
     */
    private int capacidad;

    /**
     * Crea una nueva cola con una capacidad mXXXxima de almacenamiento.
     *
     * @param max_capacidad MXXXximo nXXXmero de objetos que se pueden almacenar en
     * la cola.
     */
    public SynchronizeQueueE(int max_capacidad) {
        cola = new LinkedList<E>();
        capacidad = max_capacidad;
    }

    /**
     * Inserta un nuevo elemento a la cola. Cuando se realiza la inserciXXXn se
     * comprueba si existe otro objeto en espera para obtener el elemento de la
     * cola y lo despierta.
     *
     * @param objeto Elemento que serXXX aXXXadido.
     * @throws ColaLlenaException si la cola estXXX llena. En este caso no se
     * aXXXade el elemento.
     */
    public synchronized void insert(E objeto) throws ColaLlenaException {
        if (cola.size() < capacidad) {
            cola.addLast(objeto);
        } else {
            throw new ColaLlenaException();
        }
        notify();
    }

    /**
     * Devuelve el elemento mXXXs antiguo de la cola y lo elimina. Si la cola estXXX
     * vacia, el objeto llamante se queda "dormido" a la espera de ser
     * despertado cuando otro objeto llame a la funciXXXn <CODE>insertar</CODE>
     *
     * @return El elemento mXXXs antiguo aXXXadido en la cola.
     */
    public synchronized E consumir() {
        E resultado;

        while (cola.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }

        resultado = cola.removeFirst();
        return resultado;
    }

    /**
     * Devuelve <CODE>true</CODE> si la cola no contiene ningXXXn elemento.
     *
     * @return <CODE>true</CODE> si la cola no contiene ningXXXn elemento.
     */
    public synchronized boolean isEmpty() {
        return cola.isEmpty();
    }

    /**
     * Elimina todos los elementos de la cola.
     */
    public synchronized void emptyQueue() {
        while (cola.isEmpty() == false) {
            cola.removeFirst();
        }
    }
}
