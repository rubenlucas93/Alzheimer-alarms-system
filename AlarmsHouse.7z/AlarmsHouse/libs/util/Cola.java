/*
 * Cola.java
 *
 * Created on 28 de noviembre de 2001, 16:15
 */
package util;

import java.util.Vector;

/**
 *
 */
public class Cola extends Vector {

    private boolean fColaBloqueada = false;
    private int tamano;

    /**
     * Creates new Cola
     *
     * @param tamaXXXo TamaXXXo de la cola
     */
    public Cola(int tamano) {
        super(tamano);
        this.tamano = tamano;
    }

    /**
     * MXXXtodo que devuelve el tmaXXXo de la cola
     *
     * @return TamaXXXo de la cola
     */
    public synchronized int tamano() {
        return size();
    }

    /**
     * Lee un elemento de la cola
     *
     * @param numElement NXXXmero de elemento
     * @throws ColaNoElementException GestiXXXn de errores
     * @return El elemento de la cola
     */
    public synchronized Object leerItem(int numElement) throws
            ColaNoElementException, ColaException {
        Object item;
        try {
            item = elementAt(numElement);
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ColaNoElementException("leerItem " + numElement
                    + "no en cola");
        } catch (Exception e) {
            throw new ColaException("leerItem Exception no controla " + e.getMessage());
        }
        return item;
    }

    /**
     * Borra un elemento de la cola
     *
     * @param numElement NXXXmero de elemento
     * @throws ColaNoElementException GestiXXXn de errores
     */
    public synchronized void borrarItem(int numElement) throws
            ColaNoElementException, ColaException {
        try {
            removeElementAt(numElement);
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ColaNoElementException("borrarItem " + numElement
                    + "no en cola");
        } catch (Exception e) {
            throw new ColaException("BorrarItem Exception no controla " + e.getMessage());
        }
    }

    /**
     * Borra un elemento de la cola
     *
     * @param numElement NXXXmero de elemento
     * @throws ColaNoElementException GestiXXXn de errores
     */
    public synchronized void borrarCola() {
        clear();
    }

    /**
     * AXXXade un elemento a la cola
     *
     * @param item Elemento que para aXXXadir en la cola
     * @throws ColaLlenaException GestiXXXn de errores
     */
    public synchronized void anadirItem(Object item) throws ColaLlenaException {
        if (size() < tamano) {
            addElement(item);
        } else {
            throw new ColaLlenaException();
        }
    }

    /**
     * MXXXtodo para bloquear el acceso a la cola
     *
     * @param modo Bloquear o desbloquear
     * @throws ColaBloqueadaException GestiXXXn de errores
     */
    public synchronized void bloquear(boolean modo) throws
            ColaBloqueadaException {
        if (modo == true) {
            /*Bloqueo la cola*/
            if (fColaBloqueada == true) {
                /*La cola ya estaba bloqueada*/
                throw new ColaBloqueadaException();
            } else {
                fColaBloqueada = true;
            }
        } else if (modo == false) {
            /*Desbloqueo la cola*/
            fColaBloqueada = false;
        }
    }

    /**
     * MXXXtodo que consulta si la cola esta bloqueada
     *
     * @return true o false segXXXn la cola estXXX bloqueada o no.
     */
    public synchronized boolean EstaBloqueada() {
        return fColaBloqueada;
    }

    /**
     * MXXXtodo que consulta si la cola esta bloqueada
     *
     * @return true o false segXXXn la cola estXXX bloqueada o no.
     */
    public synchronized int numElementos() {
        return elementCount;
    }
}
