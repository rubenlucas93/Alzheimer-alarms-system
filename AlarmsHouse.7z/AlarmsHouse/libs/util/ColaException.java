/*
 * ColaException.java
 *
 * Created on 3 de diciembre de 2001, 12:35
 */
package util;

/**
 *
 */
public class ColaException extends java.lang.Exception {

    /**
     * Creates new <code>ColaException</code> without detail message.
     */
    public ColaException() {
    }

    /**
     * Constructs an <code>ColaException</code> with the specified detail
     * message.
     *
     * @param msg the detail message.
     */
    public ColaException(String msg) {
        super(msg);
    }
}
