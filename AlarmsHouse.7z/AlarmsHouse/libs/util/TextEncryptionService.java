package util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Properties;

import org.jasypt.util.text.BasicTextEncryptor;
import org.jasypt.util.text.StrongTextEncryptor;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;

/**
 * 
 * @author Unknown
 *
 */
public class TextEncryptionService {

  /**
   * Logger class manager.
   */
  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(TextEncryptionService.class);

  /**
   * Strong encription
   * @param text Text to be encrypted
   * @param password Password of encryption
   * @return
   */
  public String encryptText(String text, String password) {

    StrongTextEncryptor textEncryptor = new StrongTextEncryptor();
    textEncryptor.setPassword(password);
    String myEncryptedText = textEncryptor.encrypt(text);

    return myEncryptedText;
  }

  /**
   * Decrypt strong
   * @param text Text to be decrypted
   * @param password Password of decryption
   * @return
   */
  public String decryptText(String text, String password) {

    StrongTextEncryptor textEncryptor = new StrongTextEncryptor();
    textEncryptor.setPassword(password);
    String plainText = textEncryptor.decrypt(text);

    return plainText;
  }

  /**
   * Basic encription
   * @param text Text to be encrypted
   * @param password Password of encryption
   * @return
   */
  public String encryptTextBasic(String text, String password) {

    BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
    textEncryptor.setPassword(password);
    String myEncryptedText = textEncryptor.encrypt(text);

    return myEncryptedText;
  }

  /**
   * Decrypt basic
   * @param text Text to be decrypted
   * @param password Password of decryption
   * @return
   */
  public String decryptTextBasic(String text, String password) {

    BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
    textEncryptor.setPassword(password);
    String plainText = textEncryptor.decrypt(text);

    return plainText;
  }

  /**
   * 
   * @param fileConfig name of file to be encrypted
   * @param parameters parameters to be encrypted
   * @param password password of encryption
   */
  public void encryptFileProperties(String fileConfig, ArrayList<String> parameters, String password) {

    final Properties config = new Properties();

    try {
      config.load(new FileInputStream(fileConfig));
      String valueToEncrypt = null;
      String valueEncrypted = null;

      for (String parameter : parameters) {

        if (config.containsKey(parameter)) {
          valueToEncrypt = config.getProperty(parameter);
          if (valueToEncrypt != null && !"".equals(valueToEncrypt)) {
            if (!valueToEncrypt.startsWith("ENC")) {
              valueEncrypted = encryptText(valueToEncrypt, password);
              config.put(parameter, "ENC" + valueEncrypted);
            } else {
              LOGGER.info("Parameter:" + parameter + " is already encrypted! It wonXXXt be encrypted again.");
            }
          } else {
            LOGGER.info("Parameter:" + parameter + " is not configured properly");
          }
        } else {
          LOGGER.info("Parameter:" + parameter + " is not present in properties");
        }
      }
      config.store(new FileOutputStream(fileConfig), "");

    } catch (Exception e) {
      LOGGER.error("Error ecrypting properties");
    }
  }
}
