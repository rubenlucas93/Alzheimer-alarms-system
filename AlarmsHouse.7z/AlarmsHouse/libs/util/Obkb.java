package util;

/**
 * 
 * @author Unknown
 *
 */
public class Obkb {

  private static final String A = "RTaiQmsPR56C2jJwVzTg7";

  /**
   * Default constructor
   */
  public Obkb() {
  }

  /**
   * 
   * @return Value of Obka
   */
  public static char[] a() {
    return Obka.b();
  }

  /**
   * 
   * @return Value of Obkb
   */
  public static char[] b() {
    return A.toCharArray();
  }

}
