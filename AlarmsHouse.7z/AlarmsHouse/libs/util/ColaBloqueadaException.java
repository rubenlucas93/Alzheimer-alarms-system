/*
 * ColaBloqueada.java
 *
 * Created on 3 de diciembre de 2001, 13:44
 */
package util;

/**
 *
 */
public class ColaBloqueadaException extends ColaException {

    /**
     * Creates new <code>ColaBloqueada</code> without detail message.
     */
    public ColaBloqueadaException() {
    }

    /**
     * Constructs an <code>ColaBloqueada</code> with the specified detail
     * message.
     *
     * @param msg the detail message.
     */
    public ColaBloqueadaException(String msg) {
        super(msg);
    }
}
