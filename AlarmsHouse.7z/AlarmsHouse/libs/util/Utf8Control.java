/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * <code>Utf8Control</code> This class implements the functionality for reading properties files in UTF8 character encoding instead the ISO-8859-1 used by Java.
 * @author Pilar Ollero
 */
public class Utf8Control extends ResourceBundle.Control {

  /**
   * Register the properties extension.
   */
  private static final String PROPERTIES_EXTENSION = "properties";

  /**
   * UTF-8 character encoding.
   */
  private static final String UTF_8 = "UTF-8";

  /**
   * Creates a new bundle.
   * @return <code>ResourceBundle</code>
   * @throws java.io.IOException
   * @see Control#newBundle(java.lang.String, java.util.Locale, java.lang.String, java.lang.ClassLoader, boolean)
   */
  @Override
  public ResourceBundle newBundle(String baseName, Locale locale,
    String format, final ClassLoader loader, boolean reload) throws IOException {
    ResourceBundle bundle = null;

    String bundleName = toBundleName(baseName, locale);
    final String resourceName = toResourceName(bundleName, PROPERTIES_EXTENSION);
    InputStream stream = null;
    if (!format.equals(ResourceBundle.Control.FORMAT_PROPERTIES.get(0))) {
      bundle = null;
    } else {
      try {
        stream = AccessController.doPrivileged(
                new PrivilegedExceptionAction<InputStream>() {
                  @Override
                  public InputStream run() throws IOException {
                    InputStream is = null;
                    if (loader != null) {
                      is = loader.getResourceAsStream(resourceName);
                    } else {
                      ClassLoader.getSystemResourceAsStream(resourceName);
                    }
                    return is;
                  }
                });
      } catch (PrivilegedActionException e) {
        throw (IOException) e.getException();
      }
      if (stream != null) {
        try {
          bundle = new PropertyResourceBundle(new InputStreamReader(stream, UTF_8));
        } finally {
          stream.close();
        }
      } else {
        throw new IllegalArgumentException("Unknown format: " + format);
      }
    }
    return bundle;
  }
}
