package util;

/**
 * 
 * @author Unknown
 *
 */
public class Obka {

  private static final String A = "asfIKlelafu32kdfQPbB6";

  /**
   * Default constructor
   */
  public Obka() {
  }

  /**
   * 
   * @return Value of Obkb
   */
  public static char[] a() {
    return Obkb.b();
  }

  /**
   * 
   * @return Value of Obka
   */
  public static char[] b() {
    return A.toCharArray();
  }

}
