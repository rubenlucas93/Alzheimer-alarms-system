/*
 * ColaLlenaException.java
 *
 * Created on 3 de diciembre de 2001, 12:36
 */
package util;

/**
 *
 */
public class ColaLlenaException extends ColaException {

    /**
     * Creates new <code>ColaLlenaException</code> without detail message.
     */
    public ColaLlenaException() {
    }

    /**
     * Constructs an <code>ColaLlenaException</code> with the specified detail
     * message.
     *
     * @param msg the detail message.
     */
    public ColaLlenaException(String msg) {
        super(msg);
    }
}
