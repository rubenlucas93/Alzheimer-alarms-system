package util;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.MqttSecurityException;

public class MQTTManager {

	public MqttClient client;
	
	public MQTTManager() throws MqttPersistenceException, MqttException {
		
//		client = new MqttClient("tcp://localhost:1883", MqttClient.generateClientId());
		client = new MqttClient("tcp://192.168.43.150:1883", MqttClient.generateClientId());

	
	}
	
	public void publish(String payload, String topic) throws MqttPersistenceException, MqttException  {
		MqttMessage message = new MqttMessage();
		message.setPayload(payload .getBytes());
		client.publish(topic , message);
	}
	
	public void consume(String topic) throws MqttException {
		client.setCallback( new SimpleMqttCallBack() );
		client.subscribe(topic);
	}
	
	public void connectClient() throws MqttSecurityException, MqttException {
		client.connect();
	}
	
	public void disconnectClient() throws MqttSecurityException, MqttException {
		client.disconnect();
	}
	
	
	


}
