/**
 * FilesDirCheck.java
 *
 * Created on Dec 17, 2013, 12:04:38 PM
 *
 * Copyright (c) Siemens AG 2013, All Rights Reserved, Confidential
 *
 */
package util.files;

import java.io.File;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;

/**
 * This class manage diferent check Files and Directories operations.
 *
 */
public class FilesDirCheck {

  /**
   * Logger class manager.
   */
  private static final OCSLogger logger = OCSLoggerFactory.getLogger(FilesDirCheck.class);

  /**
   * This method check if file exist, if not throws an unsupported operation
   * exception
   *
   * @param path File path to check
   */
  public static void checkFileElseExit(String path) {
    File file = new File(path);
    if (!file.isFile() || !file.canRead()) {
      logger.error("Checking file '" + path + "' failed.");
      logger.error("Exit");
      throw (new UnsupportedOperationException("ERROR Checking File " + path));
    }
  }

  /**
   * This method check if directory exist, if not throws an unsupported
   * operation exception
   *
   * @param path Dir path to check
   */
  public static void checkDirElseExit(String path) {
    File file = new File(path);
    if (!file.isDirectory() || !file.canRead()) {
      logger.error("Checking directory '" + path + "' failed");
      logger.error("Exit");
      throw (new UnsupportedOperationException("ERROR Checking Directory " + path));
    }
  }

}
