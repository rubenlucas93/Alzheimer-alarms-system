package util.files;

import java.io.BufferedWriter;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.util.LinkedList;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.xml.serialize.Method;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.SerializerFactory;
import org.apache.xml.serialize.XMLSerializer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;

/**
 * Class used to parse a xml file
 *
 */
@SuppressWarnings("deprecation")
public class XmlParser {

  /**
   * Logger class manager.
   */
  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(XmlParser.class);

  /**
   * Elemento vacXXXo de un XXXrbol de nodos XML.
   */
  public static final Element ELEMENTO_NULO;

  static {
    Document documento = null;
    try {
      final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      final DocumentBuilder builder = factory.newDocumentBuilder();
      documento = builder.newDocument();
    } catch (javax.xml.parsers.ParserConfigurationException pce) {
      LOGGER.error("ParserConfigurationException - The instance could not be created");
    }
    ELEMENTO_NULO = (documento != null) ? documento.createElement("ELEMENTO_NULO") : null;
  }

  // METHODS THAT IMPLEMENT THE LOGIC THROUGH JAXB ELEMENTS FROM JAVAX.XML.BIND

  /**
   * Creates an unmarshaller to bind a class from a xml file
   * @param classToBind Class to be bound
   * @return Unmarshaller
   */
  public static < T > Unmarshaller createUnmarshaller(Class<T> classToBind) {
    JAXBContext jaxbContext;
    Unmarshaller unmarshaller = null;
    if (classToBind != null) {
      try {
        jaxbContext = JAXBContext.newInstance(classToBind);
        unmarshaller = jaxbContext.createUnmarshaller();
      } catch (JAXBException jaxbe) {
        LOGGER.error("JAXBException - Error creating an unmarshaller to bind a xml file: {} ", jaxbe.getMessage());
        jaxbe.printStackTrace();
      }
    } else {
      LOGGER.error("Class to bind can not be null.");
    }
    return unmarshaller;
  }

  /**
   * This method binds a class from a xml file to its related java file
   * @param unmarshaller The unmarshaller used to bind a class
   * @param xmlFile the xml file where the content of the object is located
   * @return An object of the bound class
   */
  public static Object bindClass(Unmarshaller unmarshaller, File xmlFile) {
    Object boundClass = null;
    if (xmlFile != null) {
      try {
        boundClass = unmarshaller.unmarshal(xmlFile);
      } catch (JAXBException jaxbe) {
        LOGGER.error("JAXBException - Binding a class from a xml file: {}" + jaxbe.getMessage());
        jaxbe.printStackTrace();
      }
    } else {
      LOGGER.error("Xml file can not be null.");
    }
    return boundClass;
  }

  public static < T > void toFile(T xmlRootObject, File file, Source[] schemaSources, Class<T> classOfRootObject) {
    try {

      // OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(file), LOCALIZATION.getEncoding());

      OutputStream out = new FileOutputStream(file);

      Marshaller marshaller = createMarshaller(classOfRootObject, schemaSources, true);
      marshaller.marshal(xmlRootObject, out);

      LOGGER.info("XML file written to '{}'", file.getAbsolutePath());
    } catch (JAXBException jaxbe) {
      // cannot be covered, because the method throws a runtime exception
      LOGGER.error("Error binding a class from a xml file - {}", jaxbe.getMessage());
    } catch (IOException jaxbe) {
      // cannot be covered, because the method throws a runtime exception
      LOGGER.error("Error binding a class from a xml file - {}", jaxbe.getMessage());
    }
  }

  public static Marshaller createMarshaller(Class<?> classOfRootObject, Source[] schemaSources, boolean formattedOutput) {
    Marshaller ret = null;
    try {
      JAXBContext context = JAXBContext.newInstance(classOfRootObject);
      Marshaller marshaller = context.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formattedOutput);
      marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-16");

      if (schemaSources != null) {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schemas = sf.newSchema(schemaSources);
        marshaller.setSchema(schemas);
      }

      ret = marshaller;
    } catch (JAXBException | SAXException e) {
      // cannot be covered, because the method throws a runtime exception
      LOGGER.error("Error binding a class from a xml file - {}", e.getMessage());
    }
    return ret;
  }

  // METHODS THAT IMPLEMENT THE LOGIC THROUGH DOCUMENT ELEMENTS FROM ORG.W3C.DOM

  /**
   * Lee un fichero en formato XML.
   * <p>
   * Si el documento no se puede leer o se produce algun error durante su lectura este metodo devuelve el objeto <code>null</code>.
   *
   * @param fichero Fichero que se pretende leer.
   * @return Document Nodo padre del arbol del documento <code>path_fichero</code>.
   */
  public static Document obtenerDatos(File fichero) {
    Document datos = null;

    try {
      if (fichero.exists()) {
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        factory.setIgnoringComments(true);
        factory.setNamespaceAware(false);
        factory.setIgnoringElementContentWhitespace(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        datos = builder.parse(fichero);
      }
    } catch (java.lang.SecurityException se) {
      LOGGER.error("Do not have permissions to access {}", fichero.getAbsolutePath());
    } catch (java.io.IOException ioe) {
      LOGGER.error("IOException: The file {} is not a well-formed XML", fichero.getAbsolutePath());
      datos = null;
    } catch (org.xml.sax.SAXException saxe) {
      LOGGER.error("The file {} does not have a correct XML format.", fichero.getAbsolutePath());
      datos = null;
    } catch (javax.xml.parsers.ParserConfigurationException pce) {
      LOGGER.error("Failed to create factory to read XML files: {}", fichero.getAbsolutePath());
      datos = null;
    }
    return datos;
  }

  /**
   * Escribe en un fichero un arbol XML en formato ISO-8859-1.
   *
   * @param pathFichero Path absoluto del fichero que se pretende leer.
   * @param doc Nodo padre del arbol del documento <code>path_fichero</code>.
   * @return <code>true</code> si la escritura se realia correctamente.
   */
  public static boolean escribirXMLFormatISO(String pathFichero, Document doc) {
    boolean ficheroSalvado = false;

    try {
      final File fichero = comprobarArchivo(pathFichero);

      if (fichero != null) {
        final FileOutputStream fout = new FileOutputStream(fichero);
        final OutputFormat format = new OutputFormat(doc, "ISO-8859-1", true);
        final XMLSerializer serial = new XMLSerializer(fout, format);

        serial.asDOMSerializer().serialize(doc);
        fout.close();
        ficheroSalvado = true;
      }
    } catch (java.io.IOException ioe) {
      LOGGER.error("IOException when formating the XML tree in {}", pathFichero);
    }
    return ficheroSalvado;
  }

  /**
   * Escribe en un fichero un arbol XML en formato UTF-8.
   *
   * @param pathFichero Path absoluto del fichero que se pretende leer.
   * @param doc Nodo padre del arbol del documento <code>pathFichero</code>.
   */
  public static void escribirXMLFormatUTF(String pathFichero, Document doc) {
    try {
      final File fichero = comprobarArchivo(pathFichero);

      if (fichero != null) {
        final SerializerFactory sf = SerializerFactory.getSerializerFactory(Method.XML);
        final FileOutputStream fout = new FileOutputStream(fichero);
        sf.makeSerializer(fout, new OutputFormat(doc));
        fout.close();
      }
    } catch (java.io.UnsupportedEncodingException uee) {
      LOGGER.error("Format not supported when creating {}", pathFichero);
    } catch (java.io.IOException ioe) {
      LOGGER.error("IOException when creating {}", pathFichero);
    }
  }

  /**
   * Comprueba si existe un archivo en el disco duro del sistema y en caso negativo crea uno nuevo.
   *
   * @param archivo Path absoluto del archivo que de va a chequear.
   * @return File Descriptor del archivo cuyo path es <code>archivo</code>.
   */
  private static File comprobarArchivo(String archivo) {
    File file = new File(archivo);

    if (!file.exists() || obtenerDatos(file) == null) {
      try {
        file.createNewFile();
      } catch (IOException e) {
        LOGGER.error("IOException when creating {} ", archivo);
        file = null;
      } catch (java.lang.SecurityException se) {
        LOGGER.error("Do not have permissions to create {} ", archivo);
        file = null;
      }
    }
    return file;
  }

  /**
   * Crea el nodo padre de un XXXrbol DOM.
   *
   * @param tag Nombre para el nodo padre del arbol DOM.
   * @param identificador identificador del nodo padre del arbol, en caso de que este nodo no posea este atributo el valor debe ser <code>null</code>.
   * @return Documento con formato DOM donde se almacena la estructura en arbol creada.
   */
  public static Document createDOM(String tag, String identificador) {
    Document documento = null;

    try {
      final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      final DocumentBuilder builder = factory.newDocumentBuilder();

      documento = builder.newDocument();
      Element root = documento.createElement(tag);
      if (identificador != null) {
        root.setAttribute("id", identificador);
      }

      documento.appendChild(root);
    } catch (javax.xml.parsers.FactoryConfigurationError fce) {
      LOGGER.error("There was a problen in the Factory configuration.");
    } catch (javax.xml.parsers.ParserConfigurationException pce) {
      LOGGER.error("DocumentBuilder instance could not be created.");
    } catch (org.w3c.dom.DOMException de) {
      LOGGER.error("DOMException when creating the root node {}.", tag);
    }
    return documento;
  }

  /**
   * Crea un nuevo nodo de un arbol para ser utilizado en <code>doc</code>.
   *
   * @param doc Documento utilizado para crear en nuevo nodo.
   * @param etiqueta Etiqueta del nuevo nodo.
   * @param id Identificador del nuevo nodo, si el nodo no posee identificador el valor debera ser <code>null</code>.
   * @param texto Valor del atributo que se le anadir al nodo, si el nodo no posee atributos este valor debe de ser <code>null</code>.
   * @return El nodo creado.
   */
  public static Element crearNodo(Document doc, String etiqueta, String id, String texto) {
    Element nodoNuevo = null;

    try {
      nodoNuevo = doc.createElement(etiqueta);
      if (id != null) {
        final Attr atributo = doc.createAttribute("id");
        atributo.setValue(id);
        nodoNuevo.setAttributeNode(atributo);
      }
      if (texto != null) {
        nodoNuevo.appendChild(doc.createTextNode(texto));
      }
    } catch (DOMException de) {
      LOGGER.error("DOMException when creating the node {}", etiqueta);
    }
    return nodoNuevo;
  }

  /**
   * AXXXade un nuevo nodo al elemento <code>padre</code>. Este mXXXtodo aXXXade siempre un salto de lXXXnea en el XXXrbol antes de realizar ninguna acciXXXn, a
   * continuaciXXXn aXXXade tantos tabuladores cXXXmo XXXndice <code>num_tab</code> y finalmente el nodo <code>nodo</code> si este no es <code>null</code>.
   *
   * @param doc Documento utilizado para crear los nodos utilizados para dar formato al fichero.
   * @param padre Padre del nodo que se aXXXade.
   * @param nodo Nodo que se aXXXade, si este es <code>null</code> sXXXlo se aXXXaden los tabuladores.
   * @param numTab NXXXmero de tabuladores que se aXXXadirXXXn antes del nuevo nodo en el XXXrbol, tabuladores sirven para dar formato al XXXrbol al salvarlo en
   * un fichero.
   */
  public static void addNodo(Document doc, Element padre, Element nodo, int numTab) {
    final StringBuffer textoFinal = new StringBuffer(System.getProperty("line.separator"));

    for (int indice = 0; indice < numTab; indice++) {
      textoFinal.append("\t");
    }
    try {
      padre.appendChild(doc.createTextNode(textoFinal.toString()));
      if (nodo != null) {
        padre.appendChild(nodo);
      }
    } catch (DOMException de) {
      LOGGER.error("DOMException when adding a new node.");
    }
  }

  /**
   * Obtiene el atributo <code>nombre</code> asociado al nodo <code>elemento</code>.
   *
   * @param elemento Nodo del cual se obtiene el texto asociado.
   * @param nombre Nombre del atributo que se desea obtener.
   * @param valorDefecto Valor que se devuelve en caso de que no exista el atributo.
   * @return El atributo asociado a <code>elemento</code> o <code>valorDefecto<code>
   * si dicho elemento no posee el atributo <code>nombre</code>.
   */
  public final static String getAtributo(Element elemento, String nombre, String valorDefecto) {
    String resultado = valorDefecto;

    if ((elemento != null) && (nombre != null)) {
      final Attr atributo = elemento.getAttributeNode(nombre);
      if (atributo != null) {
        resultado = atributo.getValue();
      }
    }
    if (resultado.equals(valorDefecto)) {
      LOGGER.error("The {} attribute was not found.", nombre);
    }
    return resultado;
  }

  /**
   * Obtiene el primer elemento con la etiqueta <code>etiqueta</code> que se encientra dentro del nodo <code>elemento</code>.
   *
   * @param elemento Nodo del cual se obtiene el subelemento asociado.
   * @param etiqueta Nombre de la etiqueta que debe poseer el elemento resultado.
   * @param valorDefecto Valor que se devuelve en caso de que no exista el elemento.
   * @return El elemento dentro de <code>elemento</code> con la etiqueta <code>etiqueta</code> o <code>valorDefecto</code> si dicho elemento no existe.
   */
  public final static Element getElemento(Element elemento, String etiqueta, Element valorDefecto) {
    Element resultado = valorDefecto;

    if ((elemento != null) && (etiqueta != null)) {
      final NodeList nodos = elemento.getChildNodes();
      boolean encontrado = false;

      for (int indice = 0; !encontrado && (indice < nodos.getLength()); indice++) {
        final Node nodo = nodos.item(indice);
        if (nodo.getNodeType() == Node.ELEMENT_NODE) {
          final Element elementoAux = (Element) nodo;
          if (elementoAux.getTagName().equals(etiqueta)) {
            resultado = elementoAux;
            encontrado = true;
          }
        }
      }
    }
    if (resultado.equals(valorDefecto)) {
      LOGGER.error("The {} element was not found.", etiqueta);
    }
    return resultado;
  }

  /**
   * Obtiene el conjunto de elementos con la etiqueta <code>etiqueta</code> que se encuentran dentro del nodo <code>elemento</code>.
   *
   * @param elemento Nodo del cual se obtiene el subelemento asociado.
   * @param etiqueta Nombre de la etiqueta que debe poseer los elementos resultado.
   * @return Conjunto de elementos dentro de <code>elemento</code> con la etiqueta <code>etiqueta</code>.
   */
  public final static Element[] getElementos(Element elemento, String etiqueta) {
    Element[] resultado = new Element[0];

    if ((elemento != null) && (etiqueta != null)) {
      final LinkedList<Element> listaResultado = new LinkedList<Element>();
      final NodeList nodos = elemento.getChildNodes();

      for (int indice = 0; indice < nodos.getLength(); indice++) {
        final Node nodo = nodos.item(indice);

        if (nodo.getNodeType() == Node.ELEMENT_NODE) {
          final Element elementoAux = (Element) nodo;
          if (elementoAux.getTagName().equals(etiqueta)) {
            listaResultado.addLast(elementoAux);
          }
        }
      }

      resultado = new Element[listaResultado.size()];
      for (int indice = 0; indice < resultado.length; indice++) {
        resultado[indice] = listaResultado.removeFirst();
      }
    }
    if (resultado.length == 0) {
      LOGGER.error("Unable to find elements of label: {}", etiqueta);
    }

    return resultado;
  }

  /**
   * Obtiene el texto asociado al nodo <code>elemento</code>.
   *
   * @param elemento Nodo del cual se obtiene el texto asociado.
   * @param valorDefecto Valor que se devuelve en caso de que no exista el texto.
   * @return El texto o nodo <code>TEXT_NODE</code> asociado a <code>elemento</code> o <code>valorDefecto<code> si dicho elemento no posee dicho texto.
   */
  public final static String getTexto(Element elemento, String valorDefecto) {
    String resultado = valorDefecto;

    if (elemento != null) {
      final NodeList nodos = elemento.getChildNodes();

      boolean encontrado = false;
      for (int indice = 0; indice < nodos.getLength(); indice++) {
        final Node nodo = nodos.item(indice);
        if (nodo.getNodeType() == Node.TEXT_NODE) {
          resultado = ((Text) nodo).getData();
          encontrado = true;
        }
      }
      if (encontrado == false) {
        LOGGER.error("Unable to find text of: {}", elemento.getTagName());
      }
    }
    return resultado;
  }

  /**
   * Transforma un objeto en una cadena en formato XML.
   *
   * @param objeto Mensaje de interfaz JMS a transformar
   * @return El objeto definido como una cadena en formato XML.
   */
  public static String getStringXML(Object objeto) {
    String resultado = "";

    if (objeto != null) {
      try {
        final CharArrayWriter retorno = new CharArrayWriter();
        final Writer out = new BufferedWriter(retorno);
        final org.exolab.castor.xml.Marshaller marshaller = new org.exolab.castor.xml.Marshaller(out);
        marshaller.setMarshalAsDocument(false);
        marshaller.setSuppressXSIType(true);

        marshaller.marshal(objeto);
        resultado = retorno.toString().replaceAll(" <valid>true</valid>", "").replaceAll(" valid=\"true\"", "");
      } catch (IOException e) {
        LOGGER.error("IOException - While printing the following object: {}", objeto.getClass().toString());
        e.printStackTrace();
      } catch (MarshalException e) {
        LOGGER.error("MarshalException - While printing the following object: {}", objeto.getClass().toString());
        e.printStackTrace();
      } catch (ValidationException e) {
        LOGGER.error("ValidationException - While printing the following object: {}", objeto.getClass().toString());
        e.printStackTrace();
      }
    }

    return resultado;
  }

}
