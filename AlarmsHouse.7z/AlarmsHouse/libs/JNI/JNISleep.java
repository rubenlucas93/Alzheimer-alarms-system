package JNI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;

/**
 * Clase que realiza el sleep nativo si se ha definido la libreria o el sleep de java en caso contrario. Utiliza sleep de C que funciona con cambios en las
 * fechas.
 */
public class JNISleep {

  /**
   * Metodo nativo encargado de hacer el sleep
   */
  public static native void nativeSleep(long millis);

  @SuppressWarnings({ "unchecked", "rawtypes" })
  public static List interrumped = Collections.synchronizedList(new ArrayList());

  /**
   * Logger class manager.
   */
  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(JNISleep.class);

  /**
   * 0 NOT INITIALIZED, 1 NATEIVE METHOS, 2 JVM
   */
  private static int useLib = 0;

  static {
    if (useLib == 0) {
      try {
        System.loadLibrary("sleep");
        useLib = 1;
        LOGGER.info("Using native sleep mode");
      } catch (Exception e) {
        LOGGER.info("Using JVM sleep mode");
        useLib = 2;
      } catch (UnsatisfiedLinkError e2) {
        LOGGER.info("Using JVM sleep mode");
        useLib = 2;
      }
    }
  }

  @SuppressWarnings("unchecked")
  public static void interrupt(Thread th) {
    if (useLib == 1) {
      interrumped.add(th.getId());
    } else {
      th.interrupt();
    }

  }

  /**
   * Metodo que realiza un sleep de X milisegundos. Si se ha cargado la libreria de C, utiliza el sleep correspondiente. En caso contrario, utiliza el sleep de
   * Java.
   *
   * @param millis Milisegundos de espera.
   */
  public static void sleep(long millis) throws InterruptedException {
    if (useLib == 1) {
      nativeSleep(millis);
      if (interrumped.contains(Thread.currentThread().getId())) {
        interrumped.remove(Thread.currentThread().getId());
        throw new InterruptedException();
      }
    } else {
      Thread.sleep(millis);
    }
  }

  /**
   * Metodo principal para realizar pruebas.
   *
   * @param args Argumentos de entrada.
   */
  public static void main(String[] args) {
    LOGGER.debug("[TEST] THIS IS A TEST FOR YOU TO ENSURE THAT THE COMMON LIBRARY WORKS CORRECTLY.");
    LOGGER.debug("[TEST] TO END THE TEST: CONTROL-C");
    if (args.length != 2) {
      LOGGER.debug("[TEST] THE METHOD TO TEST MUST BE PASSED BY PARAMETER (1=Sleep,2=Timer) AND THE MILLISECONDS FOR THE TEST.");
    } else {
      int tipoPrueba = Integer.parseInt(args[0]);
      long timeTest = Long.parseLong(args[1]);
      LOGGER.debug("[TEST] LAUNCHING THE TYPE TEST " + args[0] + " FOR " + args[1] + " MILLISECONDS.");

      if (tipoPrueba == 1) {
        while (true) {
          long time1 = System.currentTimeMillis();
          try {
            JNISleep.sleep(timeTest);
          } catch (Exception e) {
            LOGGER.error("[TEST] AN ERROR HAS OCCURRED.");
            e.printStackTrace();
          }
          LOGGER.debug("[TEST] PROCESS IS TAKING TO AWAKE " + (System.currentTimeMillis() - time1) + " AND THE TEST WAS : " + args[1] + " MS");
        }
      } else {

        JNITimer temporizador = null;
        if (temporizador == null) {
          final JNITimerTask tarea = new JNITimerTask() {
            public void run() {
              LOGGER.debug("[TEST] EXECUTED TASK " + System.currentTimeMillis());
            }
          };

          temporizador = new JNITimer("NOMBRE - TIMER");
          java.util.Date fecha = new java.util.Date(System.currentTimeMillis() + timeTest);
          LOGGER.debug("[TEST] EXECUTE AT :> " + fecha.getTime());
          LOGGER.debug("[TEST] NOW IS ;> " + System.currentTimeMillis());
          temporizador.schedule(tarea, fecha, timeTest);
        }
      }
    }
  }

}
