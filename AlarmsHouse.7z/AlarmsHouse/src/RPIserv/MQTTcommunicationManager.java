package RPIserv;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.BBGmessage;
import common.messageTypes.RPImessage;
import common.messageTypes.movemessage;
import util.MQTTManager;
import util.SimpleMqttCallBack;

public class MQTTcommunicationManager extends MQTTManager {

	public decisionManager manager;
    public static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(MQTTcommunicationManager.class);

    public MQTTcommunicationManager(decisionManager decisionManager) throws MqttPersistenceException, MqttException {
    	super();
    	this.manager=decisionManager;
    }
    
    private class serverMqttCallBack implements MqttCallback{

		private long rcvTime;
		private String[] payload;
		private String roomID;
		private String movevalue;
		private movemessage mvmessage = new movemessage();

		@Override
		public void connectionLost(Throwable arg0) {
		    System.out.println("Connection to MQTT broker lost!");
			
		}

		@Override
		public void deliveryComplete(IMqttDeliveryToken arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
		    System.out.println("Message received:\n\t"+ new String(mqttMessage.getPayload()) );
		    if (topic=="movement") {
			    if (mqttMessage.getPayload() == null) {
			        LOGGER.error("The information received within the message is null.");
			    }else{
			    	rcvTime = System.currentTimeMillis();
			    	payload=new String(mqttMessage.getPayload()).split(";");
			    	roomID=payload[0];
			    	movevalue=payload[1];
			    	mvmessage .constructMessage(Float.parseFloat(movevalue), roomID);
			        manager.getTratarMensaje().messageReceived(mvmessage, rcvTime);
			    }
		    }
		}

    	
    	
    }
    
    @Override
	public void consume(String topic) throws MqttException {
		client.setCallback( new serverMqttCallBack() );
		client.subscribe(topic);
	}
}
