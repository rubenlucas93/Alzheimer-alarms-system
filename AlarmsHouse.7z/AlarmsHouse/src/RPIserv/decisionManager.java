package RPIserv;

import java.io.IOException;

import org.eclipse.paho.client.mqttv3.MqttException;

import com.espertech.esper.client.EPServiceDestroyedException;
import com.espertech.esper.client.deploy.DeploymentException;
import com.espertech.esper.client.deploy.ParseException;

import JMS.JMSInterface;
import JNI.JNISleep;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.esperMessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;
import util.MQTTManager;

public class decisionManager {
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(decisionManager.class);
	private dealMessage tratarMensaje;
	private communicationManager comm;
	private RecepcionMensajesJMS receptor;
	private esperManager esper;
	private MQTTcommunicationManager MQTTcomm;
	private Thread MQTTcommunication;

	
    public void dealAlarm(Object mensaje) {
    	if (mensaje instanceof esperMessage) {
    		esperMessage informacion = (esperMessage) mensaje;
        	//aqu� es donde finalmente haremos lo que tengamos que hacer
        	switch (informacion.event) {
    	    	case "1":  informacion.event = "fire";
    	    	//do something
    	        break;
        	}
    	}else {
    		LOGGER.error("recibido un objeto que no es un esperMessage");
    	}

    		
    }

    public void alarmDescription(final String description) {
    }

    public decisionManager() throws InterruptedException, EPServiceDestroyedException, IOException, ParseException, DeploymentException{
    	
    	
    	comm=new communicationManager(this) {
    		@Override
    	    public void listenMessages(){
        	    LOGGER.log("------------------------------------------");
        	    LOGGER.log("---  Loading messaging  ---");
	    		if (interfazJMS != null) {
	        	    setReceptor(new RecepcionMensajesJMS(this.manager, interfazJMS.getReceptionQueue()));
	    		}
    		}

    		@Override
    	    public boolean sendinfo(eventMessage msgToSend) {
	            boolean success = false;
	    		if (interfazJMS != null) {
	    		    interfazJMS.sendMessage(msgToSend, JMSInterface.UPDATE_ALL_CLIENTS);
	                return success;
	    		}else{
	    			return false;
	    		}
    		}

			@Override
			public boolean sendinfo(BBGmessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(movemessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(RPImessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}


    	};
    	
    	comm.listenMessages();
    	
    	try {
			MQTTcomm=new MQTTcommunicationManager(this);
		} catch (MqttException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
    	//consume MQTT para los sensores independientes que hablan MQTT
    	MQTTcommunication = new Thread(new Runnable() {
    		      @Override
    		      public void run() {    	
				    	try {
							MQTTcomm.connectClient();
							MQTTcomm.consume("movement");
						} catch (MqttException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							try {
								MQTTcomm.disconnectClient();
							} catch (MqttException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
    		      }
    	});
    	MQTTcommunication.start();
    	

    	
    	this.setEsper(new esperManager(this, comm));
    	dealMessage tratarMensaje = new dealMessage(this);
    	this.tratarMensaje=tratarMensaje;
    	this.setTratarMensaje(tratarMensaje);
    	
    }

	public dealMessage getTratarMensaje() {
		return tratarMensaje;
	}

	public void setTratarMensaje(dealMessage tratarMensaje) {
		this.tratarMensaje = tratarMensaje;
	}


	public esperManager getEsper() {
		return esper;
	}

	public void setEsper(esperManager esper) {
		this.esper = esper;
	}

	  public static void main(String[] args) throws InterruptedException, EPServiceDestroyedException, IOException, ParseException, DeploymentException {
//		  JNISleep.sleep(30000);
		  new decisionManager();
	  }

	public RecepcionMensajesJMS getReceptor() {
		return receptor;
	}

	public void setReceptor(RecepcionMensajesJMS receptor) {
		this.receptor = receptor;
	}
    
}

