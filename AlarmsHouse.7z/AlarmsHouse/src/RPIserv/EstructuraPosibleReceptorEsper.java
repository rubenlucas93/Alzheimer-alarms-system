/*
 * RecepcionMensajesJMS.java
 *
 * Created on 18 de Noviembre de 2008, 17:23
 */
package RPIserv;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.esperListeners.InsercionMensajesEsper;
import common.messageTypes.esperMessage;
import util.SynchronizedQueue;

/**
 *
 * @version 1.0
 */
public class EstructuraPosibleReceptorEsper extends Thread {

  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(InsercionMensajesEsper.class);

  /**
   * Cola de mensajes utilizada para obtener los mensajes enviados por el IHM
   */
  private final SynchronizedQueue colaRecepcion;

  private decisionManager managerdecision;

  /**
   * Crea una nueva instancia de RecepcionMensajesJMS
   *
   * @param cola Cola de recepcion de los mensajes
   * @param gestor Gestor encargado de realizar la gestion de los mensajes
   */
  public EstructuraPosibleReceptorEsper(decisionManager manager, SynchronizedQueue cola) {
	managerdecision=manager;
    colaRecepcion = cola;
    if (cola != null) {
      start();
    }
  }

  /**
   * Crea una nueva instancia de RecepcionMensajesJMS
   *
   * @param cola Cola de recepcion de los mensajes
   * @param gestor Gestor encargado de realizar la gestion de los mensajes
   */
  public EstructuraPosibleReceptorEsper(SynchronizedQueue cola) {
    colaRecepcion = cola;
    if (cola != null) {
      start();
    }
  }
  
  /**
   * Metodo de arranque del hilo.
   */
  public void run() {
    while (colaRecepcion != null) {
      final Object objeto = colaRecepcion.consumir();
      if (objeto == null) {
        LOGGER.error("Received message to null");
      } else if (objeto instanceof esperMessage) {
            final esperMessage mensajeEsper = (esperMessage) objeto;
        	managerdecision.dealAlarm(mensajeEsper);
       
        /**
         * No used } else if (objeto instanceof JMSSubscriberState) { } else if (objeto instanceof JMSPublisherState) { } else if (objeto instanceof Life) {
         */
        } else {
          LOGGER.error("Received unexpected message type {}.", objeto.getClass().toString());
        }
    }
  }
}