package RPIserv;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.espertech.esper.client.Configuration;
import com.espertech.esper.client.EPListenable;
import com.espertech.esper.client.EPRuntime;
import com.espertech.esper.client.EPServiceDestroyedException;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;
import com.espertech.esper.client.deploy.DeploymentException;
import com.espertech.esper.client.deploy.ParseException;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.esperListeners.AirMensajesEsper;
import RPIserv.esperListeners.CalefactorMensajesEsper;
import RPIserv.esperListeners.CheckMachineOffMensajesEsper;
import RPIserv.esperListeners.FreezeMensajesEsper;
import RPIserv.esperListeners.GasMensajesEsper;
import RPIserv.esperListeners.HeatMensajesEsper;
import RPIserv.esperListeners.InsercionMensajesEsper;
import RPIserv.esperListeners.InsertRecordatoriosEsper;
import RPIserv.esperListeners.MachineOnMensajesEsper;
import RPIserv.esperListeners.SOSMensajesEsper;
import RPIserv.esperListeners.TVONMensajesEsper;
import RPIserv.esperListeners.darkMensajesEsper;
import RPIserv.esperListeners.fallMoveMensajesEsper;
import RPIserv.esperListeners.fallNoMoveMensajesEsper;
import RPIserv.esperListeners.faucetMensajesEsper;
import RPIserv.esperListeners.fireOnMensajesEsper;
import RPIserv.esperListeners.lightMensajesEsper;
import RPIserv.esperListeners.reminderMensajesEsper;
import common.messageTypes.BBGEsperMessage;
import common.messageTypes.RPIEsperMessage;
import common.messageTypes.moveEsperMessage;
import common.messageTypes.recordatorioEsperMessage;
import util.SynchronizedQueue;

public class esperManager {
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(esperManager.class);

	
    private decisionManager decManager;
    private SynchronizedQueue queue;
    private EPServiceProvider cep;
    private EPStatement cepMemoryStatement;
	private EPStatement cepMemoryStatement1;
	private EPStatement cepMemoryStatement2;
	private EPStatement cepMemoryStatement3;
	private EPStatement cepMemoryStatement4;
	private EPStatement cepMemoryStatement5;
	private EPStatement cepMemoryStatement6;
	private EPStatement cepMemoryStatement7;
	private EPStatement cepMemoryStatement8;
	private EPStatement cepMemoryStatement9;
	private EPStatement cepMemoryStatement10;
	private EPStatement cepMemoryStatement11;
	private EPStatement cepMemoryStatement12;

	
	private EPStatement cepOrientationStatement1;
	private EPStatement cepOrientationStatement2;
	private EPStatement cepOrientationStatement3;
	private EPRuntime cepRT;
	private BBGEsperMessage BBGEsperMsg;
	private moveEsperMessage moveEsperMsg;
	private RPIEsperMessage RPIEsperMsg;

	private InsertRecordatoriosEsper InsertRecordatoriosListener;
	private InsercionMensajesEsper InsertMessagesListener;
	private GasMensajesEsper GasMessagesListener;
	private AirMensajesEsper AirMessagesListener;
	private FreezeMensajesEsper FreezeMessagesListener;
	private HeatMensajesEsper HeatMessagesListener;
	private CalefactorMensajesEsper CalefactorMessagesListener;
	private MachineOnMensajesEsper MachineOnMessagesListener;
	private CheckMachineOffMensajesEsper CheckMachineOffMessagesListener;
	private fallNoMoveMensajesEsper fallNoMoveMessagesListener;
	private fallMoveMensajesEsper fallMoveMessagesListener;
	private SOSMensajesEsper SOSMessagesListener;
	private lightMensajesEsper lightMessagesListener;
	private darkMensajesEsper darkMessagesListener;
	private TVONMensajesEsper TVONMessagesListener;
	private faucetMensajesEsper  faucetMessagesListener;
	private fireOnMensajesEsper fireOnMessagesListener;







	private reminderMensajesEsper reminderMessagesListener;
	private String[] reminder;
	private String[] reminderTime;
	private int remindersNumber;
	private EPStatement reminderStatement;
	private String remindersPath = "/TFMconfig/reminder.properties";
//	private String remindersPath = "C:\\Users\\Z003TXBU\\eclipse-workspace\\AlarmsHouse\\config\\reminders.properties";


	public boolean machineStateOn = false;


	private communicationManager sender;


	private EPListenable cepOrientationStatement4;


	private recordatorioEsperMessage recordatorioEsperMsg;



    public esperManager(decisionManager manager, communicationManager sender) throws InterruptedException, EPServiceDestroyedException, IOException, ParseException, DeploymentException {
    	setDecManager(manager);
    	setSender(sender);
    	this.init();
    	
	}

    private void setSender(communicationManager sender) {
    	this.sender=sender;
	}

	private void init() throws EPServiceDestroyedException, IOException, ParseException, DeploymentException {
    	     	     	 
	    //The Configuration is meant only as an initialization-time object.
	    Configuration cepConfig = new Configuration();
	    
	    //read the configured reminders;
	    readReminders();
	    // We registhe message typesksks as objects the engine will have to handle
	    cepConfig.addEventType("BBGEsperMsg", BBGEsperMessage.class.getName());
	    cepConfig.addEventType("moveEsperMsg", moveEsperMessage.class.getName());
	    cepConfig.addEventType("RPIEsperMsg", RPIEsperMessage.class.getName());
	    cepConfig.addEventType("recordatorioEsperMsg", recordatorioEsperMessage.class.getName());

	    InsertRecordatoriosListener= new InsertRecordatoriosEsper(this, sender); 
	    InsertMessagesListener= new InsercionMensajesEsper(sender); 
	    GasMessagesListener=new GasMensajesEsper(getDecManager(),sender);
	    AirMessagesListener=new AirMensajesEsper(this,sender);
	    FreezeMessagesListener=new FreezeMensajesEsper(getDecManager(),sender);
	    HeatMessagesListener=new HeatMensajesEsper(getDecManager(),sender);
	    CalefactorMessagesListener= new CalefactorMensajesEsper(this,sender);
	    MachineOnMessagesListener= new MachineOnMensajesEsper(this,sender);
	    CheckMachineOffMessagesListener= new CheckMachineOffMensajesEsper(this,sender);
	    fallNoMoveMessagesListener= new fallNoMoveMensajesEsper(this,sender);
		fallMoveMessagesListener= new fallMoveMensajesEsper(this,sender);
		SOSMessagesListener = new SOSMensajesEsper(this,sender);
	    lightMessagesListener=new lightMensajesEsper(this,sender);
	    darkMessagesListener=new darkMensajesEsper(this,sender);
	    TVONMessagesListener=new TVONMensajesEsper(this, sender);
	    faucetMessagesListener=new faucetMensajesEsper(this, sender);
	    fireOnMessagesListener= new fireOnMensajesEsper(this, sender);
	   
	    // We setup the engine
    	cep = EPServiceProviderManager.getProvider("myCEPEngine",cepConfig);
	    cepRT = cep.getEPRuntime();

	    //create the tables we need to store the sensed information
        String ALLquery = "create table ALL_EVENTS ( room String, type String, value float, date Long primary key )";
		cep.getEPAdministrator().createEPL(ALLquery);


		String BBGquery = "create table BBG_TABLE ( room String,  gasvalue float, "
				+ "lightvalue float, tempvalue float, humvalue float, movevalue float, soundvalue float, date Long primary key )";
		cep.getEPAdministrator().createEPL(BBGquery);


		String ReminderQuery = "create table recordatorio_TABLE ( text String, date Long primary key )";
		cep.getEPAdministrator().createEPL(ReminderQuery);
		
		//statements creation
        createMemoryStatements();        
		createOrientationStatements();
		createStatisticsStatements(); //TO-DO

   

    }
 	 	
    
	private void createStatisticsStatements() {
		// TO-DO Auto-generated method stub
		
	}

	private void createOrientationStatements() {

    	//patient fell and is not moving
    	cepOrientationStatement1=cep.getEPAdministrator().createEPL(
    			"select RPI_MEASURES.fallNotMovevalue "+
    			" from RPI_MEASURES.win:time(30 seconds)"+
    			" where RPI_MEASURES.fallNotMovevalue=true ");

    	cepOrientationStatement1.addListener(fallNoMoveMessagesListener);
    	
    	//patient fell but moving
    	cepOrientationStatement2=cep.getEPAdministrator().createEPL(
    			"select RPI_MEASURES.fallvalue "+
    			" from  RPI_MEASURES.win:time(30 seconds)"+
    			" where RPI_MEASURES.fallvalue=true ");

    	cepOrientationStatement2.addListener(fallMoveMessagesListener);
    	
    	//patient asking for help
    	cepOrientationStatement3=cep.getEPAdministrator().createEPL(
    			"select RPI_MEASURES.SOSvalue "+
    			" from  RPI_MEASURES.win:time(30 seconds)"+
    			" where RPI_MEASURES.SOSvalue=true ");

    	cepOrientationStatement3.addListener(SOSMessagesListener);
    	
    	//patient in the dark. In this projecthavedodo notd use independent sensor.
    	//In case we want it we need a movement sensor in each room and the next statement:
//    	cepOrientationStatement4=cep.getEPAdministrator().createEPL(
//    			"select BBG_MEASURES.room lightvalue, MOVE_MEASURES.room, BBG_MEASURES.movevalue, MOVE_MEASURES.movevalue"+
//    			" from BBG_MEASURES.win:time(20 seconds), MOVE_MEASURES.win:time(20 seconds)"+
//    			" where BBG_MEASURES.room=MOVE_MEASURES.room having max(lightvalue)<400 and avg(BBG_MEASURES.movevalue)>0.25 and max(MOVE_MEASURES.movevalue)>0.25");
//    	cepOrientationStatement4.addListener(darkMessagesListener);
    	
    	cepOrientationStatement4=cep.getEPAdministrator().createEPL(
    			"select room, lightvalue, movevalue " +
    			"from BBG_MEASURES.win:time(20 seconds) "+
    			"having max(lightvalue)<200 and avg(movevalue)>0.25");
    	cepOrientationStatement4.addListener(darkMessagesListener);
    	
	}

	private void readReminders() {
    	final String fichero = remindersPath ;
        Properties config = new Properties();
        try {
          config.load(new java.io.FileInputStream(fichero));
          try {
        	  remindersNumber = Integer.parseInt(config.getProperty("reminders_num", "0"));
            } catch (NumberFormatException e) {
              LOGGER.error("It has been impossible to obtain remindersNumber, it is wrong in the file reminder.properties");
            }
          for(int i=1; i<=remindersNumber; i++) {
              reminder[i-1]= config.getProperty("reminder"+i);
              reminderTime[i-1] = config.getProperty("reminder_time"+i);      	  
          }

        } catch (FileNotFoundException e1) {
          e1.printStackTrace();
        } catch (IOException e1) {
          e1.printStackTrace();
        }
	}

	private void createMemoryStatements() {
		
    	//insertion of every BBG table but we do not want esper to notify or do nothing when happens so no listeners have been added
    	cepMemoryStatement=cep.getEPAdministrator().createEPL("insert into BBG_TABLE select room, gasvalue,"
    			+ " lightvalue, tempvalue, humvalue, movevalue, soundvalue, date from BBGEsperMsg");
		
    	cepMemoryStatement=cep.getEPAdministrator().createEPL("insert into recordatorio_TABLE select text, date from recordatorioEsperMsg");
    	
    	//insertion of every BBG message
    	cepMemoryStatement=cep.getEPAdministrator().createEPL("insert into BBG_MEASURES select room, "
    			+ "gasvalue, lightvalue, tempvalue, humvalue, movevalue, soundvalue, date from BBGEsperMsg");
    	cepMemoryStatement.addListener(InsertMessagesListener);
    	
    	//insertion of every reminder
    	cepMemoryStatement=cep.getEPAdministrator().createEPL("insert into Recordatorios select text "
    			+ " from recordatorioEsperMsg");
    	cepMemoryStatement.addListener(InsertRecordatoriosListener);  
    	
    	
    	//insertion of every Movement message
    	cepMemoryStatement1=cep.getEPAdministrator().createEPL("insert into MOVE_MEASURES select room,"
    			+ " movevalue, date from moveEsperMsg");
    	cepMemoryStatement1.addListener(InsertMessagesListener);
    	    	
    	//insertion of every RPI Message
      	cepMemoryStatement1=cep.getEPAdministrator().createEPL("insert into RPI_MEASURES select fallvalue,"
      			+ " SOSvalue, fallNotMovevalue, date from RPIEsperMsg");
    	cepMemoryStatement1.addListener(InsertMessagesListener);
    	
    	//gas detection and no movement in past 30 seconds
    	cepMemoryStatement2=cep.getEPAdministrator().createEPL(
    			"select gasvalue, room, movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" where room='kitchen' having avg(gasvalue)>100 and max(movevalue)=0.0");
    	cepMemoryStatement2.addListener(GasMessagesListener);
    	
    	//air conditioning on and no movement
    	cepMemoryStatement3=cep.getEPAdministrator().createEPL(
    			"select avg(tempvalue), soundvalue, movevalue" +  
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" where BBG_MEASURES.room='kitchen'"
    			+ " having min(soundvalue)>15 and avg(tempvalue)<15 and max(BBG_MEASURES.movevalue)=0.0 ");
    	cepMemoryStatement3.addListener(AirMessagesListener);
    	
    	//too freeze
    	cepMemoryStatement4=cep.getEPAdministrator().createEPL(
    			"select tempvalue, movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" having avg(tempvalue)<10 and min(movevalue)=1.0");
    	cepMemoryStatement4.addListener(FreezeMessagesListener);
    	
    	//too hot
    	cepMemoryStatement5=cep.getEPAdministrator().createEPL(
    			"select tempvalue, movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" having avg(tempvalue)>40 and min(movevalue)=1.0");
    	cepMemoryStatement5.addListener(HeatMessagesListener);
    	
    
    	//calefactor on and no movement
    	cepMemoryStatement6=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.room, MOVE_MEASURES.room, tempvalue, BBG_MEASURES.movevalue, MOVE_MEASURES.movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds), MOVE_MEASURES.win:time(30 seconds)"+
    			" where BBG_MEASURES.room='kitchen' and MOVE_MEASURES.room='kitchen' having  avg(tempvalue)>25 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0");
    	//preguntar a BRUNO como puedo ver que una medida tras otra, la temperatura ha ido bajando
    	//la idea ser�a poder comparar 3 sqls, una con 60 secs, otra con 120, otra con 180 y otra con 240
    	cepMemoryStatement6.addListener(CalefactorMessagesListener);
    	
    	
    	//washing machine or laundry ongoing
    	cepMemoryStatement7=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.room soundvalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" where BBG_MEASURES.room='kitchen' having min(soundvalue)>35");
    	cepMemoryStatement7.addListener(MachineOnMessagesListener);
    	
    	//washing machine or laundry finished 3 minutes ago. Inside the listener we check if it was on before
    	cepMemoryStatement8=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.room soundvalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" where BBG_MEASURES.room='kitchen' having min(soundvalue)<35");
    	cepMemoryStatement8.addListener(CheckMachineOffMessagesListener);
    	
    	//light still on 
    	cepMemoryStatement9=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.room lightvalue, MOVE_MEASURES.room, BBG_MEASURES.movevalue, MOVE_MEASURES.movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds), MOVE_MEASURES.win:time(30 seconds)"+
    			"where MOVE_MEASURES.room=BBG_MEASURES.room having min(lightvalue)>400 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0");
    	cepMemoryStatement9.addListener(lightMessagesListener);
    	
//    	TV ON
    	cepMemoryStatement10=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.room soundvalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" where BBG_MEASURES.room='LivingRoom' having min(soundvalue)>20");   
    	cepMemoryStatement10.addListener(TVONMessagesListener);
    	
//    	faucet open
    	cepMemoryStatement11=cep.getEPAdministrator().createEPL(
    			"select humvalue, movevalue"+
    	    			" from BBG_MEASURES.win:time(30 seconds)"+
    	    			" having avg(humvalue)>70 and max(movevalue)=0.0");
    	cepMemoryStatement11.addListener(faucetMessagesListener);
    	
    
//    	fire on and nobody cooking 
    	cepMemoryStatement12=cep.getEPAdministrator().createEPL(
    			"select tempvalue, movevalue"+
    			" from BBG_MEASURES.win:time(30 seconds)"+
    			" having avg(tempvalue)>50 and max(movevalue)=0.0");
    	cepMemoryStatement12.addListener(fireOnMessagesListener);
    		
    	
    	//reminders
    	for(int i=1; i <= remindersNumber; i++) {
    		setReminder(reminder[i-1], reminderTime[i-1]);
    	}
	}

	
    void setReminder(String reminder, String time){
    	reminderMessagesListener=new reminderMensajesEsper(reminder,sender);
    	reminderStatement=cep.getEPAdministrator().createEPL(
    			"select BBG_MEASURES.date, MOVE_MEASURES.date from BBG_MEASURES.win:time(30 seconds), MOVE_MEASURES.win:time(30 seconds)"+
    			"where MOVE_MEASURES.room.date=" + time +" or BBG_MEASURES.date=" +time);
    	reminderStatement.addListener(reminderMessagesListener);
    }
	 	
	
	
	public void checkEvents(final decisionManager creator) {
    }
    
	public decisionManager getDecManager() {
		return decManager;
	}

	public void setDecManager(decisionManager decManager) {
		this.decManager = decManager;
	}

	public SynchronizedQueue getQueue() {
		return queue;
	}

	public void setQueue(SynchronizedQueue queue) {
		this.queue = queue;
	}

	public boolean storeInfo(boolean Fall, boolean SOS, boolean FallNotMovement, long fecha) {
		    RPIEsperMsg= new RPIEsperMessage();
		    RPIEsperMsg.setFallvalue(Fall);
		    RPIEsperMsg.setSOSvalue(SOS);
		    RPIEsperMsg.setFallNotMovevalue(FallNotMovement);
		    RPIEsperMsg.setDate(fecha);
		    
		    LOGGER.info("Storing Esper message:" + RPIEsperMsg);
    	    cepRT.getEventSender("RPIEsperMsg").sendEvent(RPIEsperMsg);
     
			return true;		
	}
	
	public boolean storeInfo(String room, Float lightvalue, Float soundvalue, Float movevalue, Float gasvalue, Float tempvalue, Float humvalue,
			 long fecha) {
		    BBGEsperMsg= new BBGEsperMessage();
		    BBGEsperMsg.setRoom(room);
		    BBGEsperMsg.setGasvalue(gasvalue);
		    BBGEsperMsg.setMovevalue(movevalue);
		    BBGEsperMsg.setTempvalue(tempvalue);
		    BBGEsperMsg.setHumvalue(humvalue);
		    BBGEsperMsg.setSoundvalue(soundvalue);
		    BBGEsperMsg.setDate(fecha);
		    BBGEsperMsg.setLightvalue(lightvalue);
		    
		    LOGGER.info("Storing Esper message:" + BBGEsperMsg);
    	    cepRT.getEventSender("BBGEsperMsg").sendEvent(BBGEsperMsg);
     
			return true;		
	}

	public boolean storeInfo(String room, Float movevalue, long fecha) {
		moveEsperMsg= new moveEsperMessage();
		moveEsperMsg.setRoom(room);
		moveEsperMsg.setMovevalue(movevalue);
		moveEsperMsg.setDate(fecha);
	    
	    LOGGER.info("Storing Esper message:" + moveEsperMsg);
	    cepRT.getEventSender("moveEsperMsg").sendEvent(moveEsperMsg);
 
		return true;
	}

	public EPRuntime getCepRT() {
		return cepRT;
	}

	public boolean storeInfo(String recordatorio, long fecha) {
		recordatorioEsperMsg= new recordatorioEsperMessage();
		recordatorioEsperMsg.setText(recordatorio);
		recordatorioEsperMsg.setDate(fecha);

	    
	    LOGGER.info("Storing Esper message:" + recordatorioEsperMsg);
	    cepRT.getEventSender("recordatorioEsperMsg").sendEvent(recordatorioEsperMsg);
 
		return true;
	}
	
}
