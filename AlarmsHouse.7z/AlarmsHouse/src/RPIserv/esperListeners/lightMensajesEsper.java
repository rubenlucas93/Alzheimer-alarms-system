package RPIserv.esperListeners;

import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;


public class lightMensajesEsper implements UpdateListener{


	
		private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(GasMensajesEsper.class);
	    private String room;
		private eventMessage event;
		private communicationManager sender;
		private esperManager esperMan;  
		
	    public lightMensajesEsper(esperManager esperManager, communicationManager sender) {
				this.sender=sender;
				this.esperMan=esperManager;
		}


			public void update(EventBean[] newData, EventBean[] oldData) {
				
			    room=(String) esperMan.getCepRT().executeQuery("select BBG_MEASURES.room lightvalue, MOVE_MEASURES.room, BBG_MEASURES.movevalue, MOVE_MEASURES.movevalue"+
		    			" from BBG_MEASURES.win:time(30 minutes), MOVE_MEASURES.win:time(30 minutes)"+
		    			"where MOVE_MEASURES.room=BBG_MEASURES.room having min(lightvalue)>400 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0").getArray()[0].get("MOVE_MEASURES.room");

				
			     LOGGER.info("light on forgotten in room: " +
			        		 room);
			     event=new eventMessage(14, room);
		         sender.sendinfo(event);

			
		    }

			


	
}
