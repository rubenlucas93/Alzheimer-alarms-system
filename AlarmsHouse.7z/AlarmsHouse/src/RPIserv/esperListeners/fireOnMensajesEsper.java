package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class fireOnMensajesEsper implements UpdateListener {
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(fireOnMensajesEsper.class);
	private eventMessage event;
	private communicationManager sender;
	private esperManager esperMan;  
	
	public fireOnMensajesEsper(esperManager esperManager, communicationManager sender) {
		this.sender=sender;
		this.esperMan=esperManager;
	}

	@Override
	public void update(EventBean[] arg0, EventBean[] arg1) {
	     LOGGER.warn("fire is on");
	     event=new eventMessage(12, null);
	     sender.sendinfo(event);
	}

}
