package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class darkMensajesEsper implements UpdateListener{
		
			private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(darkMensajesEsper.class);
		    private String room;
			private eventMessage event;
			private communicationManager sender;
			private esperManager esperMan;  
			
		    public darkMensajesEsper(esperManager esperManager, communicationManager sender) {
					this.sender=sender;
					this.esperMan=esperManager;
			}


				public void update(EventBean[] newData, EventBean[] oldData) {
					

					room=(String) esperMan.getCepRT().executeQuery("select room, lightvalue, movevalue " + 
			    			"from BBG_TABLE").getArray()[0].get("room");

				     LOGGER.warn("patient moving in dark room: " +
				        		 room);
				     event=new eventMessage(15, room);
			         sender.sendinfo(event);

				
	}

	
}
