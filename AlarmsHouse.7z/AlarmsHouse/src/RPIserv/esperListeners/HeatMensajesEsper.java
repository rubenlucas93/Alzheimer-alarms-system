package RPIserv.esperListeners;

import javax.jms.JMSException;
import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.decisionManager;
import common.messageTypes.eventMessage;

public class HeatMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(HeatMensajesEsper.class);
    private static decisionManager decManager;
	private Session session;
	private eventMessage event;
	private communicationManager sender;

		public HeatMensajesEsper(decisionManager manager, communicationManager sender) {
			decManager=manager;
			this.sender=sender;

	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
		         LOGGER.info("Heat event received: "
		                            + newData[0].getUnderlying().toString());
		         event=new eventMessage(9, null);
		         sender.sendinfo(event);


		
	    }

}