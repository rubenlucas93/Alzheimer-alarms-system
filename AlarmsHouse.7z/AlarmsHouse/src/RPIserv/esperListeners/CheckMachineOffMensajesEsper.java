package RPIserv.esperListeners;

import javax.jms.JMSException;
import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class CheckMachineOffMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(CheckMachineOffMensajesEsper.class);
    private static RPIserv.esperManager esperManager;
	private Session session;
	private eventMessage event;
	private communicationManager sender;

		public CheckMachineOffMensajesEsper(esperManager manager, communicationManager sender) {
			esperManager=manager;
			this.sender=sender;
	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
			if (esperManager.machineStateOn==true) {
		         LOGGER.info("Machine off event received: "
		                            + newData[0].getUnderlying().toString());
		         esperManager.machineStateOn=false;
		         event=new eventMessage(3, null);
		         sender.sendinfo(event);
			}


		
	    }

}

