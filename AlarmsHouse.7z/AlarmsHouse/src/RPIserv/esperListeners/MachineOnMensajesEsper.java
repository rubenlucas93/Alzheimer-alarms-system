package RPIserv.esperListeners;

import javax.jms.JMSException;
import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class MachineOnMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(MachineOnMensajesEsper.class);
	private static RPIserv.esperManager esperManager;
	private Session session;
	private eventMessage event;
	private communicationManager sender;

	public MachineOnMensajesEsper(esperManager manager, communicationManager sender) {
			esperManager=manager;
			this.sender=sender;

	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
		         LOGGER.info("Machine on event received: "
		                            + newData[0].getUnderlying().toString());
		         if (esperManager.machineStateOn==false){
		        	 esperManager.machineStateOn=true;
			         event=new eventMessage(11, null);
			         sender.sendinfo(event);
		         }
		         


		
	    }

}

