package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import common.messageTypes.eventMessage;

public class InsercionMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(InsercionMensajesEsper.class);
	private eventMessage event;
	private communicationManager sender;


	public InsercionMensajesEsper(communicationManager sender) {
		this.sender=sender;
	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
		         LOGGER.info("Esper message received: "
		                            + newData[0].getUnderlying().toString());

	    }

}

