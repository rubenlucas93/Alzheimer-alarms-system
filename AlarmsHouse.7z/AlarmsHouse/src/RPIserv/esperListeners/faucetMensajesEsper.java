package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class faucetMensajesEsper implements UpdateListener {
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(faucetMensajesEsper.class);
	private eventMessage event;
	private communicationManager sender;
	private esperManager esperMan;  
	
	public faucetMensajesEsper(esperManager esperManager, communicationManager sender) {
		this.sender=sender;
		this.esperMan=esperManager;
	}

	@Override
	public void update(EventBean[] arg0, EventBean[] arg1) {
	     LOGGER.warn("faucet is open");
	     event=new eventMessage(10, " kitchen");
	     sender.sendinfo(event);
	}

}
