package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class reminderMensajesEsper  implements UpdateListener{

			
				private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(GasMensajesEsper.class);
			    private String room;
				private eventMessage event;
				private communicationManager sender;
				private String reminder;
				
			    public reminderMensajesEsper(String reminder, communicationManager sender) {
						this.sender=sender;
						this.reminder=reminder;
				}


					public void update(EventBean[] newData, EventBean[] oldData) {

						
					     LOGGER.info("reminder: " +
					        		 reminder);
					     event=new eventMessage(12, reminder);
				         sender.sendinfo(event);

					
		}
	
}
