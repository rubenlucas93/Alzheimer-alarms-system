package RPIserv.esperListeners;

import javax.jms.JMSException;
import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import common.messageTypes.eventMessage;
import RPIserv.esperManager;

public class CalefactorMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(CalefactorMensajesEsper.class);
	private static esperManager esperManager;
	private Session session;
	private eventMessage event;
	private communicationManager sender;
	private float avgTemp1;
	private float avgTemp2;
	private float avgTemp3;

		public CalefactorMensajesEsper(esperManager manager, communicationManager sender) {
			this.esperManager=manager;
			this.sender=sender;
	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {

			
			avgTemp1=(float) esperManager.getCepRT().executeQuery("select avg(tempvalue)" +  
	    			" from BBG_MEASURES.win:time(30 seconds), MOVE_MEASURES.win:time(30 seconds)"+
	    			" where BBG_MEASURES.room='comedor' and MOVE_MEASURES.room='comedor' having  avg(tempvalue)>25 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0").getArray()[0].get("avg(tempvalue)");

			avgTemp2=(float) esperManager.getCepRT().executeQuery("select avg(tempvalue)" +  
	    			" from BBG_MEASURES.win:time(60 seconds), MOVE_MEASURES.win:time(60 seconds)"+
	    			" where BBG_MEASURES.room='comedor' and MOVE_MEASURES.room='comedor' having  avg(tempvalue)>25 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0").getArray()[0].get("avg(tempvalue)");

			avgTemp3=(float) esperManager.getCepRT().executeQuery("select avg(tempvalue)" +  
	    			" from BBG_MEASURES.win:time(200 seconds), MOVE_MEASURES.win:time(200 seconds)"+
	    			" where BBG_MEASURES.room='comedor' and MOVE_MEASURES.room='comedor' having  avg(tempvalue)>25 and max(BBG_MEASURES.movevalue)=0.0 and max(MOVE_MEASURES.movevalue)=0.0").getArray()[0].get("avg(tempvalue)");

			if(avgTemp1<avgTemp2 && avgTemp2<avgTemp3) {
				LOGGER.info("Calefactor event received: "
		                            + newData[0].getUnderlying().toString());
		         event=new eventMessage(2, null);
		         sender.sendinfo(event);

			}

		
	    }

}