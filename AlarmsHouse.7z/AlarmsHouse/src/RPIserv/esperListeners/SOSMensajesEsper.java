package RPIserv.esperListeners;

import javax.jms.JMSException;
import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class SOSMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(SOSMensajesEsper.class);
	private static RPIserv.esperManager esperManager;
	private Session session;
	private String room = "somewhere";
	private eventMessage event;
	private communicationManager sender;
	 
		public SOSMensajesEsper(esperManager manager, communicationManager sender) {
			esperManager=manager;
			this.sender=sender;

	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
			
//			try {
		        
//				 String roomBBGValue= (String) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
//							   " from BBG_TABLE where movevalue=1.0").getArray()[0].get("room");
	//			 String roomMoveValue= (String) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
	//					   " from MOVE_MEASURES where movevalue=1.0").getArray()[0].get("date");
	
	
//				 long dateBBGValue= (long) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
//						   " from BBG_TABLE where movevalue=1.0").getArray()[0].get("room");
	//			 long dateMoveValue= (long) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
	//					   " from MOVE_MEASURES where movevalue=1.0").getArray()[0].get("date");
				 
	//			 if (dateBBGValue>dateMoveValue) {
//					room=roomBBGValue; 
	//			 }else {
	//				room=roomMoveValue;
	//			 }
			
//			} catch (IndexOutOfBoundsException e) {
//				LOGGER.info("no BBG messages found");
//			}
//	            
	         LOGGER.info("SOS event received from kitchen");
//	         LOGGER.info("SOS event received from " +
//	        		 room);
	         event=new eventMessage(13, "kitchen");
	         sender.sendinfo(event);
		
		
		}

}

