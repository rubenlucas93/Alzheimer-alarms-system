package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class TVONMensajesEsper implements UpdateListener {
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(TVONMensajesEsper.class);
	private eventMessage event;
	private communicationManager sender;
	private esperManager esperMan;  
	
	public TVONMensajesEsper(esperManager esperManager, communicationManager sender) {
		this.sender=sender;
		this.esperMan=esperManager;
	}

	@Override
	public void update(EventBean[] arg0, EventBean[] arg1) {
	     LOGGER.warn("television is still on");
	     event=new eventMessage(16, null);
	     sender.sendinfo(event);

	}

}
