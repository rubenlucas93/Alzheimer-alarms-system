package RPIserv.esperListeners;

import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class fallMoveMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(fallMoveMensajesEsper.class);
    private static RPIserv.esperManager esperManager;
	private Session session;
	private String room;
	private eventMessage event;
	private communicationManager sender;
	  
		public fallMoveMensajesEsper(esperManager manager, communicationManager sender) {
			esperManager=manager;
			this.sender=sender;
	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
			
			 String roomBBGValue= (String) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
					   " from MOVE_MEASURES where movevalue=1.0;").getArray()[0].get("room");
			 String roomMoveValue= (String) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
					   " from MOVE_MEASURES where movevalue=1.0;").getArray()[0].get("date");


			 long dateBBGValue= (long) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
					   " from BBG_MEASURES where movevalue=1.0;").getArray()[0].get("room");
			 long dateMoveValue= (long) esperManager.getCepRT().executeQuery("select room, date, movevalue " +
					   " from MOVE_MEASURES where movevalue=1.0;").getArray()[0].get("date");
			 
			 if (dateBBGValue>dateBBGValue) {
				room=roomBBGValue; 
			 }else {
				room=roomMoveValue;
			 }
			
		     LOGGER.info("patient fell moving event received in " +
		        		 room);
		     event=new eventMessage(5, roomMoveValue);
	         sender.sendinfo(event);

		
	    }

	}
		

