package RPIserv.esperListeners;

import javax.jms.Session;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import common.messageTypes.eventMessage;
import RPIserv.esperManager;


public class AirMensajesEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(AirMensajesEsper.class);
	private static esperManager esperManager;
	private Session session;
	private eventMessage event;
	private communicationManager sender;
	private float avgTemp1;
	private float avgTemp2;
	private float avgTemp3;

		public AirMensajesEsper(esperManager manager, communicationManager sender) {
			esperManager=manager;
			this.sender=sender;
	}
    	//compare 3 sqls, one avg 60 secs and other avg 280

		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
//		        
//			    LOGGER.info("Checking if air is on");
//				avgTemp1=(float) esperManager.getCepRT().executeQuery("select tempvalue, soundvalue, movevalue, room" +  
//		    			" from BBG_TABLE"+
//		    			" where room='kitchen' and soundvalue>15 and tempvalue<15 and movevalue=0").getArray()[2].get("tempvalue");
//
//				avgTemp2=(float) esperManager.getCepRT().executeQuery("select tempvalue, soundvalue, movevalue, room" +  
//		    			" from BBG_TABLE"+
//		    			" where room='kitchen' and soundvalue>15 and tempvalue<15 and movevalue=0").getArray()[1].get("tempvalue");
//
//				avgTemp3=(float) esperManager.getCepRT().executeQuery("select tempvalue, soundvalue, movevalue, room" +  
//		    			" from BBG_TABLE"+
//		    			" where room='kitchen' and soundvalue>15 and tempvalue<15 and movevalue=0").getArray()[0].get("tempvalue");
//				LOGGER.info(avgTemp1+", "+avgTemp2+", "+ avgTemp3);

				
//				if(avgTemp1>avgTemp2 && avgTemp2>avgTemp3) {
					LOGGER.info("Air event received: "
			                            + newData[0].getUnderlying().toString());
			         event=new eventMessage(1, null);
			         sender.sendinfo(event);
//				}
		
	    }

}