package RPIserv.esperListeners;

import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIserv.communicationManager;
import RPIserv.esperManager;
import common.messageTypes.eventMessage;

public class InsertRecordatoriosEsper implements UpdateListener {

	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(InsertRecordatoriosEsper.class);
	private eventMessage event;
	private communicationManager sender;
	private String text="";
	private static esperManager esperManager;
	private EventBean[] reminders;

	public InsertRecordatoriosEsper(esperManager manager, communicationManager sender) {
		this.sender=sender;
		esperManager=manager;
	}


		@Override
		public void update(EventBean[] newData, EventBean[] oldData) {
			LOGGER.info("reminder received: "
                    + newData[0].getUnderlying().toString());
			long now = System.currentTimeMillis()-500;
			text=(String) esperManager.getCepRT().executeQuery("select text, date from recordatorio_TABLE where date>" + now).getArray()[0].get("text");
			
			 event=new eventMessage(18, text);
			 sender.sendinfo(event);
	    }

}

