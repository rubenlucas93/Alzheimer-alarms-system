/*
 * RecepcionMensajesJMS.java
 *
 * Created on 18 de Noviembre de 2008, 17:23
 */
package RPIserv;

import JMS.JMSMessage;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.RecordatorioMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;
import util.SynchronizedQueue;

/**
 * @version 1.0
 */
public class RecepcionMensajesJMS extends Thread {

  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(RecepcionMensajesJMS.class);

  long rcvTime = 0;
  /**
   * Cola de mensajes utilizada para obtener los mensajes enviados por el IHM
   */
  private final SynchronizedQueue colaRecepcion;

  private decisionManager managerdecision;

  /**
   * Crea una nueva instancia de RecepcionMensajesJMS
   *
   * @param cola Cola de recepcion de los mensajes
   * @param gestor Gestor encargado de realizar la gestion de los mensajes
   */
  public RecepcionMensajesJMS(decisionManager manager, SynchronizedQueue cola) {
    super("RecepcionMensajesJMS");
	this.managerdecision=manager;
    colaRecepcion = cola;
    if (cola != null) {
      start();
    }
  }

  /**
   * Crea una nueva instancia de RecepcionMensajesJMS
   *
   * @param cola Cola de recepcion de los mensajes
   * @param gestor Gestor encargado de realizar la gestion de los mensajes
   */
  public RecepcionMensajesJMS(SynchronizedQueue cola) {
    super("RecepcionMensajesJMS");
    colaRecepcion = cola;
    if (cola != null) {
      start();
    }
  }
  
  /**
   * Metodo de arranque del hilo.
   */
  public void run() {
    while (colaRecepcion != null) {
      final Object objeto = colaRecepcion.consumir();
      if (objeto == null) {
        LOGGER.error("Received message to null");
      } else if (objeto instanceof JMSMessage) {
        final JMSMessage mensajeJMS = (JMSMessage) objeto;
        final Object informacion = mensajeJMS.getObject();

        if (informacion == null) {
          LOGGER.error("The information received within the message is null.");
        } else if (informacion instanceof BBGmessage ||  informacion instanceof RPImessage || informacion instanceof RecordatorioMessage ) {
        	rcvTime = System.currentTimeMillis();
        	managerdecision.getTratarMensaje().messageReceived(informacion, rcvTime);
        }
        /**
         * No used } else if (objeto instanceof JMSSubscriberState) { } else if (objeto instanceof JMSPublisherState) { } else if (objeto instanceof Life) {
         */
      } else {
    	  LOGGER.log("recibido por cola mensaje no tratado " + objeto.getClass().toString());
      }
    }

  }
}