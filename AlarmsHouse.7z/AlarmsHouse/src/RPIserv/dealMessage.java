package RPIserv;


import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.RecordatorioMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

public class dealMessage {
	
	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(dealMessage.class);

    private Float temperature = (float) 0;

    private Float sound = (float) 0;

    private int movement = 0;

    private Float distance = (float) 0;

    private Float gas = (float) 0;

    private esperManager esper;
    
    private long fecha;
    
    private decisionManager decManager;

	private boolean success;
    
    public Float getTemperature() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.temperature;
    }

    public void setTemperature(final Float value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.temperature = value;
    }

    public Float getSound() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.sound;
    }

    public void setSound(final Float value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.sound = value;
    }

    public int getMovement() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.movement;
    }

    public void setMovement(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.movement = value;
    }

    public Float getGas() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.gas;
    }

    public void setGas(final Float value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.gas = value;
    }

    public Float getDistance() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.distance;
    }

    public void setDistance(final Float value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.distance = value;
    }

    public void messageReceived(final Object mensaje, long fecha) {
    	if (mensaje instanceof BBGmessage){
    		BBGmessage informacion=(BBGmessage) mensaje;
        	LOGGER.info("mensaje de " + informacion.getRoom()  + " recibido a las " + fecha + "!");
        	success=esper.storeInfo(informacion.getRoom(), informacion.getLightvalue(), informacion.getSoundvalue(), informacion.getMovevalue() , informacion.getGasvalue(), informacion.getTempvalue(), informacion.getHumvalue(), fecha);
        	if (success) {
        		LOGGER.info("mensaje de BBG almacenado");
        	}else {
        		LOGGER.error("error almacenando el mensaje de BBG en esper");
        	}
    	}else if (mensaje instanceof movemessage){
    		movemessage informacion=(movemessage) mensaje;
        	LOGGER.info("mensaje de movimiento de " + informacion.getRoom()  + " recibido a las " + fecha + "!");
        	success=esper.storeInfo(informacion.getRoom(), informacion.getMovevalue(), fecha);
        	if (success) {
        		LOGGER.info("mensaje de movimiento almacenado");
        	}else {
        		LOGGER.error("error almacenando el mensaje de movimiento en esper");
        	}
        }else if (mensaje instanceof RPImessage){
    		RPImessage informacion=(RPImessage) mensaje;
        	LOGGER.info("mensaje de RPI recibido a las " + fecha + "!");
        	success=esper.storeInfo(informacion.getFallvalue(), informacion.getSOSvalue(), informacion.getFallNotMoveValue(), fecha);
        	if (success) {
        		LOGGER.info("mensaje de RPI almacenado");
        	}else {
        		LOGGER.error("error almacenando el mensaje de movimiento en esper");
        	}
        }else if (mensaje instanceof RecordatorioMessage) {
        	RecordatorioMessage informacion=(RecordatorioMessage) mensaje;
        	LOGGER.info("recordatorio recibido a las " + fecha + "!");
        	success=esper.storeInfo(informacion.getRecordatorio(), fecha);
        	if (success) {
        		LOGGER.info("recordatorio mostrado");
        	}else {
        		LOGGER.error("error mostrando el recordatorio");
        	}
        }else{
    		LOGGER.error("recibido un objeto que no es un mensaje");
    	}
     }
    
    public dealMessage(decisionManager manager) {
    	this.decManager=manager;
    	this.esper=decManager.getEsper();
    }

	public long getFecha() {
		return fecha;
	}

	public void setFecha(long fecha) {
		this.fecha = fecha;
	}

}
