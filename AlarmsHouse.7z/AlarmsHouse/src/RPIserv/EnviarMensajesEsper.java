package RPIserv;

import com.espertech.esper.client.Configuration;
import com.espertech.esper.client.EPRuntime;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;

import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.BBGmessage;
 
public class EnviarMensajesEsper {

	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(EnviarMensajesEsper.class);


 
    public static void EnviarMensajes(String[] args) {
     //The Configuration is meant only as an initialization-time object.
      Configuration cepConfig = new Configuration();
      cepConfig.addEventType("evento",BBGmessage.class.getName());
 
      EPServiceProvider cep=EPServiceProviderManager.getProvider("myCEPEngine",cepConfig);
 
      EPRuntime cepRT = cep.getEPRuntime();
    }
}
