package RPIclient;

import java.io.IOException;

import JMS.JMSInterface;
import JNI.JNISleep;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.sensor;
import common.messageTypes.RPImessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

public class sensorManager {
   
    private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(sensorManager.class);

	private communicationManager comm;
	
	private RPImessage sensorMsg ;

    
    private boolean fallValue = false;

    private boolean SOSValue = false;

	private fallDetector fallChecker;

	private boolean fallAndMovement;

	private boolean fallAndNotMovement;
    

    
    public sensorManager() throws InterruptedException {
    	fallChecker=new fallDetector();
    	sensorMsg=new RPImessage();
    	
    }
	
    public void enableAnalogPorts() throws InterruptedException {
//		try {
			
//			String command = "echo cape-bone-iio > /sys/devices/bone_capemgr.*/slots";
//	        // Similarly for this: "java -cp input\\master\\Kajari_G\\ MemoryComparison > output\\output1.txt" also           
//	        Process proc = Runtime.getRuntime().exec(new String[] { "/bin/sh"//$NON-NLS-1$
//	                , "-c", command });//$NON-NLS-1$
//	        if (proc != null) {
//	            proc.waitFor();
//	        }

			LOGGER.info("Analogs Ports enabled");		

//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		};
	}

    public void run() throws InterruptedException, NumberFormatException, IOException {

    	enableAnalogPorts();
    	while(true) {

	    	
	    	setFallChecker(new fallDetector());
	    	
	    	SOSValue=getSOSValue();
	    	fallAndMovement=getFallChecker().getfallAndMovement();
	    	fallAndNotMovement=getFallChecker().getfallAndNotMovement();

	    	if (SOSValue==true || fallAndNotMovement==true || fallAndMovement==true) {
		    	if(sensorMsg.constructMessage(fallAndMovement, SOSValue, fallAndNotMovement)) {
		    	
	    		comm.sendinfo(sensorMsg);
	
		    	}
		        try {
					JNISleep.sleep(4000);
				} catch (InterruptedException e) {
					LOGGER.error("sleep worked bad");
				}
	    	}
    	
    	}
    }


	private boolean getSOSValue() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isFallValue() {
		return fallValue;
	}

	public void setFallValue(boolean fallValue) {
		this.fallValue = fallValue;
	}


	public fallDetector getFallChecker() {
		return fallChecker;
	}

	public void setFallChecker(fallDetector fallChecker) {
		this.fallChecker = fallChecker;
	}
	  
}
