package RPIclient;

import java.io.IOException;

import common.sensor;

public class moveSensor extends sensor {
	
	private static final String PORT = "48";
	String Direction = "in";
	
	@Override
	public Float getSensedInfo() throws NumberFormatException, IOException {

		return Float.valueOf(readIOPort(PORT));
    
	}
	
	
	public moveSensor() throws InterruptedException{
		executeEnableIOPortCommand(PORT);
		executeSetIODirection(Direction, PORT);
	}
}
