package BBG;

import java.io.IOException;

import common.sensor;

public class moveSensor extends sensor {
	
	private static final String PORT = "48";
	String Direction = "in";
	Float sensedInfo=(float) 0;
	
	@Override
	public Float getSensedInfo() throws NumberFormatException, IOException {

		sensedInfo=readIOPort(PORT);
	    LOGGER.info("movement -"+ sensedInfo);
		return sensedInfo;

//	    return (float) 0;
		
	}
	
	public moveSensor(){
		super();
		try {
			executeEnableIOPortCommand(PORT);
			executeSetIODirection(Direction, PORT);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
