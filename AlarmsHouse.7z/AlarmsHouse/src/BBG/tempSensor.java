package BBG;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import common.sensor;

public class tempSensor extends sensor {

	private static final String PORT = "P9_12";
	
	private static Float info=(float) 0;

	@Override
	public Float getSensedInfo(Integer i) throws NumberFormatException, IOException {

    	info=(float) Math.round(21-i);
		LOGGER.info("temp -"+info);
    	return info;
//		return getTempDHT11(PORT);
    
	}

}
