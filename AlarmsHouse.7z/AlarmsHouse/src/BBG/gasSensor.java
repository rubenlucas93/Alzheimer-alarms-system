package BBG;

import java.io.IOException;

import common.sensor;

public class gasSensor extends sensor {
	
			
	private static final String PORT = "3";
	private Float finalSensedInfo=(float) 0;

	@Override
	public Float getSensedInfo(Integer i) throws NumberFormatException, IOException {

		if (i<10) {
			finalSensedInfo=(float) 0;
		}else {
			finalSensedInfo=(float) Math.round((15*Math.random()*i));
		}

//		finalSensedInfo=readAnalogPort(PORT);
		LOGGER.info("gas - "+finalSensedInfo);
		return finalSensedInfo;
    
	}
	
	
}
