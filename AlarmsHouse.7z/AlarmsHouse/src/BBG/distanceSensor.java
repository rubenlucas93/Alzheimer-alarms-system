package BBG;

import common.sensor;

public class distanceSensor extends sensor {
	
	public void run() {
	    //sensar
	  }
	
	public distanceSensor() {
        new Thread("distanceSensor").start();

	}

}
