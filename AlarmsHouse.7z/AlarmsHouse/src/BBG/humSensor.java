package BBG;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import common.sensor;

public class humSensor extends sensor {

	private static final String PORT = "P9_12";
	
	private static Float info=(float) 0;


	@Override
	public Float getSensedInfo(Integer i) throws NumberFormatException, IOException {

		info =(float) Math.round((80 + Math.random()));
		LOGGER.info("hum -"+info);
		return info;
		
//		return getHumDHT11(PORT);
    
	}


}
