package BBG;

import java.io.IOException;

import common.sensor;

public class lightSensor extends sensor {
	
			
	private static final String PORT = "1";
	private Float finalSensedInfo=(float) 0;

	@Override
	public Float getSensedInfo() throws NumberFormatException, IOException {

//		finalSensedInfo = (float) Math.round((200 + Math.random()*5));
		finalSensedInfo=readAnalogPort(PORT);
		LOGGER.info("light - "+finalSensedInfo);
		return finalSensedInfo;
    
	}
	
	
}
