package BBG;

import java.io.IOException;


import JMS.JMSInterface;
import JNI.JNISleep;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.sensor;
import common.messageTypes.RPImessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

public class sensorManager {
   
    private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(sensorManager.class);

	private static sensorManager manager;
	
	private communicationManager comm;
	
	private BBGmessage sensorMsg = new BBGmessage();



    private Float gasvalue = (float) 0;

    private Float tempvalue = (float) 0;

    private Float soundvalue = (float) 0;

    private Float movevalue = (float) 0;

	private Float lightvalue= (float) 0;

	private moveSensor move;

	private soundSensor sound;

	private gasSensor gas;

	private tempSensor temp;

	private lightSensor light;

	private Float humvalue;

	private humSensor hum;
    
	private Integer i=0;
	
    public sensorManager() throws InterruptedException {
    	
    	comm=new communicationManager(){
    		@Override
    	    public boolean sendinfo(BBGmessage msgToSend) {
	            boolean success = false;
	    		if (interfazJMS != null) {
	    		    interfazJMS.sendMessage(msgToSend, JMSInterface.UPDATE_ALL_CLIENTS);
	                return success;
	    		}else{
	    			return false;
	    		}
    		}

			@Override
			public void listenMessages() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public boolean sendinfo(eventMessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(movemessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(RPImessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}
    	};

    	
    }
    
    public void run() throws InterruptedException, NumberFormatException, IOException {
    	
    	sound=new soundSensor();
    	move=new moveSensor();
    	light=new lightSensor();
    	gas=new gasSensor();
    	temp=new tempSensor();
    	hum=new humSensor();
    	
    	sensor.enableAnalogPorts();
    	while(true) {

    		soundvalue=sound.getSensedInfo(i);
            try {
    				JNISleep.sleep((long)(1000+Math.random()*500));
    			} catch (InterruptedException e) {
    				LOGGER.error("sleep worked bad");
    			}

    		gasvalue=gas.getSensedInfo(i);

            try {
    				JNISleep.sleep((long)(1000+Math.random()*500));
    			} catch (InterruptedException e) {
    				LOGGER.error("sleep worked bad");
    			}

	    	tempvalue=temp.getSensedInfo(i);

	        try {
					JNISleep.sleep((long)(1000+Math.random()*500));
				} catch (InterruptedException e) {
					LOGGER.error("sleep worked bad");
				}
	    	movevalue=move.getSensedInfo();
	    	
	        try {
					JNISleep.sleep((long)(1000+Math.random()*500));
				} catch (InterruptedException e) {
					LOGGER.error("sleep worked bad");
				}

    		humvalue=hum.getSensedInfo(i);

            try {
    				JNISleep.sleep((long)(1000+Math.random()*500));
    			} catch (InterruptedException e) {
    				LOGGER.error("sleep worked bad");
    			}

	    	lightvalue=light.getSensedInfo();

	    	
	    	if(sensorMsg.constructMessage(movevalue, lightvalue, gasvalue, tempvalue , humvalue, soundvalue, "kitchen")) {
	    	
    		comm.sendinfo(sensorMsg);

	    	}
	        try {
				JNISleep.sleep(((long)(1000+Math.random()*500)));
			} catch (InterruptedException e) {
				LOGGER.error("sleep worked bad");
			}
    	
    	}
    }
	  public static void main(String[] args) throws InterruptedException, IOException {
		  manager=new sensorManager();
		  manager.run();
	  }

}
