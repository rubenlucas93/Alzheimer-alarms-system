package BBG;

import JMS.JMSInterface;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

public abstract class communicationManager {

    public static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(communicationManager.class);
//    public static JMSInterface interfazJMS = new JMSInterface("C:\\Users\\Z003TXBU\\eclipse-workspace\\AlarmsHouse\\config\\jms.properties");;
    public static JMSInterface interfazJMS = new JMSInterface("/TFMconfig/jms.properties");

    
	public communicationManager() {
		// TODO Auto-generated constructor stub
	}

	public abstract boolean sendinfo(BBGmessage msgToSend);

    public abstract void listenMessages();

	public abstract boolean sendinfo(eventMessage msgToSend);


	public abstract boolean sendinfo(movemessage msgToSend);

	public abstract boolean sendinfo(RPImessage msgToSend);



}
