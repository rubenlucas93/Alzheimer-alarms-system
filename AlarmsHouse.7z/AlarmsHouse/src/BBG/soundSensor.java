package BBG;

import java.io.IOException;

import common.sensor;

public class soundSensor extends sensor {

	private static final String PORT = "6";;
	private Float finalSensedInfo=(float) 0;

	@Override
	public Float getSensedInfo(Integer i) throws NumberFormatException, IOException {

//		finalSensedInfo=readAnalogPort(PORT);
		finalSensedInfo=(float) Math.round((60 - Math.random()*i+Math.random()*i));
		LOGGER.info("sound - "+finalSensedInfo);
		return finalSensedInfo;
    
	}

}
