package externalCLient;

import java.io.IOException;

import common.sensor;

/**
	 *
	 * @author pablo
	 */



	public class fallDetector extends Thread {
	   
		private acelerometerSensor acelerometerSensor;
		
		private boolean fallAndMovementValue;
		private boolean fallAndNotMovementValue;

		private Float[] valuesXYZ;

		private Float[] valuesXYZ2;
		

		public fallDetector() {
		    acelerometerSensor=new acelerometerSensor();

			start();
		}

		public void run() {

	    	while(true) {

		    	try {
					valuesXYZ=acelerometerSensor.getInfo();
				} catch (NumberFormatException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		    	if (valuesXYZ[2]<6){
		    		try {
						valuesXYZ2=acelerometerSensor.getInfo();
					} catch (NumberFormatException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    		if ((valuesXYZ2[2].equals(valuesXYZ[2]))){
		    			fallAndNotMovementValue=true;
		    			fallAndMovementValue=false;
		    		}else {
		    			fallAndNotMovementValue=false;
		    		}
		    	}else {
	    			fallAndNotMovementValue=false;
	    			fallAndMovementValue=false;
		    	}
	    	}
		    	
	    	}
	    
		
		public boolean getfallAndMovement() {
			// TODO Auto-generated method stub
			return this.fallAndMovementValue;
		}

		public boolean getfallAndNotMovement() {
			// TODO Auto-generated method stub
			return this.fallAndNotMovementValue;
		}
		
		
}


