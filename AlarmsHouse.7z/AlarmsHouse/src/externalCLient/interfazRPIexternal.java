package externalCLient;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.sound.sampled.AudioFileFormat.Type;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.sun.speech.freetts.audio.SingleFileAudioPlayer;

import JMS.JMSInterface;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.DialogoInfo;
import common.SimpleTTS;
import common.needHelpWindow;
import common.messageTypes.RPImessage;
import common.messageTypes.eventMessage;

public class interfazRPIexternal {

	
	private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(interfazRPIexternal.class);



	private static SimpleTTS voz;
	private static int lastEvent=0;
	private static long lastTime=0;



	private static String tempaudioPath="/home/pi/Desktop/tempaudio.wav";
//	private String tempaudioPath="C:\\Users\\Z003TXBU\\Desktop\\tempaudio.wav";
	private SingleFileAudioPlayer audioPlayer = new SingleFileAudioPlayer(tempaudioPath,Type.WAVE);



	private JPanel SOSPanel;



	private JButton Button;



	private boolean fallAndNotMovement;



	private boolean fallAndMovement;



	private boolean SOSValue;



	private RPImessage sensorMsg;



	private communicationManagerexternal comm;



	private static JDialog Window;


	private static Process proc;
	

	
	public interfazRPIexternal() throws Exception{
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
		voz = new SimpleTTS("kevin"); //if you pay, you can get more voices like "mbrola"
		audioNotify("voice inicialized");
	}


	static void audioNotify(String text) throws Exception{
//		voz.toFile(tempaudioPath, text);
//		String command = "omxplayer -o alsa " + tempaudioPath;
//        proc = Runtime.getRuntime().exec(new String[] { "bash"//$NON-NLS-1$
//                , "-c", command });//$NON-NLS-1$
	}
	
//	private static void createUI() {
//	
//		
//	}
//	


	/**	
	   * Muestra un mensaje de alerta
	   *
	   * @param mensaje mensaje a mostrar
	   */
	  static void alert(String mensaje) {
	    DialogoInfo info = new DialogoInfo(new JFrame(), true, mensaje, true);
	    info.dispose();
	  }

	public static void showEvent(Object informacion, long rcvTime) throws Exception {
		if (informacion instanceof eventMessage){
			eventMessage evento=(eventMessage) informacion;
        	LOGGER.info("evento recibido a las " + rcvTime + "!");
        	switch (evento.getEventType()) {
	        	case 1: 
	        		LOGGER.info("air conditioning on");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {
	        		audioNotify("the air conditioning is on");
	        		alert("the air conditioning is on");
	        		}
	        		break;
	          	case 2:
	        		LOGGER.info("Calefactor on");

	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("the calefactor is on");
	        		alert("the calefactor is on");
	        		
	        		}
	        		break;
	        	case 3: 
	        		LOGGER.info("the washing machine or dryer has already finish");

	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("the washing machine or dryer has already finish");
	        		alert("the washing machine or dryer has already finish");
	        		}
	        		break;
	        	case 4:
	        		LOGGER.info("fire open! turn off please, we do not want an accident");

	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("fire open! turn off please, we do not want an accident");
	        		alert("fire open! turn off please, we do not want an accident");
	        		}
	        		break;	     
	        	case 5:
	        		LOGGER.info("patient fell but is still conscius");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("WARNING!! ATTENTION!! THE PATIENT FELL");
	        		alert("WARNING!! ATTENTION!! THE PATIENT FELL");

	        		}
	        		break;
	        	case 6:
	        		LOGGER.info("patient fell and is unconscius");
	        		audioNotify("CRITICAL WARNING! THE PATIENT FELL AND LOST CONSCIOUSNESS");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		alert("CRITICAL WARNING! THE PATIENT FELL AND LOST CONSCIOUSNESS");
	        		}
	        		break;
	        	case 7:
	        		LOGGER.info("room is too cold");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("room temperature is too low");
	        		alert("room temperature is too low");

	        		}
	        		break;
	        	case 8:
	        		LOGGER.info("gas measure is too high");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("WARNING! the gas is open.");

	        		alert("WARNING! the gas is open.");
	        		}
	        		break;
	        	case 9:
	        		LOGGER.info("room is too hot");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("room temperature is too high");
	        		alert("room temperature is too high");
	        		}
	        		break;
	        	case 10:
	        		LOGGER.info("faucet open in room" + evento.getExtraInfo());
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("faucet open in room " + evento.getExtraInfo());
	        		alert("\"faucet open in room" + evento.getExtraInfo());

	        		}
	        		//entre otros eventos, en este ser�a interesante poder encender la luz de la habitaci�n
	        		break;	       
	        	case 11:
	        		LOGGER.info("washing machine or dryer ongoing");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("washing machine or dryer ongoing");
	        		alert("washing machine or dryer ongoing");
	        		}
	        		break;
	        	case 12:
	        		LOGGER.info("reminder!");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify(evento.getExtraInfo());
	        		alert(evento.getExtraInfo());

	        		}
	        		break;
	        	case 13:
	        		LOGGER.info("SOS-SOS-SOS");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("I need help");
	        		
	        		alert("I need help");
	        		}
	        		break;
	        	case 14:
	        		LOGGER.info("light still on");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("check the lights of the " + evento.getExtraInfo());
	        		
	        		alert("check the lights of the " + evento.getExtraInfo());
	        		}
	        		break;
	        	case 15:
	        		LOGGER.info("patient disoriented in the dark");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("you are in the " + evento.getExtraInfo());
	        		alert("you are in the " + evento.getExtraInfo());
	        		}
	        		//entre otros eventos, en este ser�a interesante poder encender la luz de la habitaci�n
	        		break;
	        	case 16:
	        		LOGGER.info("Television is still on");
	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {

	        		audioNotify("Television is still on");
	        		alert("Television is still on");
	        		}
	        		//entre otros eventos, en este ser�a interesante poder encender la luz de la habitaci�n
	        		break;
//	        	case 18:
//	        		LOGGER.info("Re minder!");
//	        		if (lastEvent!=evento.getEventType() || rcvTime-lastTime>5000) {
//
//	        		audioNotify(evento.getExtraInfo());
//	        		alert(evento.getExtraInfo());
//	        		}
//	        		//entre otros eventos, en este ser�a interesante poder encender la luz de la habitaci�n
//	        		break;
	        	default:
	        		break;

        	}
   	     
           	lastTime=rcvTime;
           	lastEvent=evento.getEventType();

		}else {
        	LOGGER.debug("recibido mensaje no tratado a las " + rcvTime + "!");

		}
	
	}


	public void setComm(communicationManagerexternal comm) {
		this.comm=comm;
		Window = new writeReminderWindow(new JFrame(), false, "Reminder window", false, comm);

//		createUI(); //TODO Fix

	}
	public communicationManagerexternal getComm() {
		return this.comm;
	}
}

