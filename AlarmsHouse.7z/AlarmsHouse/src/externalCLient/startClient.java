package externalCLient;

import java.io.IOException;

import JMS.JMSInterface;
import JNI.JNISleep;
import common.messageTypes.BBGmessage;
import common.messageTypes.RPImessage;
import common.messageTypes.RecordatorioMessage;
import common.messageTypes.eventMessage;
import common.messageTypes.movemessage;

public class startClient {

	private static communicationManagerexternal comm;
	protected static RecepcionMensajesJMSCLientewexternal receptor;
	private static interfazRPIexternal interfazRPI;
	private static sensorManager sensorManager;
	private static Thread checkTime;
	
	public static void main(String[] args) throws InterruptedException, IOException, Exception {
	   
		sensorManager=new sensorManager();
	    interfazRPI=new externalCLient.interfazRPIexternal(); 
		
		comm=new communicationManagerexternal(interfazRPI){
			
			@Override
    	    public void listenMessages(){
        	    LOGGER.log("------------------------------------------");
        	    LOGGER.log("---  Loading messaging  ---");
	    		if (interfazJMS != null) {
	        	    receptor = new RecepcionMensajesJMSCLientewexternal(interfazRPI, interfazJMS.getReceptionQueue());
	    		}
    		}

    		@Override
    	    public boolean sendinfo(RecordatorioMessage msgToSend) {
	            boolean success = false;
	    		if (interfazJMS != null) {
	    		    interfazJMS.sendMessage(msgToSend, JMSInterface.UPDATE_ALL_CLIENTS);
	                return success;
	    		}else{
	    			return false;
	    		}
    		}



			@Override
			public boolean sendinfo(eventMessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(movemessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean sendinfo(RPImessage msgToSend) {
				// TODO Auto-generated method stub
				return false;
			}

			
    	};
    	
//    	checkTime = new Thread(new Runnable() {
//  	      @Override
//  	      public void run() {
//  	    	  while(true) {
//  	            long timeToWait = 600000;
//  	            try {
//  	            	externalCLient.interfazRPI.alert("check the batery level of the bracelet");
//  	            	externalCLient.interfazRPI.audioNotify("check the batery level of the bracelet");
//					JNISleep.sleep(timeToWait);
//
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//
//  	      }
//  	    }  
//  	});
    	
    	
    	comm.listenMessages();    	
    	interfazRPI.setComm(comm);      
//    	checkTime.start();
	}
	
}

