package externalCLient;

import JMS.JMSInterface;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import RPIclient.interfazRPI;
import common.messageTypes.RPImessage;
import common.messageTypes.RecordatorioMessage;
import common.messageTypes.eventMessage;
import common.messageTypes.BBGmessage;
import common.messageTypes.movemessage;

public abstract class communicationManagerexternal {

	public externalCLient.interfazRPIexternal interfaz;
    public static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(communicationManagerexternal.class);
    public static JMSInterface interfazJMS = new JMSInterface("C:\\Users\\Z003TXBU\\eclipse-workspace\\AlarmsHouse\\config\\jms.properties");;
//    public static JMSInterface interfazJMS = new JMSInterface("/TFMconfig/jms.properties");

    public communicationManagerexternal(externalCLient.interfazRPIexternal interfazRPI) {
    	this.interfaz=interfazRPI;
    }
    
	public communicationManagerexternal() {
		// TODO Auto-generated constructor stub
	}

	public abstract boolean sendinfo(RecordatorioMessage recordatorio);

    public abstract void listenMessages();

	public abstract boolean sendinfo(eventMessage msgToSend);


	public abstract boolean sendinfo(movemessage msgToSend);

	public abstract boolean sendinfo(RPImessage msgToSend);



}
