package externalCLient;

import java.io.IOException;

import common.sensor;

public class acelerometerSensor extends sensor {
	
			
	private static final String PORT = "1";;


	public Float[] getInfo() throws NumberFormatException, IOException {
		Float[] values = {(float) 0, (float) 0, (float) 0};
//		values[0]=Float.valueOf((readAccelerometer(PORT).split(";")[0]));
//		values[1]=Float.valueOf((readAccelerometer(PORT).split(";")[1]));
//		values[2]=Float.valueOf((readAccelerometer(PORT).split(";")[2]));
		values[0]=(float) 10.0;
		values[1]=(float) 10.0;
		values[2]=(float) 10.0;

		return values;
	}
	
	
}
