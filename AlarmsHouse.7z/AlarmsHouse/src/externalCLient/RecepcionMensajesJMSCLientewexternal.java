package externalCLient;

import JMS.JMSMessage;
import Logger.OCSLogger;
import Logger.OCSLoggerFactory;
import common.messageTypes.RPImessage;
import common.messageTypes.eventMessage;
import util.SynchronizedQueue;


public class RecepcionMensajesJMSCLientewexternal extends Thread{
	  private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(RecepcionMensajesJMSCLientewexternal.class);


	  long rcvTime = 0;
	  /**
	   * Cola de mensajes utilizada para obtener los mensajes enviados por el IHM
	   */
	  private final SynchronizedQueue colaRecepcion;

	private interfazRPIexternal interfaz;


	  /**
	   * Crea una nueva instancia de RecepcionMensajesJMS
	   *
	   * @param cola Cola de recepcion de los mensajes
	   * @param gestor Gestor encargado de realizar la gestion de los mensajes
	   */
	  public RecepcionMensajesJMSCLientewexternal(interfazRPIexternal interfaz, SynchronizedQueue cola) {
		super("RecepcionMensajesJMSCLiente");
	    colaRecepcion = cola;
	    this.setInterfaz(interfaz);
	    if (cola != null) {
          System.out.println("receptor ready");
	      start();
	    }
	    
	  }
	  
	  /**
	   * Metodo de arranque del hilo.
	   */
	  public void run() {
	    while (colaRecepcion != null) {
	      final Object objeto = colaRecepcion.consumir();
	      if (objeto == null) {
	        LOGGER.error("Received message to null");
	      } else if (objeto instanceof JMSMessage) {
	        final JMSMessage mensajeJMS = (JMSMessage) objeto;
	        final Object informacion = mensajeJMS.getObject();
	        if (informacion instanceof eventMessage) {
	        	rcvTime = System.currentTimeMillis();
	        	try {
	  	          LOGGER.error("Received Event!");
					externalCLient.interfazRPIexternal.showEvent(informacion, rcvTime);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        /**
	         * No used } else if (objeto instanceof JMSSubscriberState) { } else if (objeto instanceof JMSPublisherState) { } else if (objeto instanceof Life) {
	         */
	      } else {
	    	  LOGGER.log("recibido por cola mensajito no tratado " + objeto.getClass().toString());
	      }
	    }

	  }

	public interfazRPIexternal getInterfaz() {
		return interfaz;
	}

	public void setInterfaz(interfazRPIexternal interfaz) {
		this.interfaz = interfaz;
	}
}
