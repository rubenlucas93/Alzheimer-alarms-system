package IsolateMoveSensor;
//ESTE ES UNA REFERENCIA EN JAVA. FINALMENTE SE UTILIZAR� UNA VERSI�N EN C QUE REQUIERE MENOS MEMORIA Y ES M�S R�PIDO.
//IMPORTANTE TENER EN CUENTA QUE LOS MENSAJES TIENEN QUE SER:
//TOPICO=movement PAYLOAD=<roomID>;<movevalue>

	import java.io.IOException;	
	import JMS.JMSInterface;
	import JNI.JNISleep;
	import Logger.OCSLogger;
	import Logger.OCSLoggerFactory;
	import common.sensor;
	import common.messageTypes.RPImessage;
	import common.messageTypes.eventMessage;
	import common.messageTypes.BBGmessage;
	import common.messageTypes.movemessage;

	public class moveSensorManager {
	   
	    private static final OCSLogger LOGGER = OCSLoggerFactory.getLogger(moveSensorManager.class);

		private static moveSensorManager manager;
		
		private communicationManager comm;
		
		private movemessage sensorMsg = new movemessage();


	    private Float movement;
	    

	    private Float movevalue = (float) 0;


	    public Float getMovement() {

	        return this.movement;
	    }

	    public void setMovement(final Float value) {
	        this.movement = value;
	    }
	    
	    //Aqu� habr� que meter el main en el que inicie todos los sensores 
	    //y vaya pidiendo informaci�n y mand�ndola forever
	    
	    public void sensorManager() throws InterruptedException {
	    	
	    	comm=new communicationManager(){
	    		@Override
	    	    public boolean sendinfo(BBGmessage msgToSend) {
		            boolean success = false;
		    		if (interfazJMS != null) {
		    		    interfazJMS.sendMessage(msgToSend, JMSInterface.UPDATE_ALL_CLIENTS);
		                return success;
		    		}else{
		    			return false;
		    		}
	    		}

				@Override
				public void listenMessages() {
					// TODO Auto-generated method stub
					
				}

				@Override
				public boolean sendinfo(eventMessage msgToSend) {
					// TODO Auto-generated method stub
					return false;
				}

				@Override
				public boolean sendinfo(movemessage msgToSend) {
					// TODO Auto-generated method stub
					return false;
				}

				@Override
				public boolean sendinfo(RPImessage msgToSend) {
					// TODO Auto-generated method stub
					return false;
				}
	    	};

	    	
	    }
	    
	    public void run() throws InterruptedException, NumberFormatException, IOException {

//	    	sensor.enableAnalogPorts(); TO DO NEVER :D
	    	while(true) {

		    	movevalue=(float) 1;
//		    	}else {
//			    	movevalue=(float) 0;
	//
//		    	}
		    	if(sensorMsg.constructMessage(movevalue, "cocina")) {
		    	
	    		comm.sendinfo(sensorMsg);

		    	}
		        try {
					JNISleep.sleep(4000);
				} catch (InterruptedException e) {
					LOGGER.error("sleep worked bad");
				}

	    	
	    	}
	    }
		  public static void main(String[] args) throws InterruptedException, IOException {
			  manager=new moveSensorManager();
			  manager.run();
		  }

	}

