-----Prerequisites------------

development environment for compiling the code


-----Installing--------------

Load the code into the environment

-----Running the tests-------

Run following configurations:

-sensorManager contained in BBG folder (this class act as main class of BBG)
-decisionManager contained in RPIserver folder (this class act as main class of the server)
-startClient contained in RPIclient folder (this class act as main class of the client board)

*For isolate sensor we provide a C programm.

------Deployment--------------

export sensorManager as a java proyect and then run it into the BBG using the command:
java -jar sensorManager.java


export decisionManager as a java proyect and then run it into the raspberry pi server using the command:
java -jar decisionManager.java


export startClient as a java proyect and then run it into the raspberry pi client using the command:
java -jar startClient.java

